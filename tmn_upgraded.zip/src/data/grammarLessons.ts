import type { GrammarCategoryId, GrammarLesson } from '../types';
import { GRAMMAR_LESSONS_PART_1 } from './grammarLessonsPart1';
import { GRAMMAR_LESSONS_PART_2 } from './grammarLessonsPart2';

/**
 * Complete 36-lesson English Grammar Curriculum (CEFR A0 through C2).
 * Each rule contains structured Arabic explanation (auto-localized to all 10 UI languages),
 * formula, how/when to use, common mistakes, spoken examples, and 4 interactive exercise types.
 */
export const GRAMMAR_LESSONS: GrammarLesson[] = [
  ...GRAMMAR_LESSONS_PART_1,
  ...GRAMMAR_LESSONS_PART_2,
];

export const GRAMMAR_CATEGORIES: GrammarCategoryId[] = [
  'foundations',
  'tenses',
  'modals',
  'modifiers',
  'connectors',
  'voice_speech',
  'clauses',
  'advanced',
];
