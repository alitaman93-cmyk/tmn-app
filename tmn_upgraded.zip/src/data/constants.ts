import type { BandMeta, CefrBand, GameDef, GameModeId } from '../types';

export const TMN_LOGO_URL = '/assets/aistudio/photo_2026-11-24_22-36-05_19c2b62d.jpg';

export const BANDS: CefrBand[] = ['A0', 'A1', 'A2', 'B1', 'B2', 'C1', 'C2'];

export const BAND_META: Record<CefrBand, BandMeta> = {
  A0: {
    ar: 'تأسيسي',
    desc: 'أهم الكلمات الأساسية جداً',
    color: '#059669',
    bgClass: 'bg-emerald-600',
    textClass: 'text-emerald-600 dark:text-emerald-400',
  },
  A1: {
    ar: 'مبتدئ',
    desc: 'مستوى المبتدئ الأول',
    color: '#0d9488',
    bgClass: 'bg-teal-600',
    textClass: 'text-teal-600 dark:text-teal-400',
  },
  A2: {
    ar: 'أساسي',
    desc: 'المحادثة والحياة اليومية',
    color: '#0891b2',
    bgClass: 'bg-cyan-600',
    textClass: 'text-cyan-600 dark:text-cyan-400',
  },
  B1: {
    ar: 'متوسط',
    desc: 'الطلاقة اليومية والدراسية',
    color: '#2563eb',
    bgClass: 'bg-blue-600',
    textClass: 'text-blue-600 dark:text-blue-400',
  },
  B2: {
    ar: 'فوق المتوسط',
    desc: 'مستوى العمل والجامعة',
    color: '#4f46e5',
    bgClass: 'bg-indigo-600',
    textClass: 'text-indigo-600 dark:text-indigo-400',
  },
  C1: {
    ar: 'متقدم',
    desc: 'إتقان أكاديمي ومهني',
    color: '#7c3aed',
    bgClass: 'bg-violet-600',
    textClass: 'text-violet-600 dark:text-violet-400',
  },
  C2: {
    ar: 'احترافي',
    desc: 'حصيلة لغوية شاملة',
    color: '#e11d48',
    bgClass: 'bg-rose-600',
    textClass: 'text-rose-600 dark:text-rose-400',
  },
};

export const GAMES: GameDef[] = [
  {
    id: 'listen_type',
    name: 'الإملاء الصوتي',
    desc: 'استمع لنطق الكلمة واكتبها بالإنكليزية',
    featured: true,
  },
  { id: 'missing', name: 'الحروف الناقصة', desc: 'أكمل الأحرف المفقودة في الكلمة' },
  { id: 'scramble', name: 'ترتيب الحروف', desc: 'رتّب الحروف المبعثرة لتكوين الكلمة' },
  { id: 'type_en', name: 'اكتب بالإنكليزي', desc: 'تظهر بالعربية وتكتبها بالإنجليزية' },
  { id: 'type_ar', name: 'اكتب بالعربي', desc: 'تظهر بالإنجليزية وتكتب معناها' },
  { id: 'mcq', name: 'اختيار من متعدد', desc: 'اختر الإجابة الصحيحة من 4 خيارات' },
  { id: 'tf', name: 'صح أم خطأ', desc: 'اختبار سريع للترجمة' },
  { id: 'match', name: 'لعبة التوصيل', desc: 'وصّل كل كلمة بترجمتها العربية' },
  { id: 'mixed', name: 'جولة منوّعة', desc: 'مزيج من كل الألعاب معاً', featured: true },
  { id: 'study', name: 'بطاقات أنكي (SRS)', desc: 'فلاش كارد بنظام التكرار المتباعد الذكي' },
];

export const GAME_MAP: Record<GameModeId, GameDef> = GAMES.reduce(
  (acc, game) => {
    acc[game.id] = game;
    return acc;
  },
  {} as Record<GameModeId, GameDef>
);

export const POS_AR: Record<string, string> = {
  noun: 'اسم',
  verb: 'فعل',
  adjective: 'صفة',
  adverb: 'ظرف',
  pronoun: 'ضمير',
  preposition: 'حرف جر',
  conjunction: 'أداة عطف',
  interjection: 'تعجب',
};

export const FUNC_WORDS = new Set([
  'the', 'a', 'an', 'to', 'of', 'in', 'on', 'at', 'by', 'for', 'with', 'from',
  'into', 'onto', 'upon', 'if', 'or', 'and', 'but', 'nor', 'yet', 'so', 'as',
  'than', 'that', 'which', 'who', 'whom', 'whose', 'what', 'this', 'these',
  'those', 'it', 'its', 'he', 'him', 'his', 'she', 'her', 'they', 'them',
  'their', 'we', 'us', 'our', 'you', 'your', 'i', 'me', 'my', 'be', 'is',
  'am', 'are', 'was', 'were', 'been', 'have', 'has', 'had', 'do', 'does',
  'did', 'will', 'would', 'shall', 'should', 'can', 'could', 'may', 'might',
  'must', 'not', 'no', 'yes', 'very', 'too', 'also', 'just', 'only', 'even',
  'still', 'already', 'although', 'though', 'however', 'therefore', 'unless',
  'whereas', 'meanwhile', 'because',
]);

export const BAD_PHOTO_TERMS = [
  'illustration', 'vector', 'clipart', 'icon', 'logo', '3d render',
  'cartoon', 'drawing', 'sketch', 'typography', 'screenshot', 'mockup',
];

export const VOCAB_PLACEHOLDER = '<!-- الصق هنا سطور الكلمات من ملفك الأصلي -->';
