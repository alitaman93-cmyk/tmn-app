const SENTENCE_STOP_WORDS = new Set([
  'a', 'an', 'the', 'i', 'you', 'he', 'she', 'it', 'we', 'they',
  'me', 'him', 'her', 'us', 'them', 'my', 'your', 'his', 'its', 'our', 'their',
  'mine', 'yours', 'hers', 'ours', 'theirs', 'myself', 'yourself', 'himself', 'herself',
  'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
  'do', 'does', 'did', 'done', 'doing',
  'have', 'has', 'had', 'having',
  'will', 'would', 'shall', 'should', 'can', 'could', 'may', 'might', 'must',
  'to', 'of', 'in', 'on', 'at', 'by', 'for', 'with', 'about', 'against', 'between',
  'into', 'through', 'during', 'before', 'after', 'above', 'below', 'from', 'up', 'down',
  'out', 'off', 'over', 'under', 'again', 'further', 'then', 'once',
  'and', 'but', 'or', 'nor', 'so', 'yet', 'if', 'because', 'as', 'until', 'while', 'than',
  'this', 'that', 'these', 'those', 'here', 'there', 'where', 'when', 'why', 'how',
  'what', 'which', 'who', 'whom', 'whose',
  'not', 'no', 'yes', 'very', 'just', 'only', 'also', 'too', 'really', 'quite', 'much', 'many',
  'some', 'any', 'all', 'both', 'each', 'few', 'more', 'most', 'other', 'such', 'own', 'same',
  'now', 'well', 'please', 'okay', 'ok', 'oh', 'hey', 'hi', 'let', 'lets', 'got', 'get',
  'im', 'ive', 'ill', 'id', 'youre', 'youve', 'youll', 'hes', 'shes', 'its', 'were', 'theyre',
  'dont', 'doesnt', 'didnt', 'isnt', 'arent', 'wasnt', 'werent', 'wont', 'cant', 'couldnt',
  'shouldnt', 'wouldnt', 'havent', 'hasnt', 'hadnt', 'thats', 'theres', 'whats',
]);

const CONTRACTION_EXPANSION: Record<string, string> = {
  "i'm": 'am',
  "aren't": 'are',
  "isn't": 'is',
  "wasn't": 'was',
  "weren't": 'were',
  "don't": 'do',
  "doesn't": 'does',
  "didn't": 'did',
  "won't": 'will',
  "can't": 'can',
  "couldn't": 'could',
  "shouldn't": 'should',
  "wouldn't": 'would',
  "haven't": 'have',
  "hasn't": 'has',
  "hadn't": 'had',
  "you're": 'you',
  "we're": 'we',
  "they're": 'they',
  "he's": 'he',
  "she's": 'she',
  "it's": 'it',
  "that's": 'that',
  "there's": 'there',
  "what's": 'what',
};

export interface SentenceVideoTargets {
  primaryQuery: string;
  keywords: string[];
  cleanSentence: string;
}

/**
 * Extracts ranked, real-speech video search targets from an English sentence.
 * Filters out weak function/stop words so `/api/word-clips` finds rich authentic TED/speech clips
 * while also guaranteeing a valid searchable keyword even for ultra-short sentences like "I'm".
 */
export function extractSentenceVideoTargets(rawSentence: string): SentenceVideoTargets {
  const cleanSentence = (rawSentence || '').split('=')[0].replace(/\s+/g, ' ').trim();
  if (!cleanSentence) {
    return { primaryQuery: '', keywords: [], cleanSentence: '' };
  }

  const rawTokens = cleanSentence
    .replace(/[“”"()[\]{}.,!?;:/\\]/g, ' ')
    .split(/\s+/)
    .map((t) => t.replace(/^'+|'+$/g, '').trim())
    .filter(Boolean);

  const seen = new Set<string>();
  const contentWords: Array<{ word: string; score: number; index: number }> = [];

  rawTokens.forEach((token, idx) => {
    const lower = token.toLowerCase();
    const alphaOnly = lower.replace(/[^a-z'-]/g, '');
    const noApos = alphaOnly.replace(/'/g, '');
    if (alphaOnly.length < 3) return;
    if (SENTENCE_STOP_WORDS.has(alphaOnly) || SENTENCE_STOP_WORDS.has(noApos)) return;
    if (seen.has(alphaOnly)) return;
    seen.add(alphaOnly);

    // Prefer rich content words (4–11 letters are ideal for real-speech TED corpus matches)
    let score = Math.min(alphaOnly.length, 10);
    if (alphaOnly.length >= 5 && alphaOnly.length <= 10) score += 3;
    if (alphaOnly.length > 13) score -= 2;
    if (alphaOnly.includes("'")) score -= 2;
    contentWords.push({ word: alphaOnly, score, index: idx });
  });

  // Sort by informativeness descending, keeping sentence order for ties
  contentWords.sort((a, b) => b.score - a.score || a.index - b.index);

  let keywords = contentWords.slice(0, 5).map((item) => item.word);

  // Fallback for very short sentences made mostly of common words (e.g. "I'm", "How are you?", "I am here.")
  if (keywords.length === 0) {
    const fallbackSeen = new Set<string>();
    keywords = rawTokens
      .map((t) => {
        const lower = t.toLowerCase().replace(/[^a-z']/g, '');
        return CONTRACTION_EXPANSION[lower] || lower.replace(/'/g, '');
      })
      .filter((w) => {
        if (w.length < 2 || fallbackSeen.has(w)) return false;
        fallbackSeen.add(w);
        return true;
      })
      .sort((a, b) => b.length - a.length)
      .slice(0, 3);
  }

  // Final safeguard for single-letter sentences
  if (keywords.length === 0 && rawTokens.length > 0) {
    const first = rawTokens[0].toLowerCase().replace(/[^a-z]/g, '');
    if (first) keywords = [first];
  }

  const primaryQuery = keywords[0] || '';
  return {
    primaryQuery,
    keywords,
    cleanSentence,
  };
}
