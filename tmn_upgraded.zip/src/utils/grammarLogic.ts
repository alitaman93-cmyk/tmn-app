import type { CefrBand, GrammarCategoryId, GrammarLesson } from '../types';

export function normalizeGrammarInput(raw: string): string {
  return (raw || '')
    .trim()
    .toLowerCase()
    .replace(/[’`]/g, "'")
    .replace(/[.,!?;:"()]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

const CONTRACTION_PAIRS: Array<[string, string]> = [
  ["don't", 'do not'],
  ["doesn't", 'does not'],
  ["didn't", 'did not'],
  ["isn't", 'is not'],
  ["aren't", 'are not'],
  ["wasn't", 'was not'],
  ["weren't", 'were not'],
  ["haven't", 'have not'],
  ["hasn't", 'has not'],
  ["hadn't", 'had not'],
  ["won't", 'will not'],
  ["can't", 'cannot'],
  ["couldn't", 'could not'],
  ["shouldn't", 'should not'],
  ["wouldn't", 'would not'],
  ["mustn't", 'must not'],
  ["i'm", 'i am'],
  ["you're", 'you are'],
  ["he's", 'he is'],
  ["she's", 'she is'],
  ["it's", 'it is'],
  ["we're", 'we are'],
  ["they're", 'they are'],
  ["i've", 'i have'],
  ["i'll", 'i will'],
];

function expandContractions(norm: string): string {
  let out = norm;
  for (const [shortForm, longForm] of CONTRACTION_PAIRS) {
    out = out.replace(new RegExp(`\\b${shortForm.replace("'", "'")}\\b`, 'g'), longForm);
  }
  return out;
}

/**
 * Checks a user's fill-in-the-blank grammar answer against accepted answers,
 * forgiving case, extra whitespace, punctuation, and standard English contractions.
 */
export function checkFillBlankAnswer(userInput: string, acceptedAnswers: string[]): boolean {
  const normUser = normalizeGrammarInput(userInput);
  if (!normUser) return false;
  const expandedUser = expandContractions(normUser);

  return acceptedAnswers.some((ans) => {
    const normAns = normalizeGrammarInput(ans);
    if (!normAns) return false;
    return normUser === normAns || expandedUser === expandContractions(normAns);
  });
}

/**
 * Splits a grammar target sentence into clean tokens and deterministically shuffles them
 * (guaranteed not to stay in the exact solved order when >= 2 unique tokens exist).
 */
export function buildGrammarReorderTiles(targetSentence: string): {
  targetTokens: string[];
  shuffledTiles: Array<{ id: number; text: string }>;
} {
  const targetTokens = (targetSentence || '')
    .trim()
    .split(/\s+/)
    .filter(Boolean);

  const tiles = targetTokens.map((text, idx) => ({ id: idx, text }));
  if (tiles.length <= 1) {
    return { targetTokens, shuffledTiles: tiles };
  }

  // Deterministic Fisher-Yates seeded by sentence characters so exercises are stable and testable
  let seed = 0;
  for (let i = 0; i < targetSentence.length; i++) {
    seed = (seed * 31 + targetSentence.charCodeAt(i)) >>> 0;
  }

  const out = [...tiles];
  for (let i = out.length - 1; i > 0; i--) {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    const j = seed % (i + 1);
    [out[i], out[j]] = [out[j], out[i]];
  }

  // Ensure it's actually scrambled
  const identical = out.every((t, i) => t.text === targetTokens[i]);
  if (identical && out.length >= 2) {
    [out[0], out[out.length - 1]] = [out[out.length - 1], out[0]];
  }

  return { targetTokens, shuffledTiles: out };
}

export function checkGrammarReorderAnswer(
  selectedTokens: string[],
  targetSentence: string
): boolean {
  const userJoined = normalizeGrammarInput(selectedTokens.join(' '));
  const targetJoined = normalizeGrammarInput(targetSentence);
  return userJoined.length > 0 && userJoined === targetJoined;
}

export function filterGrammarLessons(
  lessons: GrammarLesson[],
  opts: { category?: GrammarCategoryId | 'all'; band?: CefrBand | 'all'; query?: string }
): GrammarLesson[] {
  const q = (opts.query || '').trim().toLowerCase();
  return lessons.filter((lesson) => {
    if (opts.category && opts.category !== 'all' && lesson.category !== opts.category) {
      return false;
    }
    if (opts.band && opts.band !== 'all' && lesson.band !== opts.band) {
      return false;
    }
    if (q) {
      const hay = `${lesson.titleEn} ${lesson.titleAr} ${lesson.formula} ${lesson.summaryAr}`.toLowerCase();
      return hay.includes(q);
    }
    return true;
  });
}

export function computeGrammarMastery(
  totalLessons: number,
  completedIds: string[]
): { completedCount: number; totalCount: number; percent: number } {
  const uniqueCompleted = new Set(completedIds || []).size;
  const safeTotal = Math.max(1, totalLessons);
  return {
    completedCount: Math.min(uniqueCompleted, totalLessons),
    totalCount: totalLessons,
    percent: Math.min(100, Math.round((uniqueCompleted / safeTotal) * 100)),
  };
}
