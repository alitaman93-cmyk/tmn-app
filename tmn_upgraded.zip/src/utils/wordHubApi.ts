import { POS_AR } from '../data/constants';
import type { CefrBand, UiLanguageCode, WordHubData } from '../types';
import { translateViaGtxFast } from './aiApi';
import { fetchWordInfo } from './mediaApi';
import { idbMediaGet, idbMediaSet, lsHotGet } from './storage';
import { sanitizeWordHubData } from './wordHubLogic';

const HUB_TTL_MS = 180 * 24 * 60 * 60 * 1000; // 180 days persistent cache
const HUB_FALLBACK_TTL_MS = 14 * 24 * 60 * 60 * 1000; // 14 days for dictionary-enriched fallback
const hubMemCache = new Map<string, WordHubData>();
const hubInFlight = new Map<string, Promise<WordHubData>>();

function cacheKey(word: string, uiLang: UiLanguageCode): string {
  return `hub_v4:${uiLang}:${word.toLowerCase().trim()}`;
}

async function fetchJsonFast<T>(url: string, timeoutMs = 4000): Promise<T | null> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  } finally {
    window.clearTimeout(timer);
  }
}

interface FreeDictEntry {
  word?: string;
  phonetic?: string;
  phonetics?: Array<{ text?: string; audio?: string }>;
  origin?: string;
  meanings?: Array<{
    partOfSpeech?: string;
    synonyms?: string[];
    antonyms?: string[];
    definitions?: Array<{
      definition?: string;
      example?: string;
      synonyms?: string[];
      antonyms?: string[];
    }>;
  }>;
}

/**
 * Rich multi-source lexicographical builder (Free Dictionary + Datamuse + Wiktionary + fast GTX translation).
 * Guarantees that EVERY word has complete definitions, IPA, US/UK audio, synonyms, antonyms,
 * related words, examples, register info, and memory tip even if AI backend is offline or rate-limited.
 */
async function buildRichDictionaryFallback(
  word: string,
  ar: string,
  band: CefrBand = 'B1',
  backendUrl?: string
): Promise<WordHubData> {
  const cleanWord = word.trim();
  const lower = cleanWord.toLowerCase();
  const encoded = encodeURIComponent(lower);

  const isOnline = typeof navigator === 'undefined' || navigator.onLine !== false;

  let posEn = '';
  let posAr = '';
  let ipaUs = '';
  let ipaUk = '';
  let audioUs = '';
  let audioUk = '';
  let definitionEn = '';
  let wordOrigin = '';
  const secondaryRaw: Array<{ posEn: string; definitionEn: string }> = [];
  const exampleTexts: string[] = [];
  const synSet = new Set<string>();
  const antSet = new Set<string>();
  const relSet = new Set<string>();

  if (isOnline) {
    const [dictData, dmSyn, dmAnt, dmRel, basicInfo] = await Promise.all([
      fetchJsonFast<FreeDictEntry[]>(
        `https://api.dictionaryapi.dev/api/v2/entries/en/${encoded}`,
        4500
      ),
      fetchJsonFast<Array<{ word?: string }>>(
        `https://api.datamuse.com/words?rel_syn=${encoded}&max=6`,
        3500
      ),
      fetchJsonFast<Array<{ word?: string }>>(
        `https://api.datamuse.com/words?rel_ant=${encoded}&max=4`,
        3500
      ),
      fetchJsonFast<Array<{ word?: string }>>(
        `https://api.datamuse.com/words?ml=${encoded}&max=6`,
        3500
      ),
      fetchWordInfo(cleanWord, backendUrl || '', false).catch(() => ({
        status: 'error' as const,
        data: null,
      })),
    ]);

    if (Array.isArray(dictData) && dictData.length > 0) {
      for (const entry of dictData) {
        if (!wordOrigin && entry.origin) wordOrigin = entry.origin;
        for (const p of entry.phonetics || []) {
          const url = p.audio ? (p.audio.startsWith('//') ? `https:${p.audio}` : p.audio) : '';
          const txt = (p.text || '').trim().replace(/^\/|\/$/g, '');
          if (url && /-us\.mp3$/i.test(url)) {
            if (!audioUs) audioUs = url;
            if (!ipaUs && txt) ipaUs = txt;
          } else if (url && /-uk\.mp3$/i.test(url)) {
            if (!audioUk) audioUk = url;
            if (!ipaUk && txt) ipaUk = txt;
          } else if (url && !audioUs) {
            audioUs = url;
          }
          if (txt) {
            if (!ipaUs) ipaUs = txt;
            if (!ipaUk) ipaUk = txt;
          }
        }
        if (!ipaUs && entry.phonetic) ipaUs = entry.phonetic.replace(/^\/|\/$/g, '');
        if (!ipaUk && entry.phonetic) ipaUk = entry.phonetic.replace(/^\/|\/$/g, '');

        for (const m of entry.meanings || []) {
          const rawPos = (m.partOfSpeech || '').toLowerCase();
          if (!posEn && rawPos) {
            posEn = rawPos.charAt(0).toUpperCase() + rawPos.slice(1);
            posAr = POS_AR[rawPos] || posEn;
          }
          for (const s of m.synonyms || []) {
            if (s && s.toLowerCase() !== lower) synSet.add(s);
          }
          for (const a of m.antonyms || []) {
            if (a && a.toLowerCase() !== lower) antSet.add(a);
          }
          for (const d of m.definitions || []) {
            if (d.definition) {
              if (!definitionEn) {
                definitionEn = d.definition;
              } else if (secondaryRaw.length < 3) {
                secondaryRaw.push({
                  posEn: rawPos ? rawPos.charAt(0).toUpperCase() + rawPos.slice(1) : posEn || 'Usage',
                  definitionEn: d.definition,
                });
              }
            }
            if (d.example && exampleTexts.length < 4) {
              let ex = d.example.trim();
              if (!/[.!?]$/.test(ex)) ex += '.';
              ex = ex.charAt(0).toUpperCase() + ex.slice(1);
              if (!exampleTexts.includes(ex)) exampleTexts.push(ex);
            }
            for (const s of d.synonyms || []) {
              if (s && s.toLowerCase() !== lower) synSet.add(s);
            }
            for (const a of d.antonyms || []) {
              if (a && a.toLowerCase() !== lower) antSet.add(a);
            }
          }
        }
      }
    }

    if (Array.isArray(dmSyn)) {
      for (const item of dmSyn) {
        if (item?.word && item.word.toLowerCase() !== lower && !item.word.includes(' ')) {
          synSet.add(item.word);
        }
      }
    }
    if (Array.isArray(dmAnt)) {
      for (const item of dmAnt) {
        if (item?.word && item.word.toLowerCase() !== lower && !item.word.includes(' ')) {
          antSet.add(item.word);
        }
      }
    }
    if (Array.isArray(dmRel)) {
      for (const item of dmRel) {
        if (
          item?.word &&
          item.word.toLowerCase() !== lower &&
          !synSet.has(item.word) &&
          !antSet.has(item.word)
        ) {
          relSet.add(item.word);
        }
      }
    }

    if (basicInfo?.data) {
      if (!ipaUs && basicInfo.data.phonetic) ipaUs = basicInfo.data.phonetic.replace(/^\/|\/$/g, '');
      if (!posEn && basicInfo.data.posEn) posEn = basicInfo.data.posEn;
      if (!posAr && basicInfo.data.posAr) posAr = basicInfo.data.posAr;
      for (const ex of basicInfo.data.examples || []) {
        if (ex.text && exampleTexts.length < 4 && !exampleTexts.includes(ex.text)) {
          exampleTexts.push(ex.text);
        }
      }
    }
  } else {
    // Purely offline: try cached basic wordInfo
    const basic = await fetchWordInfo(cleanWord, backendUrl || '', false).catch(() => ({
      status: 'error' as const,
      data: null,
    }));
    if (basic?.data) {
      ipaUs = (basic.data.phonetic || '').replace(/^\/|\/$/g, '');
      ipaUk = ipaUs;
      posEn = basic.data.posEn || '';
      posAr = basic.data.posAr || '';
      for (const ex of basic.data.examples || []) {
        if (ex.text) exampleTexts.push(ex.text);
      }
    }
  }

  // Batch-translate definitions, examples, synonyms, antonyms, related words into Arabic in ONE ultra-fast GTX call
  const synList = Array.from(synSet).slice(0, 4);
  const antList = Array.from(antSet).slice(0, 3);
  const relList = Array.from(relSet).slice(0, 4);
  const toTranslate: string[] = [];
  if (definitionEn) toTranslate.push(definitionEn);
  if (!ar) toTranslate.push(cleanWord);
  for (const s of secondaryRaw) toTranslate.push(s.definitionEn);
  for (const e of exampleTexts) toTranslate.push(e);
  for (const w of [...synList, ...antList, ...relList]) toTranslate.push(w);
  if (wordOrigin) toTranslate.push(wordOrigin);

  const trMap = isOnline && toTranslate.length > 0 ? await translateViaGtxFast(toTranslate, 'ar') : {};

  const finalAr = ar || trMap[cleanWord] || cleanWord;
  const finalDefAr = (definitionEn && trMap[definitionEn]) || finalAr;

  const examples =
    exampleTexts.length > 0
      ? exampleTexts.map((en) => ({
          en,
          ar: trMap[en] || '',
          register: 'neutral' as const,
        }))
      : [
          {
            en: `Try using "${cleanWord}" in a clear everyday sentence.`,
            ar: `جرّب استخدام كلمة «${cleanWord}» (${finalAr}) في جملة يومية واضحة.`,
            register: 'neutral' as const,
          },
        ];

  const hasRichDict = Boolean(definitionEn || synList.length || antList.length || exampleTexts.length);

  return sanitizeWordHubData(
    {
      word: cleanWord,
      posEn: posEn || 'Word',
      posAr: posAr || 'كلمة',
      ipaUs,
      ipaUk: ipaUk || ipaUs,
      audioUs: audioUs || undefined,
      audioUk: audioUk || audioUs || undefined,
      definitionEn:
        definitionEn ||
        `English ${band} vocabulary word meaning "${finalAr}".`,
      definitionAr: finalDefAr,
      secondaryMeanings: secondaryRaw.map((sec) => ({
        posEn: sec.posEn,
        definitionEn: sec.definitionEn,
        ar: trMap[sec.definitionEn] || finalAr,
      })),
      synonyms: synList.map((w) => ({
        word: w,
        ar: trMap[w] || finalAr,
        nuanceAr: `مرادف قريب في المعنى من كلمة ${cleanWord} (${finalAr}).`,
        exampleEn: '',
        exampleAr: '',
      })),
      antonyms: antList.map((w) => ({
        word: w,
        ar: trMap[w] || w,
        contrastAr: `يعبّر عن المعنى المعاكس لكلمة ${cleanWord} (${finalAr}).`,
        exampleEn: '',
        exampleAr: '',
      })),
      wordFamily: [],
      relatedWords: relList.map((w) => ({
        word: w,
        ar: trMap[w] || w,
        relationAr: `كلمة مرتبطة سياقياً بـ ${cleanWord}`,
      })),
      collocations: [],
      examples,
      commonMistakes: [],
      usageNotes: [
        `تنتمي كلمة «${cleanWord}» إلى مستوى ${band} وتُستخدم بمعنى: ${finalAr}.`,
        'استمع للنطق الأمريكي والبريطاني وكرر الكلمة داخل جملة كاملة لترسيخها في الذاكرة.',
      ],
      formalVsInformal: {
        registerLabel: 'Neutral',
        registerLabelAr: 'محايد (مناسب لمعظم المواقف)',
        noteAr: `يمكن استخدام «${cleanWord}» بشكل طبيعي في المحادثات اليومية والكتابة العامة.`,
      },
      idioms: [],
      phrasalVerbs: [],
      wordOrigin: wordOrigin ? trMap[wordOrigin] || wordOrigin : '',
      memoryTip: `اربط كلمة «${cleanWord}» بصورتها الواقعية وبالمعنى «${finalAr}»، ثم كوّن منها جملة شخصية قصيرة.`,
      source: hasRichDict ? 'dictionary' : 'offline',
    },
    cleanWord,
    finalAr
  );
}

/**
 * Synchronous 0ms cache peek for instant UI rendering without loading skeletons.
 */
export function getCachedWordHubSync(
  word: string,
  uiLang: UiLanguageCode = 'ar'
): WordHubData | null {
  const key = cacheKey(word, uiLang);
  const mem = hubMemCache.get(key);
  if (mem) return mem;
  const hot = lsHotGet<WordHubData>('wordHub', key);
  if (hot && hot.word) {
    hubMemCache.set(key, hot);
    return hot;
  }
  return null;
}

export async function fetchWordHub(params: {
  word: string;
  ar: string;
  band?: CefrBand;
  uiLang?: UiLanguageCode;
  backendUrl?: string;
  force?: boolean;
}): Promise<{ data: WordHubData; offline: boolean }> {
  const cleanWord = String(params.word || '').trim();
  const uiLang: UiLanguageCode = params.uiLang || 'ar';
  const key = cacheKey(cleanWord, uiLang);

  if (!params.force && hubMemCache.has(key)) {
    const hit = hubMemCache.get(key)!;
    return { data: hit, offline: hit.source === 'offline' };
  }

  if (!params.force) {
    const cached =
      (await idbMediaGet<WordHubData>('wordHub', key)) ||
      (await idbMediaGet<WordHubData>('wordInfo', `hub_v3:${uiLang}:${cleanWord.toLowerCase()}`));
    if (cached && cached.word) {
      hubMemCache.set(key, cached);
      return { data: cached, offline: cached.source === 'offline' };
    }
  }

  const existing = hubInFlight.get(key);
  if (existing && !params.force) {
    const data = await existing;
    return { data, offline: data.source === 'offline' };
  }

  const reqPromise = (async (): Promise<WordHubData> => {
    const isOnline = typeof navigator === 'undefined' || navigator.onLine !== false;
    if (isOnline) {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 14_000);
        try {
          const res = await fetch('/api/word-hub', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
            body: JSON.stringify({
              word: cleanWord,
              ar: params.ar,
              band: params.band || 'B1',
              uiLang,
            }),
          });
          if (res.ok) {
            const json = (await res.json()) as Partial<WordHubData>;
            const clean = sanitizeWordHubData(json, cleanWord, params.ar);
            if (clean.definitionEn || clean.synonyms.length > 0 || clean.examples.length > 0) {
              hubMemCache.set(key, clean);
              void idbMediaSet(
                'wordHub',
                key,
                clean,
                clean.source === 'dictionary+ai' ? HUB_TTL_MS : HUB_FALLBACK_TTL_MS
              );
              return clean;
            }
          }
        } finally {
          clearTimeout(timer);
        }
      } catch {
        // Fall through to rich multi-source dictionary fallback
      }
    }

    const fallback = await buildRichDictionaryFallback(
      cleanWord,
      params.ar,
      params.band || 'B1',
      params.backendUrl
    );
    hubMemCache.set(key, fallback);
    if (fallback.source !== 'offline') {
      void idbMediaSet('wordHub', key, fallback, HUB_FALLBACK_TTL_MS);
    }
    return fallback;
  })();

  hubInFlight.set(key, reqPromise);
  try {
    const data = await reqPromise;
    return { data, offline: data.source === 'offline' };
  } finally {
    hubInFlight.delete(key);
  }
}

export function prefetchWordHub(
  word: string,
  ar: string,
  band?: CefrBand,
  uiLang: UiLanguageCode = 'ar'
): void {
  const key = cacheKey(word, uiLang);
  if (hubMemCache.has(key) || hubInFlight.has(key)) return;
  void fetchWordHub({ word, ar, band, uiLang }).catch(() => {});
}
