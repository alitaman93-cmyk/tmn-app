import test from 'node:test';
import assert from 'node:assert/strict';
import { extractSentenceVideoTargets } from './sentenceVideoLogic';

test('extractSentenceVideoTargets picks meaningful content keywords over stop words', () => {
  const res = extractSentenceVideoTargets(
    'Could you tell me how to get to the nearest train station?'
  );
  assert.ok(res.keywords.length >= 3);
  assert.ok(!res.keywords.includes('the'));
  assert.ok(!res.keywords.includes('could'));
  assert.ok(res.keywords.includes('station'));
  assert.ok(res.keywords.includes('nearest') || res.keywords.includes('train'));
  assert.equal(res.primaryQuery, res.keywords[0]);
});

test('extractSentenceVideoTargets handles synonym sentences with = and short greeting sentences', () => {
  const withAlt = extractSentenceVideoTargets('I appreciate your patience. = Thank you for waiting.');
  assert.equal(withAlt.cleanSentence, 'I appreciate your patience.');
  assert.ok(withAlt.keywords.includes('appreciate'));
  assert.ok(withAlt.keywords.includes('patience'));

  const shortGreeting = extractSentenceVideoTargets('How are you?');
  assert.ok(shortGreeting.primaryQuery.length >= 2);
  assert.ok(shortGreeting.keywords.length >= 1);
});

test('extractSentenceVideoTargets returns empty safely for blank input', () => {
  const empty = extractSentenceVideoTargets('   ');
  assert.equal(empty.primaryQuery, '');
  assert.deepEqual(empty.keywords, []);
});
