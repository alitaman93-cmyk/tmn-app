import type {
  CefrBand,
  ListeningBandProgress,
  ListeningLevelConfig,
  ListeningQuizQuestion,
  UiLanguageCode,
  VideoCaptionCue,
} from '../types';

/**
 * 7 CEFR Listening Levels (A0 -> C2) with required listening hours to reach the next level.
 * Each level's catalog fetches real spoken videos whose total duration equals or exceeds requiredHours.
 */
export const LISTENING_LEVELS: ListeningLevelConfig[] = [
  {
    band: 'A0',
    nextBand: 'A1',
    requiredHours: 5,
    minDurationSec: 120,
    maxDurationSec: 420,
    titleAr: 'التأسيس السمعي',
    descAr: 'فيديوهات قصيرة وواضحة جداً لتدريب الأذن على الأصوات والكلمات اليومية الأساسية.',
    topics: ['food', 'animals', 'family', 'music', 'color', 'sleep', 'water', 'smile'],
  },
  {
    band: 'A1',
    nextBand: 'A2',
    requiredHours: 10,
    minDurationSec: 180,
    maxDurationSec: 540,
    titleAr: 'المبتدئ',
    descAr: 'قصص يومية وموضوعات مألوفة عن السفر، الدراسة، الصحة، والحياة اليومية بإيقاع هادئ.',
    topics: ['travel', 'school', 'health', 'home', 'friends', 'sports', 'nature', 'city'],
  },
  {
    band: 'A2',
    nextBand: 'B1',
    requiredHours: 15,
    minDurationSec: 240,
    maxDurationSec: 720,
    titleAr: 'ما قبل المتوسط',
    descAr: 'محادثات وقصص ملهمة عن العادات، العمل، الثقافات، والتجارب الإنسانية بلغة واضحة.',
    topics: ['habits', 'work', 'culture', 'books', 'happiness', 'learning', 'kindness', 'time'],
  },
  {
    band: 'B1',
    nextBand: 'B2',
    requiredHours: 20,
    minDurationSec: 360,
    maxDurationSec: 960,
    titleAr: 'المتوسط',
    descAr: 'محاضرات وعروض ممتعة في علم النفس، التصميم، التعليم، والتكنولوجيا بمتحدثين متنوعين.',
    topics: ['psychology', 'design', 'education', 'creativity', 'memory', 'communication', 'career', 'mind'],
  },
  {
    band: 'B2',
    nextBand: 'C1',
    requiredHours: 25,
    minDurationSec: 480,
    maxDurationSec: 1140,
    titleAr: 'فوق المتوسط',
    descAr: 'مناقشات معمّقة حول الابتكار، المجتمع، القيادة، والعلوم بسرعة حديث طبيعية.',
    topics: ['innovation', 'society', 'leadership', 'science', 'climate', 'technology', 'future', 'energy'],
  },
  {
    band: 'C1',
    nextBand: 'C2',
    requiredHours: 30,
    minDurationSec: 600,
    maxDurationSec: 1400,
    titleAr: 'المتقدم',
    descAr: 'محاضرات فكرية وأكاديمية في الاقتصاد، الطب، الذكاء الاصطناعي، والفلسفة بمفردات غنية.',
    topics: ['economics', 'philosophy', 'medicine', 'artificial intelligence', 'history', 'politics', 'neuroscience', 'ethics'],
  },
  {
    band: 'C2',
    nextBand: null,
    requiredHours: 35,
    minDurationSec: 660,
    maxDurationSec: 1800,
    titleAr: 'الإتقان الكامل',
    descAr: 'خطابات رئيسية ومناظرات عالية المستوى بلهجات طبيعية سريعة وتراكيب بلاغية دقيقة.',
    topics: ['consciousness', 'universe', 'democracy', 'quantum', 'civilization', 'language', 'evolution', 'art'],
  },
];

export const LISTENING_LEVEL_MAP: Record<CefrBand, ListeningLevelConfig> = LISTENING_LEVELS.reduce(
  (acc, item) => {
    acc[item.band] = item;
    return acc;
  },
  {} as Record<CefrBand, ListeningLevelConfig>
);

export const TED_LANG_CODE_MAP: Record<UiLanguageCode, string> = {
  ar: 'ar',
  hi: 'hi',
  zh: 'zh-cn',
  ru: 'ru',
  de: 'de',
  fr: 'fr',
  es: 'es',
  it: 'it',
  pt: 'pt-br',
  sv: 'sv',
};

export function getActiveListeningCue(
  cues: VideoCaptionCue[],
  currentTimeSec: number
): VideoCaptionCue | null {
  if (!cues.length) return null;
  // Binary search for fast O(log n) lookup during video playback
  let lo = 0;
  let hi = cues.length - 1;
  let best: VideoCaptionCue | null = null;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    const cue = cues[mid];
    if (currentTimeSec >= cue.startSec - 0.15 && currentTimeSec <= cue.endSec + 0.2) {
      return cue;
    }
    if (cue.startSec <= currentTimeSec) {
      best = cue;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  if (best && currentTimeSec <= best.endSec + 0.45) {
    return best;
  }
  return null;
}

export function computeListeningLevelProgress(
  config: ListeningLevelConfig,
  progress?: ListeningBandProgress
): {
  watchedSec: number;
  watchedHours: number;
  requiredHours: number;
  remainingHours: number;
  percent: number;
  completedCount: number;
} {
  const watchedSec = Math.max(0, progress?.watchedSec || 0);
  const requiredSec = Math.max(3600, config.requiredHours * 3600);
  const watchedHours = Number((watchedSec / 3600).toFixed(1));
  const remainingHours = Number(Math.max(0, config.requiredHours - watchedSec / 3600).toFixed(1));
  const percent = Math.min(100, Math.round((watchedSec / requiredSec) * 100));
  const completedCount = progress?.completedVideoIds?.length || 0;
  return {
    watchedSec,
    watchedHours,
    requiredHours: config.requiredHours,
    remainingHours,
    percent,
    completedCount,
  };
}

export function formatDurationMMSS(totalSec: number): string {
  const s = Math.max(0, Math.floor(totalSec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const rem = s % 60;
  if (h > 0) {
    return `${h}:${m < 10 ? '0' : ''}${m}:${rem < 10 ? '0' : ''}${rem}`;
  }
  return `${m}:${rem < 10 ? '0' : ''}${rem}`;
}

export function formatTotalHours(totalSec: number): string {
  const hrs = totalSec / 3600;
  return hrs >= 10 ? hrs.toFixed(1) : hrs.toFixed(1);
}

/**
 * Deterministic fallback comprehension quiz builder grounded directly in a video's
 * real title, speaker, and English transcript cues so every video ALWAYS has a quiz.
 */
export function buildFallbackTranscriptQuiz(
  title: string,
  speaker: string,
  cues: VideoCaptionCue[]
): ListeningQuizQuestion[] {
  const fullSentences = cues
    .map((c) => c.text.trim())
    .filter((t) => t.length >= 25 && /[a-zA-Z]/.test(t));

  const cleanTitle = (title || 'this talk').trim();
  const cleanSpeaker = (speaker || 'the speaker').trim();

  const questions: ListeningQuizQuestion[] = [];

  // Q1: Main topic / title comprehension
  questions.push({
    id: 'q1',
    question: `What is the main focus of ${cleanSpeaker}'s talk?`,
    options: [
      cleanTitle,
      'A step-by-step recipe for baking sourdough bread',
      'The rules and scoring system of professional ice hockey',
      'How to repair vintage mechanical wristwatches',
    ],
    correctIndex: 0,
    explanation: `The talk is titled "${cleanTitle}" and centers directly on this topic.`,
  });

  // Extract 3 meaningful content sentences spread across the video for cloze comprehension
  const stopWords = new Set([
    'that', 'this', 'with', 'from', 'they', 'them', 'were', 'have', 'been', 'will',
    'would', 'could', 'should', 'about', 'there', 'their', 'which', 'where', 'when',
    'what', 'your', 'just', 'like', 'into', 'more', 'some', 'than', 'very', 'also',
    'only', 'over', 'such', 'make', 'know', 'think', 'really', 'going', 'because',
  ]);
  const distractorPool = [
    'architecture', 'submarine', 'telescope', 'orchestra', 'calendar', 'mountain',
    'bicycle', 'umbrella', 'painting', 'journal', 'algorithm', 'horizon',
    'compass', 'factory', 'library', 'bridge',
  ];

  const candidateIndices =
    fullSentences.length >= 6
      ? [
          Math.floor(fullSentences.length * 0.18),
          Math.floor(fullSentences.length * 0.45),
          Math.floor(fullSentences.length * 0.72),
          Math.floor(fullSentences.length * 0.88),
        ]
      : fullSentences.map((_, i) => i);

  let qNum = 2;
  const usedTargets = new Set<string>();

  for (const idx of candidateIndices) {
    if (questions.length >= 5) break;
    const line = fullSentences[idx];
    if (!line) continue;

    const words = line.match(/\b[a-zA-Z]{5,14}\b/g) || [];
    const target = words.find(
      (w) => !stopWords.has(w.toLowerCase()) && !usedTargets.has(w.toLowerCase())
    );
    if (!target) continue;
    usedTargets.add(target.toLowerCase());

    const blanked = line.replace(new RegExp(`\\b${target}\\b`), '______');
    const wrongs = distractorPool
      .filter((d) => d.toLowerCase() !== target.toLowerCase())
      .slice((qNum * 3) % 10, (qNum * 3) % 10 + 3);
    while (wrongs.length < 3) {
      wrongs.push(distractorPool[wrongs.length]);
    }

    const correctIndex = qNum % 4;
    const options = [...wrongs];
    options.splice(correctIndex, 0, target);

    questions.push({
      id: `q${qNum}`,
      question: `Listen closely — which word completes this line from the video?\n"${blanked}"`,
      options,
      correctIndex,
      explanation: `In the video, the speaker says: "${line}"`,
    });
    qNum += 1;
  }

  // Ensure at least 4–5 questions even if transcript is short
  if (questions.length < 4) {
    questions.push({
      id: `q${qNum++}`,
      question: `Who is presenting the ideas in "${cleanTitle}"?`,
      options: [
        cleanSpeaker,
        'An automated weather broadcast system',
        'A live football match commentator',
        'An airport flight announcement voice',
      ],
      correctIndex: 0,
      explanation: `${cleanSpeaker} is the presenter of this talk.`,
    });
  }

  return questions.slice(0, 5);
}
