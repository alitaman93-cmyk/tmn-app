import type { UiLanguageCode } from '../types';

export interface ParsedAuthError {
  code: string;
  message: string;
  isUnauthorizedDomain: boolean;
  isProviderDisabled: boolean;
  hostname: string;
}

const REDIRECT_FALLBACK_CODES = new Set([
  'auth/popup-blocked',
  'auth/operation-not-supported-in-this-environment',
]);

export function extractFirebaseErrorCode(err: unknown): string {
  if (!err || typeof err !== 'object') return '';
  const maybeCode = (err as { code?: unknown }).code;
  if (typeof maybeCode === 'string' && maybeCode.trim()) {
    return maybeCode.trim();
  }
  const maybeMsg = (err as { message?: unknown }).message;
  if (typeof maybeMsg === 'string') {
    const match = maybeMsg.match(/auth\/[a-z0-9-]+/i);
    if (match) return match[0].toLowerCase();
  }
  return '';
}

export function shouldUseRedirectFallback(code: string, isInIframe: boolean): boolean {
  if (isInIframe) return false;
  return REDIRECT_FALLBACK_CODES.has(code);
}

export function parseFirebaseAuthError(
  err: unknown,
  lang: UiLanguageCode = 'ar',
  hostname = ''
): ParsedAuthError {
  const code = extractFirebaseErrorCode(err);
  const cleanHost = hostname.trim();
  const isAr = lang === 'ar';

  switch (code) {
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return {
        code,
        message: '',
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
      };

    case 'auth/unauthorized-domain':
      return {
        code,
        isUnauthorizedDomain: true,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? `نطاق الموقع الحالي (${cleanHost || 'هذا النطاق'}) غير مضاف بعد ضمن النطاقات المصرح بها في Firebase Authentication. انسخ النطاق أدناه وأضفه في إعدادات Firebase ثم أعد المحاولة.`
          : `This domain (${cleanHost || 'current domain'}) is not yet listed in Firebase Authentication Authorized Domains. Copy the domain below, add it in Firebase Console, and try again.`,
      };

    case 'auth/popup-blocked':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'قام المتصفح بحظر نافذة تسجيل الدخول المنبثقة. يرجى السماح بالنوافذ المنبثقة (Popups) لهذا الموقع أو فتح التطبيق في متصفح Chrome/Safari مباشرة ثم المحاولة مرة أخرى.'
          : 'Your browser blocked the sign-in popup. Please allow popups for this site and try again.',
      };

    case 'auth/operation-not-supported-in-this-environment':
    case 'auth/web-storage-unsupported':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'هذا المتصفح يمنع تخزين جلسة المصادقة (ملفات تعريف الارتباط/النوافذ المنبثقة). يرجى فتح التطبيق في متصفح عادي مثل Chrome أو Safari بدلاً من المتصفح المدمج.'
          : 'This browser environment blocks authentication storage or popups. Please open the app directly in Chrome or Safari.',
      };

    case 'auth/network-request-failed':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'تعذّر الاتصال بخادم المصادقة. تأكد من اتصال الإنترنت أو أوقف مانع الإعلانات مؤقتاً وحاول مرة أخرى.'
          : 'Network error while contacting the authentication server. Check your connection and try again.',
      };

    case 'auth/account-exists-with-different-credential':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'يوجد حساب مرتبط بهذا البريد الإلكتروني بطريقة تسجيل دخول مختلفة. جرّب تسجيل الدخول بالطريقة السابقة.'
          : 'An account already exists with this email using a different sign-in method.',
      };

    case 'auth/email-already-in-use':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'هذا البريد الإلكتروني مسجّل مسبقاً. يرجى الانتقال إلى تبويب «تسجيل الدخول».'
          : 'This email is already registered. Please switch to Sign In.',
      };

    case 'auth/invalid-email':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'يرجى إدخال بريد إلكتروني صحيح.'
          : 'Please enter a valid email address.',
      };

    case 'auth/weak-password':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'كلمة المرور ضعيفة، يجب أن تتكون من 6 أحرف على الأقل.'
          : 'Password must be at least 6 characters.',
      };

    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.'
          : 'Incorrect email or password.',
      };

    case 'auth/user-disabled':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'تم تعطيل هذا الحساب مؤقتاً. يرجى التواصل مع الدعم.'
          : 'This account has been disabled.',
      };

    case 'auth/too-many-requests':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'محاولات كثيرة متتالية. يرجى الانتظار قليلاً ثم المحاولة مرة أخرى.'
          : 'Too many attempts. Please wait a moment and try again.',
      };

    case 'auth/operation-not-allowed':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: true,
        hostname: cleanHost,
        message: isAr
          ? 'تسجيل الدخول بالبريد وكلمة المرور غير مفعّل بعد في لوحة Firebase. فعّله بضغطة واحدة من الرابط أدناه أو تابع فوراً بحساب Google.'
          : 'Email/Password sign-in is not enabled yet in Firebase Console. Enable it via the link below or continue with Google right now.',
      };

    case 'auth/internal-error':
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? 'حدث خطأ داخلي مؤقت في نافذة Google. تأكد من السماح بملفات تعريف الارتباط والنوافذ المنبثقة ثم أعد المحاولة.'
          : 'Temporary Google sign-in error. Ensure cookies and popups are allowed, then try again.',
      };

    default: {
      const codeSuffix = code ? ` (${code})` : '';
      return {
        code,
        isUnauthorizedDomain: false,
        isProviderDisabled: false,
        hostname: cleanHost,
        message: isAr
          ? `تعذّر إكمال المصادقة حالياً${codeSuffix}. يرجى المحاولة مرة أخرى.`
          : `Authentication could not be completed right now${codeSuffix}. Please try again.`,
      };
    }
  }
}
