import test from 'node:test';
import assert from 'node:assert/strict';
import type { VocabEntry, VocabStore, WordHubData } from '../types';
import {
  buildWordHubGames,
  computeWordMastery,
  findWordInStore,
  sanitizeWordHubData,
} from './wordHubLogic';

const SAMPLE_POOL: VocabEntry[] = [
  { id: 0, band: 'A0', en: 'happy', ar: 'سعيد' },
  { id: 1, band: 'A0', en: 'apple', ar: 'تفاحة' },
  { id: 2, band: 'A1', en: 'river', ar: 'نهر' },
  { id: 3, band: 'A1', en: 'window', ar: 'نافذة' },
  { id: 4, band: 'A2', en: 'careful', ar: 'حذر' },
  { id: 5, band: 'B1', en: 'decision', ar: 'قرار' },
  { id: 6, band: 'B1', en: 'improve', ar: 'يحسّن' },
];

const SAMPLE_STORE: VocabStore = {
  words: SAMPLE_POOL,
  byBand: { A0: [0, 1], A1: [2, 3], A2: [4], B1: [5, 6], B2: [], C1: [], C2: [] },
  normEn: SAMPLE_POOL.map((w) => w.en.toLowerCase()),
  normAr: SAMPLE_POOL.map((w) => w.ar),
};

test('sanitizeWordHubData removes self-referential synonyms, placeholders, and invalid POS', () => {
  const cleaned = sanitizeWordHubData(
    {
      word: 'happy',
      posEn: 'Adjective',
      posAr: 'صفة',
      ipaUs: '/ˈhæpi/',
      ipaUk: '/ˈhæpi/',
      definitionEn: 'Feeling or showing pleasure or contentment.',
      definitionAr: 'شعور بالسرور والرضا',
      synonyms: [
        { word: 'happy', ar: 'سعيد', nuanceAr: 'self', exampleEn: 'I am happy.', exampleAr: 'أنا سعيد' },
        { word: 'glad', ar: 'مسرور', nuanceAr: 'تُستخدم غالباً لحدث معين', exampleEn: 'I am glad to see you.', exampleAr: 'يسرني رؤيتك.' },
        { word: 'N/A', ar: 'لا يوجد', nuanceAr: '', exampleEn: '', exampleAr: '' },
      ],
      antonyms: [
        { word: 'glad', ar: 'مسرور', contrastAr: 'dup syn', exampleEn: '', exampleAr: '' },
        { word: 'sad', ar: 'حزين', contrastAr: 'الشعور المعاكس تماماً', exampleEn: 'He felt sad.', exampleAr: 'شعر بالحزن.' },
      ],
      wordFamily: [
        { word: 'happiness', pos: 'Noun', posAr: 'اسم', ar: 'سعادة', exampleEn: 'Happiness matters.' },
        { word: 'happily', pos: 'Adverb', posAr: 'ظرف', ar: 'بسعادة', exampleEn: 'They lived happily.' },
        // @ts-expect-error testing invalid POS filtering
        { word: 'happyish', pos: 'Slang', posAr: 'عامي', ar: 'شبه سعيد', exampleEn: '' },
      ],
      phrasalVerbs: [
        { phrase: 'singleword', ar: 'ليس فعل مركب', exampleEn: '' },
      ],
      wordOrigin: 'N/A',
      memoryTip: 'اربطها بكلمة Happy Birthday.',
    },
    'happy',
    'سعيد'
  );

  assert.equal(cleaned.ipaUs, 'ˈhæpi');
  assert.equal(cleaned.synonyms.length, 1);
  assert.equal(cleaned.synonyms[0].word, 'glad');
  assert.equal(cleaned.antonyms.length, 1);
  assert.equal(cleaned.antonyms[0].word, 'sad');
  assert.equal(cleaned.wordFamily.length, 2);
  assert.equal(cleaned.phrasalVerbs.length, 0);
  assert.equal(cleaned.wordOrigin, '');
});

test('computeWordMastery requires real practice (viewing alone = 0%) and unlocks at >=70% + 2 activities', () => {
  const empty = computeWordMastery(null);
  assert.equal(empty.scorePct, 0);
  assert.equal(empty.isEarnedMastered, false);

  const oneGame = computeWordMastery({
    wordKey: 'happy',
    completedGames: ['synonym_match'],
    correctAnswers: 2,
    wrongAnswers: 0,
    updatedAt: Date.now(),
  });
  assert.ok(oneGame.scorePct < 70);
  assert.equal(oneGame.isEarnedMastered, false);

  const earned = computeWordMastery({
    wordKey: 'happy',
    completedGames: ['synonym_match', 'definition_quiz'],
    sentencePassed: true,
    correctAnswers: 4,
    wrongAnswers: 0,
    updatedAt: Date.now(),
  });
  assert.ok(earned.scorePct >= 70);
  assert.equal(earned.isEarnedMastered, true);
});

test('buildWordHubGames disables Antonym Challenge when word has no direct antonym (never fabricates)', () => {
  const appleHub: WordHubData = sanitizeWordHubData(
    {
      word: 'apple',
      posEn: 'Noun',
      posAr: 'اسم',
      definitionEn: 'A round fruit with red, yellow, or green skin.',
      definitionAr: 'فاكهة دائرية لذيذة',
      synonyms: [],
      antonyms: [],
      wordFamily: [],
      relatedWords: [
        { word: 'fruit', ar: 'فاكهة', relationAr: 'التصنيف العام' },
        { word: 'orchard', ar: 'بستان', relationAr: 'مكان النمو' },
      ],
      collocations: [
        { phrase: 'apple pie', ar: 'فطيرة تفاح', exampleEn: 'She baked an apple pie.', exampleAr: 'خبزت فطيرة تفاح.' },
      ],
      examples: [
        { en: 'I eat an apple every morning.', ar: 'آكل تفاحة كل صباح.' },
      ],
      commonMistakes: [],
      usageNotes: [],
      idioms: [],
      phrasalVerbs: [],
      wordOrigin: '',
      memoryTip: '',
    },
    'apple',
    'تفاحة'
  );

  const games = buildWordHubGames(appleHub, SAMPLE_POOL[1], SAMPLE_POOL);
  assert.equal(games.length, 8);
  const antGame = games.find((g) => g.id === 'antonym_challenge');
  const synGame = games.find((g) => g.id === 'synonym_match');
  const defGame = games.find((g) => g.id === 'definition_quiz');
  const compGame = games.find((g) => g.id === 'sentence_completion');
  const colGame = games.find((g) => g.id === 'collocation_challenge');

  assert.equal(antGame?.available, false);
  assert.equal(synGame?.available, false);
  assert.equal(defGame?.available, true);
  assert.equal(compGame?.available, true);
  assert.equal(colGame?.available, true);
  assert.ok(compGame!.questions[0].promptEn!.includes('______'));
});

test('buildWordHubGames activates all 8 games when full genuine linguistic data exists', () => {
  const happyHub: WordHubData = sanitizeWordHubData(
    {
      word: 'happy',
      posEn: 'Adjective',
      posAr: 'صفة',
      definitionEn: 'Feeling or showing pleasure or contentment.',
      definitionAr: 'شعور بالسرور والرضا',
      synonyms: [
        { word: 'glad', ar: 'مسرور', nuanceAr: 'لفرح محدد', exampleEn: 'I am glad to help.', exampleAr: 'يسرني المساعدة.' },
        { word: 'cheerful', ar: 'مبتهج', nuanceAr: 'يظهر في المزاج والتصرف', exampleEn: 'She has a cheerful smile.', exampleAr: 'لديها ابتسامة مبتهجة.' },
      ],
      antonyms: [
        { word: 'sad', ar: 'حزين', contrastAr: 'الشعور المعاكس', exampleEn: 'He looked sad.', exampleAr: 'بدا حزيناً.' },
      ],
      wordFamily: [
        { word: 'happiness', pos: 'Noun', posAr: 'اسم', ar: 'سعادة', exampleEn: 'True happiness is peace.' },
        { word: 'happily', pos: 'Adverb', posAr: 'ظرف', ar: 'بسعادة', exampleEn: 'They smiled happily.' },
      ],
      relatedWords: [{ word: 'smile', ar: 'ابتسامة', relationAr: 'تعبير مرتبط بالسعادة' }],
      collocations: [
        { phrase: 'happy ending', ar: 'نهاية سعيدة', exampleEn: 'The movie had a happy ending.', exampleAr: 'الفيلم له نهاية سعيدة.' },
      ],
      examples: [{ en: 'We are very happy with the results.', ar: 'نحن سعداء جداً بالنتائج.' }],
      commonMistakes: [
        { wrong: 'I am very happy for meet you.', right: 'I am very happy to meet you.', noteAr: 'نستخدم to قبل الفعل.' },
      ],
      usageNotes: [],
      idioms: [],
      phrasalVerbs: [],
      wordOrigin: '',
      memoryTip: '',
    },
    'happy',
    'سعيد'
  );

  const games = buildWordHubGames(happyHub, SAMPLE_POOL[0], SAMPLE_POOL);
  assert.equal(games.length, 8);
  for (const g of games) {
    assert.equal(g.available, true, `Expected game ${g.id} to be available`);
  }
});

test('findWordInStore matches case-insensitively and returns null for unknown words', () => {
  const found = findWordInStore(SAMPLE_STORE, '  HAPPY ');
  assert.equal(found?.id, 0);
  assert.equal(found?.en, 'happy');
  assert.equal(findWordInStore(SAMPLE_STORE, 'nonexistentword'), null);
});
