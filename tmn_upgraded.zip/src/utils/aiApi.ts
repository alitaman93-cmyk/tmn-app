import type {
  AiCoachApiResponse,
  CefrBand,
  CoachScenarioId,
  SpeechEvalResult,
} from '../types';

export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      resolve(commaIdx >= 0 ? result.slice(commaIdx + 1) : result);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

/**
 * Ultra-fast direct Google GTX translation fallback (~200-400ms, works even if backend AI is busy or unavailable).
 */
export async function translateViaGtxFast(
  texts: string[],
  targetLang = 'ar',
  signal?: AbortSignal
): Promise<Record<string, string>> {
  const clean = texts.map((t) => t.replace(/\r?\n/g, ' ').trim()).filter(Boolean);
  if (!clean.length) return {};

  const result: Record<string, string> = {};
  const chunkSize = 15;
  const chunks: string[][] = [];
  for (let i = 0; i < clean.length; i += chunkSize) {
    chunks.push(clean.slice(i, i + chunkSize));
  }

  await Promise.all(
    chunks.map(async (chunk) => {
      const joined = chunk.join('\n');
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${encodeURIComponent(
        targetLang
      )}&dt=t&q=${encodeURIComponent(joined)}`;
      const controller = new AbortController();
      const timer = window.setTimeout(() => controller.abort(), 5500);
      const onAbort = () => controller.abort();
      signal?.addEventListener('abort', onAbort, { once: true });
      try {
        const res = await fetch(url, { signal: controller.signal });
        if (!res.ok) return;
        const data = (await res.json()) as unknown[];
        if (Array.isArray(data) && Array.isArray(data[0])) {
          const fullText = (data[0] as unknown[])
            .map((seg) => (Array.isArray(seg) && typeof seg[0] === 'string' ? seg[0] : ''))
            .join('');
          const lines = fullText.split(/\r?\n/);
          chunk.forEach((orig, idx) => {
            const tr = (lines[idx] || '').trim();
            if (tr && tr.toLowerCase() !== orig.toLowerCase()) {
              result[orig] = tr;
            }
          });
        }
      } catch {
        // Ignore single chunk error
      } finally {
        window.clearTimeout(timer);
        signal?.removeEventListener('abort', onAbort);
      }
    })
  );

  return result;
}

export async function translateSentencesBatch(
  sentences: string[],
  signal?: AbortSignal
): Promise<Record<string, string>> {
  const unique = Array.from(new Set(sentences.map((s) => s.trim()).filter(Boolean)));
  if (!unique.length) return {};

  // Race / try fast backend endpoint first (with crisp 6.5s timeout), then immediately fill any gaps via GTX
  let serverResult: Record<string, string> = {};
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 6500);
  const onAbort = () => controller.abort();
  signal?.addEventListener('abort', onAbort, { once: true });

  try {
    const res = await fetch('/api/translate-sentences', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sentences: unique }),
      signal: controller.signal,
    });
    if (res.ok) {
      const data = (await res.json().catch(() => ({}))) as {
        translations?: Record<string, string>;
      };
      if (data.translations && typeof data.translations === 'object') {
        serverResult = data.translations;
      }
    }
  } catch {
    // Fall through to fast GTX fallback
  } finally {
    window.clearTimeout(timer);
    signal?.removeEventListener('abort', onAbort);
  }

  if (signal?.aborted) return serverResult;

  const missing = unique.filter((s) => !serverResult[s]);
  if (missing.length > 0) {
    const gtxResult = await translateViaGtxFast(missing, 'ar', signal);
    serverResult = { ...serverResult, ...gtxResult };
  }

  if (Object.keys(serverResult).length === 0 && !signal?.aborted) {
    throw new Error('تعذر جلب الترجمة العربية حالياً.');
  }
  return serverResult;
}

export async function evaluateSpeechWithAi(params: {
  targetSentence: string;
  spokenText?: string;
  audioBase64?: string;
  audioMimeType?: string;
}): Promise<SpeechEvalResult> {
  const res = await fetch('/api/evaluate-speech', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as Partial<SpeechEvalResult> & {
    error?: string;
  };
  if (!res.ok) {
    throw new Error(data.error || 'تعذر تقييم التسجيل الصوتي.');
  }
  return {
    heardText: data.heardText || params.spokenText || '',
    score: typeof data.score === 'number' ? data.score : 0,
    isMatch: Boolean(data.isMatch),
    feedbackAr: data.feedbackAr || 'تم تقييم النطق.',
    tipAr: data.tipAr || '',
    source: 'ai',
  };
}

export async function sendAiCoachTurn(params: {
  scenario: CoachScenarioId;
  level: CefrBand;
  provider?: 'auto' | 'open' | 'gemini';
  history: Array<{ role: 'user' | 'model'; text: string }>;
  userText?: string;
  audioBase64?: string;
  audioMimeType?: string;
}): Promise<AiCoachApiResponse> {
  const res = await fetch('/api/ai-coach', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as Partial<AiCoachApiResponse> & {
    error?: string;
  };
  if (!res.ok || !data.replyEn) {
    throw new Error(data.error || 'تعذر التواصل مع المدرب الذكي.');
  }
  return {
    userTranscript: data.userTranscript || params.userText || '',
    replyEn: data.replyEn,
    replyAr: data.replyAr || '',
    hasErrors: Boolean(data.hasErrors),
    correctedEn: data.correctedEn || data.userTranscript || params.userText || '',
    explanationAr: data.explanationAr || '',
    betterPhrasing: data.betterPhrasing || '',
    score: typeof data.score === 'number' ? data.score : 85,
    suggestions: Array.isArray(data.suggestions) ? data.suggestions : [],
    providerLabel: data.providerLabel,
  };
}

export async function checkWordSentenceWithAi(params: {
  targetWord: string;
  targetMeaningAr?: string;
  sentence?: string;
  audioBase64?: string;
  audioMimeType?: string;
}): Promise<import('../types').WordSentenceCheckResult> {
  const res = await fetch('/api/check-word-sentence', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as Partial<
    import('../types').WordSentenceCheckResult
  > & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || 'تعذر تصحيح الجملة حالياً.');
  }
  return {
    userSentence: data.userSentence || params.sentence || '',
    containsTargetWord: Boolean(data.containsTargetWord),
    isCorrect: Boolean(data.isCorrect),
    score: typeof data.score === 'number' ? data.score : 0,
    correctedEn: data.correctedEn || data.userSentence || params.sentence || '',
    wrongParts: Array.isArray(data.wrongParts) ? data.wrongParts : [],
    explanationAr: data.explanationAr || '',
    betterExampleEn: data.betterExampleEn || '',
  };
}

export async function evaluateWritingTaskWithAi(params: {
  taskType: 'picture' | 'topic' | 'article_summary';
  level: CefrBand;
  contextTitle: string;
  contextText: string;
  userText?: string;
  audioBase64?: string;
  audioMimeType?: string;
}): Promise<import('../types').WritingEvaluationResult> {
  const res = await fetch('/api/evaluate-writing-task', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as Partial<
    import('../types').WritingEvaluationResult
  > & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || 'تعذر تصحيح الإجابة حالياً.');
  }
  return {
    userText: data.userText || params.userText || '',
    hasErrors: Boolean(data.hasErrors),
    score: typeof data.score === 'number' ? data.score : 80,
    overallFeedbackAr: data.overallFeedbackAr || '',
    contentFeedbackAr: data.contentFeedbackAr || '',
    correctedText: data.correctedText || data.userText || params.userText || '',
    wrongParts: Array.isArray(data.wrongParts) ? data.wrongParts : [],
    sentenceFeedback: Array.isArray(data.sentenceFeedback) ? data.sentenceFeedback : [],
    improvedVersionEn: data.improvedVersionEn || '',
    vocabularyTips: Array.isArray(data.vocabularyTips) ? data.vocabularyTips : [],
    providerLabel: data.providerLabel,
  };
}

export async function generateWritingTopicWithAi(params: {
  level: CefrBand;
  previousTitles?: string[];
}): Promise<import('../types').WritingTopicPrompt> {
  const res = await fetch('/api/generate-topic-prompt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as Partial<
    import('../types').WritingTopicPrompt
  > & { error?: string };
  if (!res.ok || !data.titleEn) {
    throw new Error(data.error || 'تعذر توليد موضوع جديد.');
  }
  return {
    id: data.id || `topic-${Date.now()}`,
    titleEn: data.titleEn,
    titleAr: data.titleAr || data.titleEn,
    promptEn: data.promptEn || '',
    promptAr: data.promptAr || '',
    keywords: Array.isArray(data.keywords) ? data.keywords : [],
    level: data.level || params.level,
  };
}

export async function searchArticlesWithAi(params: {
  query: string;
  level: CefrBand;
  contentType: 'all' | 'article' | 'story' | 'essay';
}): Promise<import('../types').ArticleItem[]> {
  const res = await fetch('/api/articles/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = (await res.json().catch(() => ({}))) as {
    articles?: import('../types').ArticleItem[];
    error?: string;
  };
  if (!res.ok || !Array.isArray(data.articles)) {
    throw new Error(data.error || 'تعذر جلب المقالات حالياً.');
  }
  return data.articles;
}

export async function translateSingleWordWithAi(params: {
  word: string;
  contextSentence?: string;
}): Promise<{ word: string; ar: string; posAr?: string }> {
  try {
    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), 5000);
    try {
      const res = await fetch('/api/translate-word', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
        signal: controller.signal,
      });
      const data = (await res.json().catch(() => ({}))) as {
        word?: string;
        ar?: string;
        posAr?: string;
      };
      if (res.ok && data.ar) {
        return {
          word: data.word || params.word,
          ar: data.ar,
          posAr: data.posAr,
        };
      }
    } finally {
      window.clearTimeout(timer);
    }
  } catch {
    // Fall through to fast GTX translation
  }

  const gtx = await translateViaGtxFast([params.word], 'ar');
  const ar = gtx[params.word.trim()];
  if (ar) {
    return { word: params.word, ar };
  }
  throw new Error('تعذر ترجمة الكلمة.');
}
