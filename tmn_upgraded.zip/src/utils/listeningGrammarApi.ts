import type {
  CefrBand,
  GrammarLesson,
  ListeningCatalogResponse,
  ListeningQuizQuestion,
  ListeningVideoDetail,
  LocalizedGrammarPayload,
  UiLanguageCode,
  VideoCaptionCue,
} from '../types';
import { buildFallbackTranscriptQuiz } from './listeningLogic';
import { enqueueIdleTask, warmImageUrl } from './prefetchEngine';
import { idbMediaGet, idbMediaSet } from './storage';

const catalogMem = new Map<CefrBand, ListeningCatalogResponse>();
const videoMem = new Map<string, ListeningVideoDetail>();
const captionMem = new Map<string, VideoCaptionCue[]>();
const quizMem = new Map<string, ListeningQuizQuestion[]>();
const grammarLocMem = new Map<string, LocalizedGrammarPayload>();

const CATALOG_TTL_MS = 12 * 60 * 60 * 1000;
const QUIZ_TTL_MS = 24 * 60 * 60 * 1000;
const GRAMMAR_LOC_TTL_MS = 14 * 24 * 60 * 60 * 1000;

export async function fetchListeningCatalog(band: CefrBand): Promise<ListeningCatalogResponse> {
  const inRam = catalogMem.get(band);
  if (inRam) return inRam;

  const idbKey = `listening_catalog_v1_${band}`;
  const inIdb = await idbMediaGet<ListeningCatalogResponse>('videos', idbKey);
  if (inIdb && Array.isArray(inIdb.videos) && inIdb.videos.length > 0) {
    catalogMem.set(band, inIdb);
    return inIdb;
  }

  const res = await fetch(`/api/listening/catalog?band=${encodeURIComponent(band)}`);
  if (!res.ok) {
    throw new Error('تعذر تحميل فيديوهات هذا المستوى حالياً.');
  }
  const data = (await res.json()) as ListeningCatalogResponse;
  if (Array.isArray(data.videos) && data.videos.length > 0) {
    catalogMem.set(band, data);
    void idbMediaSet('videos', idbKey, data, CATALOG_TTL_MS);
  }
  return data;
}

export async function fetchListeningVideoDetail(
  slug: string,
  lang: UiLanguageCode
): Promise<ListeningVideoDetail> {
  const existing = videoMem.get(slug);
  if (existing && existing.translatedCues[lang]) {
    return existing;
  }

  const res = await fetch(
    `/api/listening/video?slug=${encodeURIComponent(slug)}&lang=${encodeURIComponent(lang)}`
  );
  if (!res.ok) {
    const errBody = await res.json().catch(() => null);
    throw new Error(errBody?.error || 'تعذر تحميل الفيديو حالياً.');
  }
  const data = (await res.json()) as ListeningVideoDetail;
  if (existing) {
    data.translatedCues = { ...existing.translatedCues, ...data.translatedCues };
  }
  videoMem.set(slug, data);
  if (data.translatedCues[lang]) {
    captionMem.set(`${data.id}::${lang}`, data.translatedCues[lang]);
  }
  return data;
}

export async function fetchListeningCaptions(
  videoId: string,
  slug: string,
  lang: UiLanguageCode
): Promise<VideoCaptionCue[]> {
  const key = `${videoId}::${lang}`;
  const inRam = captionMem.get(key);
  if (inRam) return inRam;

  const vid = videoMem.get(slug);
  if (vid?.translatedCues[lang]?.length) {
    captionMem.set(key, vid.translatedCues[lang]);
    return vid.translatedCues[lang];
  }

  const res = await fetch(
    `/api/listening/captions?videoId=${encodeURIComponent(videoId)}&slug=${encodeURIComponent(
      slug
    )}&lang=${encodeURIComponent(lang)}`
  );
  if (!res.ok) {
    throw new Error('تعذر تحميل الترجمة لهذه اللغة.');
  }
  const data = (await res.json()) as { cues?: VideoCaptionCue[] };
  const cues = Array.isArray(data.cues) ? data.cues : [];
  if (cues.length > 0) {
    captionMem.set(key, cues);
    if (vid) {
      vid.translatedCues[lang] = cues;
    }
  }
  return cues;
}

export async function fetchListeningQuiz(params: {
  videoId: string;
  title: string;
  speaker: string;
  band: CefrBand;
  cues: VideoCaptionCue[];
}): Promise<ListeningQuizQuestion[]> {
  const key = `${params.videoId}::${params.band}`;
  const inRam = quizMem.get(key);
  if (inRam) return inRam;

  const idbKey = `listening_quiz_v1_${key}`;
  const inIdb = await idbMediaGet<ListeningQuizQuestion[]>('videos', idbKey);
  if (Array.isArray(inIdb) && inIdb.length >= 3) {
    quizMem.set(key, inIdb);
    return inIdb;
  }

  try {
    const res = await fetch('/api/listening/quiz', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        videoId: params.videoId,
        title: params.title,
        speaker: params.speaker,
        band: params.band,
        cues: params.cues.slice(0, 120),
      }),
    });
    if (res.ok) {
      const data = (await res.json()) as { questions?: ListeningQuizQuestion[] };
      if (Array.isArray(data.questions) && data.questions.length >= 3) {
        quizMem.set(key, data.questions);
        void idbMediaSet('videos', idbKey, data.questions, QUIZ_TTL_MS);
        return data.questions;
      }
    }
  } catch {
    // Fall through to deterministic transcript quiz
  }

  const fallback = buildFallbackTranscriptQuiz(params.title, params.speaker, params.cues);
  quizMem.set(key, fallback);
  return fallback;
}

export function prefetchListeningVideos(
  slugs: string[],
  posters: string[],
  lang: UiLanguageCode
): void {
  posters.slice(0, 6).forEach((p) => warmImageUrl(p));
  slugs.slice(0, 2).forEach((slug) => {
    if (!slug || videoMem.has(slug)) return;
    enqueueIdleTask(async () => {
      try {
        await fetchListeningVideoDetail(slug, lang);
      } catch {
        // Ignore silent speculative prefetch errors
      }
    });
  });
}

export async function fetchLocalizedGrammarLesson(
  lesson: GrammarLesson,
  uiLang: UiLanguageCode
): Promise<LocalizedGrammarPayload> {
  if (uiLang === 'ar') {
    return {
      title: lesson.titleAr,
      summary: lesson.summaryAr,
      howToUse: lesson.howToUseAr,
      whenToUse: lesson.whenToUseAr,
      mistakeNotes: lesson.commonMistakes.map((m) => m.noteAr),
      exampleNotes: lesson.examples.map((e) => e.ar),
    };
  }

  const key = `${lesson.id}::${uiLang}`;
  const inRam = grammarLocMem.get(key);
  if (inRam) return inRam;

  const idbKey = `grammar_loc_v1_${key}`;
  const inIdb = await idbMediaGet<LocalizedGrammarPayload>('wordInfo', idbKey);
  if (inIdb && inIdb.title && inIdb.summary) {
    grammarLocMem.set(key, inIdb);
    return inIdb;
  }

  const res = await fetch('/api/grammar/localize', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      lessonId: lesson.id,
      uiLang,
      titleEn: lesson.titleEn,
      titleAr: lesson.titleAr,
      summaryAr: lesson.summaryAr,
      howToUseAr: lesson.howToUseAr,
      whenToUseAr: lesson.whenToUseAr,
      mistakeNotesAr: lesson.commonMistakes.map((m) => m.noteAr),
      exampleNotesAr: lesson.examples.map((e) => e.ar),
    }),
  });

  if (!res.ok) {
    return {
      title: lesson.titleEn,
      summary: lesson.summaryAr,
      howToUse: lesson.howToUseAr,
      whenToUse: lesson.whenToUseAr,
      mistakeNotes: lesson.commonMistakes.map((m) => m.noteAr),
      exampleNotes: lesson.examples.map((e) => e.ar),
    };
  }

  const data = (await res.json()) as LocalizedGrammarPayload;
  grammarLocMem.set(key, data);
  void idbMediaSet('wordInfo', idbKey, data, GRAMMAR_LOC_TTL_MS);
  return data;
}
