import type { CefrBand, UiLanguageCode, VocabEntry } from '../types';
import { translateSentencesBatch } from './aiApi';
import { fetchWordInfo, fetchWordPhoto, fetchWordVideoClips } from './mediaApi';
import { extractSentenceVideoTargets } from './sentenceVideoLogic';
import {
  idbGetSentenceTranslations,
  idbLoadDataset,
  idbSaveDataset,
  idbSetSentenceTranslations,
  requestPersistentStorage,
} from './storage';
import { prefetchWordHub } from './wordHubApi';

interface PrefetchOptions {
  backendUrl: string;
  pixabayKey: string;
  unsplashKey: string;
  uiLang?: UiLanguageCode;
}

const queuedWords = new Set<string>();
const queuedVideoWords = new Set<string>();
const queuedSentenceBatches = new Set<string>();
const predecodedUrls = new Set<string>();
const warmedVideoUrls = new Set<string>();
const pendingTasks: Array<() => Promise<void>> = [];
let activeWorkers = 0;
const MAX_CONCURRENT = 6;
const MAX_QUEUE = 160;
let chunksWarmed = false;
let datasetsWarmed = false;

function scheduleFast(fn: () => void): void {
  if (typeof window === 'undefined') return;
  const w = window as unknown as {
    requestIdleCallback?: (cb: () => void, opts?: { timeout?: number }) => number;
  };
  if (typeof w.requestIdleCallback === 'function') {
    w.requestIdleCallback(fn, { timeout: 150 });
  } else {
    window.setTimeout(fn, 25);
  }
}

function drainQueue(): void {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
  while (activeWorkers < MAX_CONCURRENT && pendingTasks.length > 0) {
    const task = pendingTasks.shift();
    if (!task) break;
    activeWorkers += 1;
    void task()
      .catch(() => {})
      .finally(() => {
        activeWorkers -= 1;
        if (pendingTasks.length > 0) {
          scheduleFast(drainQueue);
        }
      });
  }
}

export function enqueueIdleTask(task: () => Promise<void>, highPriority = false): void {
  if (pendingTasks.length >= MAX_QUEUE) {
    if (!highPriority) return;
    pendingTasks.pop();
  }
  if (highPriority) {
    pendingTasks.unshift(task);
  } else {
    pendingTasks.push(task);
  }
  scheduleFast(drainQueue);
}

export function warmImageUrl(url?: string): void {
  if (!url || typeof window === 'undefined' || predecodedUrls.has(url)) return;
  if (url.startsWith('data:')) return;
  predecodedUrls.add(url);
  try {
    const img = new Image();
    img.decoding = 'async';
    img.referrerPolicy = 'no-referrer';
    img.src = url;
  } catch {
    // Ignore
  }
}

/**
 * Aggressively warms the HTTP connection and metadata for an upcoming video URL
 * using a lightweight link prefetch hint so clicking Play or Next starts instantaneously.
 */
export function warmVideoUrl(url?: string): void {
  if (!url || typeof document === 'undefined' || warmedVideoUrls.has(url)) return;
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
  warmedVideoUrls.add(url);
  try {
    const link = document.createElement('link');
    link.rel = 'prefetch';
    link.as = 'video';
    link.href = url;
    link.referrerPolicy = 'no-referrer';
    document.head.appendChild(link);
    // Clean up DOM node after browser registers prefetch
    window.setTimeout(() => {
      try {
        link.remove();
      } catch {
        // Ignore
      }
    }, 30_000);
  } catch {
    // Ignore
  }
}

/**
 * Proactively fetches & caches both full offline TSV datasets (18k words + 21k sentences)
 * into IndexedDB on app startup so the entire core app works 100% offline immediately.
 */
export function prefetchOfflineDatasets(): void {
  if (typeof window === 'undefined' || datasetsWarmed) return;
  datasetsWarmed = true;
  requestPersistentStorage();

  enqueueIdleTask(async () => {
    const existingSent = await idbLoadDataset('sentences-21k.tsv');
    if (!existingSent && navigator.onLine !== false) {
      try {
        const res = await fetch('/sentences-21k.tsv');
        if (res.ok) {
          const text = await res.text();
          if (text.length > 5000) {
            await idbSaveDataset('sentences-21k.tsv', text);
          }
        }
      } catch {
        // Ignore
      }
    }
  });

  enqueueIdleTask(async () => {
    const existingVocab = await idbLoadDataset('vocab-18k.tsv');
    if (!existingVocab && navigator.onLine !== false) {
      try {
        const res = await fetch('/vocab-18k.tsv');
        if (res.ok) {
          const text = await res.text();
          if (text.length > 5000) {
            await idbSaveDataset('vocab-18k.tsv', text);
          }
        }
      } catch {
        // Ignore
      }
    }
  });
}

/**
 * Speculatively prefetches photo + Word Hub profile + dictionary info + video clips + posters
 * for a single word so opening WordDetailView or advancing in games feels 0ms instant.
 */
export function prefetchWordBundle(
  word: Pick<VocabEntry, 'en' | 'ar' | 'band'>,
  options: PrefetchOptions,
  includeInfo = true,
  highPriority = false
): void {
  if (typeof window === 'undefined') return;
  const key = `${word.en.toLowerCase()}::${includeInfo ? 'full' : 'photo'}`;
  if (queuedWords.has(key)) return;
  queuedWords.add(key);

  enqueueIdleTask(async () => {
    const photoRes = await fetchWordPhoto(word.en, 1, options, false, {
      ar: word.ar,
      band: word.band,
    });
    if (photoRes.data?.imageUrl) {
      warmImageUrl(photoRes.data.thumbUrl || photoRes.data.imageUrl);
      if (photoRes.data.imageUrl !== photoRes.data.thumbUrl) {
        warmImageUrl(photoRes.data.imageUrl);
      }
    }
    if (includeInfo) {
      prefetchWordHub(word.en, word.ar, word.band as CefrBand, options.uiLang || 'ar');
      await fetchWordInfo(word.en, options.backendUrl, false);
    }
  }, highPriority);

  if (includeInfo) {
    prefetchWordVideoClips(word.en, highPriority);
  }
}

/**
 * Prefetches up to `limit` upcoming words aggressively (photos, definitions, hubs, and videos).
 */
export function prefetchWordsBatch(
  words: Array<Pick<VocabEntry, 'en' | 'ar' | 'band'>>,
  options: PrefetchOptions,
  limit = 8,
  includeInfo = true
): void {
  if (typeof window === 'undefined' || !words.length) return;
  const slice = words.slice(0, Math.max(1, Math.min(limit, 20)));
  slice.forEach((w, idx) => {
    prefetchWordBundle(w, options, includeInfo, idx < 3);
  });
}

/**
 * Speculatively prefetches the first page of ±3s spoken video clips, poster frames,
 * and warms the first video stream URL so playing clips has near-zero wait.
 */
export function prefetchWordVideoClips(word: string, highPriority = false): void {
  if (typeof window === 'undefined') return;
  if (typeof navigator !== 'undefined' && !navigator.onLine) return;
  const clean = (word || '').trim().toLowerCase();
  if (!clean || queuedVideoWords.has(clean)) return;
  queuedVideoWords.add(clean);

  enqueueIdleTask(async () => {
    const res = await fetchWordVideoClips(clean, 0, false);
    for (const clip of (res.clips || []).slice(0, 4)) {
      if (clip.posterUrl) warmImageUrl(clip.posterUrl);
    }
    if (res.clips?.[0]?.videoUrl) {
      warmVideoUrl(res.clips[0].videoUrl);
    }
  }, highPriority);
}

/**
 * Speculatively prefetches translations AND primary video clips for upcoming sentences
 * and saves them into IndexedDB + localStorage so flipping pages or tapping Videos is instant.
 */
export function prefetchSentenceTranslations(
  sentences: string[],
  alsoPrefetchVideos = true
): void {
  if (typeof window === 'undefined' || !sentences.length) return;
  if (typeof navigator !== 'undefined' && !navigator.onLine) return;
  const clean = sentences.map((s) => s.trim()).filter(Boolean).slice(0, 30);
  if (!clean.length) return;

  const batchKey = clean[0] + '::' + clean.length;
  if (queuedSentenceBatches.has(batchKey)) return;
  queuedSentenceBatches.add(batchKey);

  enqueueIdleTask(async () => {
    const cached = await idbGetSentenceTranslations(clean);
    const missing = clean.filter((s) => !cached[s]);
    if (missing.length > 0) {
      const translated = await translateSentencesBatch(missing);
      if (Object.keys(translated).length > 0) {
        await idbSetSentenceTranslations(translated);
      }
    }
  }, true);

  if (alsoPrefetchVideos) {
    const seenKw = new Set<string>();
    for (const sentence of clean.slice(0, 6)) {
      const targets = extractSentenceVideoTargets(sentence);
      if (targets.primaryQuery && !seenKw.has(targets.primaryQuery)) {
        seenKw.add(targets.primaryQuery);
        prefetchWordVideoClips(targets.primaryQuery, false);
      }
    }
  }
}

/**
 * Speculatively preloads all lazy-loaded route chunks rapidly right after first paint
 * so switching tabs feels instantaneous with zero spinner flash.
 */
export function prefetchSecondaryChunks(loaders: Array<() => Promise<unknown>>): void {
  if (typeof window === 'undefined' || chunksWarmed) return;
  chunksWarmed = true;
  loaders.forEach((loader, idx) => {
    window.setTimeout(() => {
      scheduleFast(() => {
        void loader().catch(() => {});
      });
    }, 80 + idx * 90);
  });
}

export function getPrefetchStats(): { queuedWordsCount: number; pendingTasksCount: number } {
  return {
    queuedWordsCount: queuedWords.size,
    pendingTasksCount: pendingTasks.length,
  };
}
