import type { VideoCaptionCue, WordVideoClip } from '../types';

export interface RawTranscriptCue {
  /** Timestamp in milliseconds from the beginning of the video */
  time: number;
  /** Raw caption text */
  text: string;
}

export interface SourceVideoMeta {
  videoId: string;
  slug: string;
  title: string;
  speaker: string;
  sourceLabel: string;
  videoUrl: string;
  posterUrl: string;
  durationSec: number;
}

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Builds a strict word-boundary regex matching the English word and its natural
 * English inflections (plurals, -ed, -ing, -er, -est, -s, -es, y->ies).
 */
export function buildWordMatchRegex(rawWord: string): RegExp {
  const clean = (rawWord || '')
    .trim()
    .toLowerCase()
    .replace(/^to\s+/, '')
    .replace(/[^a-z0-9'\-\s]/g, '')
    .trim();

  if (!clean) return /\b__never_match__\b/i;

  // Multi-word phrase: match exact phrase with flexible whitespace
  if (clean.includes(' ')) {
    const parts = clean.split(/\s+/).filter(Boolean).map(escapeRegExp);
    return new RegExp(`\\b${parts.join('\\s+')}\\b`, 'i');
  }

  const forms = new Set<string>([clean]);
  if (clean.length >= 3) {
    forms.add(`${clean}s`);
    forms.add(`${clean}es`);
    forms.add(`${clean}ed`);
    forms.add(`${clean}d`);
    forms.add(`${clean}ing`);
    forms.add(`${clean}er`);
    forms.add(`${clean}est`);
    if (clean.endsWith('e') && clean.length >= 4) {
      const stem = clean.slice(0, -1);
      forms.add(`${stem}ing`);
      forms.add(`${stem}ed`);
      forms.add(`${stem}er`);
      forms.add(`${stem}est`);
    }
    if (clean.endsWith('y') && clean.length >= 4 && !/[aeiou]y$/.test(clean)) {
      const stem = clean.slice(0, -1);
      forms.add(`${stem}ies`);
      forms.add(`${stem}ied`);
      forms.add(`${stem}ier`);
      forms.add(`${stem}iest`);
    }
  }

  const ordered = Array.from(forms).sort((a, b) => b.length - a.length);
  return new RegExp(`\\b(${ordered.map(escapeRegExp).join('|')})\\b`, 'i');
}

/**
 * Computes the exact playback clip window:
 * 3 seconds BEFORE the word is spoken and 3 seconds AFTER it is spoken,
 * clamped cleanly to [0, videoDurationSec].
 */
export function computeWordClipWindow(
  wordStartSec: number,
  videoDurationSec: number,
  padBefore = 3,
  padAfter = 3
): {
  startSec: number;
  endSec: number;
  clipDurationSec: number;
  wordOffsetPct: number;
} {
  const safeDur = Math.max(6, Number.isFinite(videoDurationSec) ? videoDurationSec : 120);
  const safeWordSec = Math.max(0, Math.min(safeDur, Number.isFinite(wordStartSec) ? wordStartSec : 0));

  let startSec = Math.max(0, safeWordSec - padBefore);
  let endSec = Math.min(safeDur, safeWordSec + padAfter);

  // Guarantee a clean ~6s window near video boundaries when possible
  if (endSec - startSec < padBefore + padAfter) {
    if (startSec === 0) {
      endSec = Math.min(safeDur, padBefore + padAfter);
    } else if (endSec === safeDur) {
      startSec = Math.max(0, safeDur - (padBefore + padAfter));
    }
  }

  startSec = Number(startSec.toFixed(2));
  endSec = Number(Math.max(startSec + 1.5, endSec).toFixed(2));
  const clipDurationSec = Number((endSec - startSec).toFixed(2));
  const rawPct = clipDurationSec > 0 ? ((safeWordSec - startSec) / clipDurationSec) * 100 : 50;
  const wordOffsetPct = Math.max(5, Math.min(95, Math.round(rawPct)));

  return { startSec, endSec, clipDurationSec, wordOffsetPct };
}

function cleanCaptionText(text: string): string {
  return (text || '')
    .replace(/\r?\n/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Extracts verified, exact-timestamp 6-second clips (±3s around each spoken occurrence)
 * from a video's timed English transcript cues.
 */
export function extractWordClipsFromCues(
  video: SourceVideoMeta,
  rawCues: RawTranscriptCue[],
  targetWord: string,
  maxPerVideo = 4
): WordVideoClip[] {
  if (!video.videoUrl || !rawCues.length) return [];

  const regex = buildWordMatchRegex(targetWord);
  const normalizedCues: VideoCaptionCue[] = rawCues
    .filter((c) => c && typeof c.text === 'string' && Number.isFinite(c.time))
    .map((c, idx, arr) => {
      const startSec = Math.max(0, c.time / 1000);
      const nextSec = arr[idx + 1] ? arr[idx + 1].time / 1000 : startSec + 4.2;
      const endSec = Math.max(startSec + 1.1, Math.min(startSec + 8.5, nextSec));
      return {
        startSec: Number(startSec.toFixed(2)),
        endSec: Number(endSec.toFixed(2)),
        text: cleanCaptionText(c.text),
      };
    })
    .filter((c) => c.text.length > 0);

  if (!normalizedCues.length) return [];

  const results: WordVideoClip[] = [];
  let lastAcceptedWordSec = -999;

  for (let i = 0; i < normalizedCues.length; i++) {
    if (results.length >= maxPerVideo) break;
    const cue = normalizedCues[i];
    const match = regex.exec(cue.text);
    if (!match) continue;

    // Estimate the exact second inside the cue when the target word is spoken
    const charRatio = cue.text.length > 1 ? match.index / cue.text.length : 0.3;
    const cueDur = Math.max(1.0, cue.endSec - cue.startSec);
    const wordStartSec = Number((cue.startSec + charRatio * cueDur).toFixed(2));

    // Keep at least 9 seconds between clips from the same video so clips feel distinct
    if (wordStartSec - lastAcceptedWordSec < 9) continue;
    lastAcceptedWordSec = wordStartSec;

    const { startSec, endSec } = computeWordClipWindow(wordStartSec, video.durationSec, 3, 3);

    // Gather all overlapping synchronized captions inside [startSec, endSec]
    const windowCues = normalizedCues.filter(
      (c) => c.endSec >= startSec + 0.15 && c.startSec <= endSec - 0.15
    );

    const captionText = cue.text;
    results.push({
      id: `${video.videoId}-${Math.round(wordStartSec * 10)}`,
      word: targetWord,
      matchedTerm: match[0],
      videoUrl: video.videoUrl,
      posterUrl: video.posterUrl,
      title: video.title,
      speaker: video.speaker,
      sourceLabel: video.sourceLabel,
      wordStartSec,
      startSec,
      endSec,
      durationSec: video.durationSec,
      captionText,
      cues: windowCues.length > 0 ? windowCues : [cue],
    });
  }

  return results;
}

/**
 * Returns the live English caption line for a given playback time inside a clip.
 */
export function getActiveCaptionAtTime(clip: WordVideoClip, currentTimeSec: number): string {
  if (!clip.cues || clip.cues.length === 0) return clip.captionText;
  const active = clip.cues.find(
    (c) => currentTimeSec >= c.startSec - 0.2 && currentTimeSec <= c.endSec + 0.15
  );
  return active ? active.text : clip.captionText;
}

/**
 * Computes lookahead indices to speculatively preload ahead of user swiping/clicking Next.
 */
export function getNextPrefetchIndices(
  currentIndex: number,
  totalCount: number,
  lookahead = 3
): number[] {
  if (totalCount <= 1) return [];
  const out: number[] = [];
  const safeIdx = Math.max(0, Math.min(currentIndex, totalCount - 1));
  for (let offset = 1; offset <= lookahead; offset++) {
    const idx = safeIdx + offset;
    if (idx < totalCount) out.push(idx);
  }
  if (safeIdx - 1 >= 0) {
    out.push(safeIdx - 1);
  }
  return out;
}

/**
 * Deduplicates clips across paginated server fetches while preserving relevance order.
 */
export function dedupeVideoClips(clips: WordVideoClip[]): WordVideoClip[] {
  const seen = new Set<string>();
  const out: WordVideoClip[] = [];
  for (const clip of clips) {
    const bucketKey = `${clip.videoUrl}::${Math.round(clip.startSec / 4)}`;
    if (seen.has(clip.id) || seen.has(bucketKey)) continue;
    seen.add(clip.id);
    seen.add(bucketKey);
    out.push(clip);
  }
  return out;
}

export function formatSecondsShort(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}:${rem < 10 ? '0' : ''}${rem}`;
}
