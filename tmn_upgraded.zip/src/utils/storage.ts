import type { PersistedSettings } from '../types';

export const STORE_KEY = 'vocab_cefr_android_v3';
const IDB_NAME = 'VocabCefrCustomDB';
const IDB_STORE = 'csvStore';
const MEDIA_DB_NAME = 'VocabCefrMediaDB';
const MEDIA_DB_VERSION = 5;

const LS_HOT_PREFIX = 'tmn_hot_v1::';
const LS_HOT_INDEX_KEY = 'tmn_hot_v1_index';
const LS_HOT_MAX_ENTRIES = 180;
const LS_HOT_MAX_ITEM_BYTES = 28_000;

export type MediaStoreName =
  | 'images'
  | 'wordInfo'
  | 'videos'
  | 'sentencesAr'
  | 'wordHub'
  | 'datasets'
  | 'listening';

const ALL_MEDIA_STORES: MediaStoreName[] = [
  'images',
  'wordInfo',
  'videos',
  'sentencesAr',
  'wordHub',
  'datasets',
  'listening',
];

export function todayStr(): string {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export const DEFAULT_UNSPLASH_ACCESS_KEY: string =
  (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_UNSPLASH_ACCESS_KEY ||
  'ofbUnj5e3vSjfGor04gqVKKkVBTUet-PqtFnRNqWPzI';

export function getDefaultSettings(): PersistedSettings {
  return {
    levelSize: 20,
    dailyGoal: 20,
    todayDate: todayStr(),
    todayCount: 0,
    theme: 'dark',
    uiLang: 'ar',
    sfx: true,
    autoSpeak: false,
    ttsRate: 0.92,
    mcqDir: 'en2ar',
    lastGame: 'missing',
    lastBand: 'A0',
    lastSubLevel: 0,
    xp: 0,
    streak: 0,
    bestStreak: 0,
    completed: {},
    mistakes: [],
    favorites: [],
    mastered: [],
    favoriteSentences: [],
    practicedSentences: [],
    srsCards: {},
    placementResult: null,
    listeningProgress: undefined,
    completedGrammarIds: [],
    savedWordNotes: [],
    wordMastery: {},
    pixabayKey: '',
    unsplashKey: DEFAULT_UNSPLASH_ACCESS_KEY,
    backendUrl: '',
    usingCustom: false,
    customSourceName: '',
  };
}

export function loadPersistedSettings(): PersistedSettings {
  const defaults = getDefaultSettings();
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as Partial<PersistedSettings>;
    const td = todayStr();
    return {
      ...defaults,
      ...parsed,
      unsplashKey:
        typeof parsed.unsplashKey === 'string' && parsed.unsplashKey.trim().length > 0
          ? parsed.unsplashKey
          : defaults.unsplashKey,
      todayDate: td,
      todayCount: parsed.todayDate === td ? parsed.todayCount || 0 : 0,
      completed: parsed.completed && typeof parsed.completed === 'object' ? parsed.completed : {},
      mistakes: Array.isArray(parsed.mistakes) ? parsed.mistakes : [],
      favorites: Array.isArray(parsed.favorites) ? parsed.favorites : [],
      mastered: Array.isArray(parsed.mastered) ? parsed.mastered : [],
      favoriteSentences: Array.isArray(parsed.favoriteSentences) ? parsed.favoriteSentences : [],
      practicedSentences: Array.isArray(parsed.practicedSentences) ? parsed.practicedSentences : [],
      srsCards: parsed.srsCards && typeof parsed.srsCards === 'object' ? parsed.srsCards : {},
      listeningProgress:
        parsed.listeningProgress && typeof parsed.listeningProgress === 'object'
          ? parsed.listeningProgress
          : undefined,
      completedGrammarIds: Array.isArray(parsed.completedGrammarIds)
        ? parsed.completedGrammarIds.filter((x): x is string => typeof x === 'string')
        : [],
      savedWordNotes: Array.isArray(parsed.savedWordNotes) ? parsed.savedWordNotes : [],
      wordMastery:
        parsed.wordMastery && typeof parsed.wordMastery === 'object' ? parsed.wordMastery : {},
      uiLang:
        typeof parsed.uiLang === 'string' &&
        ['ar', 'hi', 'zh', 'ru', 'de', 'fr', 'es', 'it', 'pt', 'sv'].includes(parsed.uiLang)
          ? parsed.uiLang
          : defaults.uiLang,
      placementResult:
        parsed.placementResult && typeof parsed.placementResult === 'object'
          ? parsed.placementResult
          : null,
    };
  } catch {
    return defaults;
  }
}

export function savePersistedSettings(settings: PersistedSettings): void {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(settings));
  } catch {
    // Evict hot cache entries if localStorage is near quota, then retry
    evictHotCacheBatch(40);
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(settings));
    } catch {
      // Ignore storage quota errors
    }
  }
}

// ─── Tier 2: Synchronous localStorage Hot Cache (0ms boot hydration) ─────────

function readHotIndex(): string[] {
  try {
    const raw = localStorage.getItem(LS_HOT_INDEX_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr.filter((x): x is string => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

function writeHotIndex(keys: string[]): void {
  try {
    localStorage.setItem(LS_HOT_INDEX_KEY, JSON.stringify(keys));
  } catch {
    // Ignore
  }
}

function evictHotCacheBatch(count = 25): void {
  try {
    const idx = readHotIndex();
    if (!idx.length) return;
    const toDrop = idx.slice(0, count);
    const keep = idx.slice(count);
    for (const k of toDrop) {
      localStorage.removeItem(LS_HOT_PREFIX + k);
    }
    writeHotIndex(keep);
  } catch {
    // Ignore
  }
}

export function lsHotGet<T>(storeName: MediaStoreName, key: string): T | null {
  if (typeof window === 'undefined') return null;
  try {
    const fullKey = `${storeName}::${key}`;
    const raw = localStorage.getItem(LS_HOT_PREFIX + fullKey);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { data: T; expiresAt?: number };
    if (!parsed || (parsed.expiresAt && parsed.expiresAt <= Date.now())) {
      localStorage.removeItem(LS_HOT_PREFIX + fullKey);
      return null;
    }
    return parsed.data;
  } catch {
    return null;
  }
}

export function lsHotSet<T>(
  storeName: MediaStoreName,
  key: string,
  data: T,
  ttlMs: number
): void {
  if (typeof window === 'undefined') return;
  try {
    const serialized = JSON.stringify({ data, expiresAt: Date.now() + ttlMs });
    if (serialized.length > LS_HOT_MAX_ITEM_BYTES) return;
    const fullKey = `${storeName}::${key}`;
    try {
      localStorage.setItem(LS_HOT_PREFIX + fullKey, serialized);
    } catch {
      evictHotCacheBatch(35);
      try {
        localStorage.setItem(LS_HOT_PREFIX + fullKey, serialized);
      } catch {
        return;
      }
    }
    const idx = readHotIndex().filter((k) => k !== fullKey);
    idx.push(fullKey);
    if (idx.length > LS_HOT_MAX_ENTRIES) {
      const overflow = idx.splice(0, idx.length - LS_HOT_MAX_ENTRIES);
      for (const oldKey of overflow) {
        localStorage.removeItem(LS_HOT_PREFIX + oldKey);
      }
    }
    writeHotIndex(idx);
  } catch {
    // Ignore
  }
}

export function clearHotLocalStorageCache(): void {
  try {
    const idx = readHotIndex();
    for (const k of idx) {
      localStorage.removeItem(LS_HOT_PREFIX + k);
    }
    localStorage.removeItem(LS_HOT_INDEX_KEY);
  } catch {
    // Ignore
  }
}

// ─── Persistent Storage API (asks browser/Android to keep offline cache) ─────

let persistRequested = false;
export function requestPersistentStorage(): void {
  if (persistRequested || typeof navigator === 'undefined') return;
  persistRequested = true;
  try {
    if (navigator.storage && typeof navigator.storage.persist === 'function') {
      void navigator.storage.persist().catch(() => {});
    }
  } catch {
    // Ignore
  }
}

// ─── Custom TSV IDB ──────────────────────────────────────────────────────────

export function idbSaveCustomTSV(tsv: string): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(IDB_STORE)) {
          req.result.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = () => {
        const tx = req.result.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).put(tsv, 'custom_tsv');
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      };
      req.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

export function idbLoadCustomTSV(): Promise<string | null> {
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(IDB_STORE)) {
          req.result.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = () => {
        const tx = req.result.transaction(IDB_STORE, 'readonly');
        const g = tx.objectStore(IDB_STORE).get('custom_tsv');
        g.onsuccess = () => resolve((g.result as string) || null);
        g.onerror = () => resolve(null);
      };
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

export function idbClearCustomTSV(): Promise<boolean> {
  return new Promise((resolve) => {
    try {
      const req = indexedDB.open(IDB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(IDB_STORE)) {
          req.result.createObjectStore(IDB_STORE);
        }
      };
      req.onsuccess = () => {
        const tx = req.result.transaction(IDB_STORE, 'readwrite');
        tx.objectStore(IDB_STORE).delete('custom_tsv');
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      };
      req.onerror = () => resolve(false);
    } catch {
      resolve(false);
    }
  });
}

// ─── Tier 3: Singleton IndexedDB Media & Offline Store (10x faster) ──────────

let mediaDbPromise: Promise<IDBDatabase> | null = null;

function openMediaDB(): Promise<IDBDatabase> {
  if (mediaDbPromise) return mediaDbPromise;
  mediaDbPromise = new Promise((resolve, reject) => {
    try {
      const req = indexedDB.open(MEDIA_DB_NAME, MEDIA_DB_VERSION);
      req.onupgradeneeded = () => {
        ALL_MEDIA_STORES.forEach((s) => {
          if (!req.result.objectStoreNames.contains(s)) {
            req.result.createObjectStore(s);
          }
        });
      };
      req.onsuccess = () => {
        const db = req.result;
        db.onversionchange = () => {
          db.close();
          mediaDbPromise = null;
        };
        db.onclose = () => {
          mediaDbPromise = null;
        };
        resolve(db);
      };
      req.onerror = () => {
        mediaDbPromise = null;
        reject(req.error);
      };
    } catch (e) {
      mediaDbPromise = null;
      reject(e);
    }
  });
  return mediaDbPromise;
}

export async function idbMediaGet<T>(
  storeName: MediaStoreName,
  key: string
): Promise<T | null> {
  // Fast path: check synchronous localStorage hot cache first (0ms)
  const hot = lsHotGet<T>(storeName, key);
  if (hot !== null) return hot;

  try {
    const db = await openMediaDB();
    if (!db.objectStoreNames.contains(storeName)) return null;
    return await new Promise((resolve) => {
      const tx = db.transaction(storeName, 'readonly');
      const g = tx.objectStore(storeName).get(key);
      g.onsuccess = () => {
        const entry = g.result as { data: T; expiresAt?: number } | undefined;
        if (!entry || (entry.expiresAt && entry.expiresAt <= Date.now())) {
          resolve(null);
        } else {
          // Promote warm hit into localStorage hot cache for next reload
          const remaining = entry.expiresAt ? entry.expiresAt - Date.now() : 30 * 864e5;
          if (remaining > 60_000) {
            lsHotSet(storeName, key, entry.data, remaining);
          }
          resolve(entry.data);
        }
      };
      g.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

export async function idbMediaSet<T>(
  storeName: MediaStoreName,
  key: string,
  data: T,
  ttlMs: number
): Promise<boolean> {
  // Mirror into hot localStorage cache (size-guarded)
  if (storeName !== 'datasets') {
    lsHotSet(storeName, key, data, ttlMs);
  }
  try {
    const db = await openMediaDB();
    if (!db.objectStoreNames.contains(storeName)) return false;
    return await new Promise((resolve) => {
      const tx = db.transaction(storeName, 'readwrite');
      tx.objectStore(storeName).put({ data, expiresAt: Date.now() + ttlMs }, key);
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch {
    return false;
  }
}

export async function idbSaveDataset(key: string, content: string): Promise<boolean> {
  return idbMediaSet('datasets', key, content, 365 * 24 * 60 * 60 * 1000);
}

export async function idbLoadDataset(key: string): Promise<string | null> {
  try {
    const db = await openMediaDB();
    if (!db.objectStoreNames.contains('datasets')) return null;
    return await new Promise((resolve) => {
      const tx = db.transaction('datasets', 'readonly');
      const g = tx.objectStore('datasets').get(key);
      g.onsuccess = () => {
        const entry = g.result as { data: string; expiresAt?: number } | undefined;
        resolve(entry && typeof entry.data === 'string' ? entry.data : null);
      };
      g.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

const LS_SENT_MAP_KEY = 'tmn_sent_ar_hot_v1';
const LS_SENT_MAP_MAX = 450;

function readHotSentenceMap(): Record<string, string> {
  try {
    const raw = localStorage.getItem(LS_SENT_MAP_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? (parsed as Record<string, string>) : {};
  } catch {
    return {};
  }
}

function mergeHotSentenceMap(entries: Record<string, string>): void {
  try {
    const existing = readHotSentenceMap();
    const merged: Record<string, string> = { ...existing, ...entries };
    const keys = Object.keys(merged);
    if (keys.length > LS_SENT_MAP_MAX) {
      const trimmed: Record<string, string> = {};
      for (const k of keys.slice(keys.length - LS_SENT_MAP_MAX)) {
        trimmed[k] = merged[k];
      }
      localStorage.setItem(LS_SENT_MAP_KEY, JSON.stringify(trimmed));
    } else {
      localStorage.setItem(LS_SENT_MAP_KEY, JSON.stringify(merged));
    }
  } catch {
    // Ignore quota error
  }
}

export function getHotSentenceTranslationsSync(): Record<string, string> {
  if (typeof window === 'undefined') return {};
  return readHotSentenceMap();
}

export async function idbGetSentenceTranslations(
  keys: string[]
): Promise<Record<string, string>> {
  const result: Record<string, string> = {};
  if (!keys.length) return result;

  // Check localStorage hot sentence map synchronously first
  const hotMap = readHotSentenceMap();
  const missingForIdb: string[] = [];
  for (const key of keys) {
    if (hotMap[key]) {
      result[key] = hotMap[key];
    } else {
      missingForIdb.push(key);
    }
  }
  if (!missingForIdb.length) return result;

  try {
    const db = await openMediaDB();
    await new Promise<void>((resolve) => {
      const tx = db.transaction('sentencesAr', 'readonly');
      const store = tx.objectStore('sentencesAr');
      for (const key of missingForIdb) {
        const req = store.get(key);
        req.onsuccess = () => {
          const entry = req.result as { data: string; expiresAt?: number } | undefined;
          if (
            entry &&
            typeof entry.data === 'string' &&
            (!entry.expiresAt || entry.expiresAt > Date.now())
          ) {
            result[key] = entry.data;
          }
        };
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    // Ignore IDB errors
  }
  return result;
}

export async function idbSetSentenceTranslations(
  entries: Record<string, string>
): Promise<boolean> {
  const pairs = Object.entries(entries).filter(([, v]) => v && v.trim());
  if (!pairs.length) return true;

  mergeHotSentenceMap(Object.fromEntries(pairs.map(([k, v]) => [k, v.trim()])));

  try {
    const db = await openMediaDB();
    const ttl = Date.now() + 365 * 24 * 60 * 60 * 1000; // 1 year offline persistence
    return await new Promise((resolve) => {
      const tx = db.transaction('sentencesAr', 'readwrite');
      const store = tx.objectStore('sentencesAr');
      for (const [k, v] of pairs) {
        store.put({ data: v.trim(), expiresAt: ttl }, k);
      }
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch {
    return false;
  }
}

export async function clearAllMediaCache(): Promise<boolean> {
  clearHotLocalStorageCache();
  try {
    localStorage.removeItem(LS_SENT_MAP_KEY);
  } catch {
    // Ignore
  }
  try {
    const db = await openMediaDB();
    const stores = ALL_MEDIA_STORES.filter((s) => db.objectStoreNames.contains(s));
    if (!stores.length) return true;
    return await new Promise((resolve) => {
      const tx = db.transaction(stores, 'readwrite');
      stores.forEach((s) => tx.objectStore(s).clear());
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch {
    return false;
  }
}
