import {
  Award,
  BookOpen,
  Brain,
  CheckCircle2,
  Flame,
  LogIn,
  MessageSquareText,
  ShieldCheck,
  Sparkles,
  Target,
  Trophy,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { BANDS, BAND_META } from '../data/constants';
import type { PersistedSettings, VocabStore } from '../types';
import { getSrsStats } from '../utils/srsLogic';
import { getBandDoneCount, getBandSubCount } from '../utils/vocabLogic';

interface StatsViewProps {
  store: VocabStore;
  settings: PersistedSettings;
  onStartDueSrsReview: () => void;
  onReviewMistakes: () => void;
  onToast: (msg: string) => void;
}

export function StatsView({
  store,
  settings,
  onStartDueSrsReview,
  onReviewMistakes,
  onToast,
}: StatsViewProps) {
  const { user, signingIn, authError, signInWithGoogle } = useAuth();

  const doneAll = Object.values(settings.completed).filter((p) => p >= 80).length;
  const totalSubsAll = BANDS.reduce(
    (acc, b) => acc + getBandSubCount(store, b, settings.levelSize),
    0
  );
  const goalPct = Math.min(
    100,
    Math.round((settings.todayCount / Math.max(1, settings.dailyGoal)) * 100)
  );
  const srsStats = getSrsStats(settings.srsCards || {});
  const masteredSet = new Set(settings.mastered);

  const handleSignIn = async () => {
    const ok = await signInWithGoogle();
    if (ok) onToast('تم ربط إحصائياتك بحسابك السحابي');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-2xl">
            الإحصائيات وتقدمك الشخصي
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            متابعة شاملة لمستواك في الكلمات والجمل وبطاقات أنكي للتكرار المتباعد
          </p>
        </div>

        {user ? (
          <div className="inline-flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-3.5 py-2 text-xs font-bold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            <span>متزامن مع حساب {user.displayName || 'Google'}</span>
          </div>
        ) : (
          <button
            type="button"
            disabled={signingIn}
            onClick={() => void handleSignIn()}
            className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white transition-colors hover:bg-indigo-700 disabled:opacity-50"
          >
            <LogIn className="h-4 w-4" aria-hidden="true" />
            <span>سجّل الدخول لحفظ إحصائياتك</span>
          </button>
        )}
      </div>

      {authError && !user && (
        <div
          role="alert"
          className="rounded-2xl border border-rose-500/35 bg-rose-500/10 px-4 py-3 text-xs font-bold leading-relaxed text-rose-600 dark:text-rose-300"
        >
          {authError}
        </div>
      )}

      {/* Primary 4-Column KPI Strip (moved from Settings) */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
            <BookOpen className="h-4 w-4" aria-hidden="true" />
          </div>
          <div className="font-code text-2xl font-extrabold tabular-nums text-slate-900 dark:text-slate-100">
            {store.words.length.toLocaleString('en-US')}
          </div>
          <div className="mt-0.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
            إجمالي الكلمات
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400">
            <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
          </div>
          <div className="font-code text-2xl font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
            {settings.mastered.length.toLocaleString('en-US')}
          </div>
          <div className="mt-0.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
            كلمات متقنة
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-amber-50 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400">
            <Sparkles className="h-4 w-4" aria-hidden="true" />
          </div>
          <div className="font-code text-2xl font-extrabold tabular-nums text-amber-600 dark:text-amber-400">
            {settings.xp.toLocaleString('en-US')}
          </div>
          <div className="mt-0.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
            نقاط XP
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 text-center dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="mx-auto mb-2 flex h-9 w-9 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-400">
            <Award className="h-4 w-4" aria-hidden="true" />
          </div>
          <div className="font-code text-2xl font-extrabold tabular-nums text-indigo-600 dark:text-indigo-400">
            {doneAll}/{totalSubsAll}
          </div>
          <div className="mt-0.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
            مستويات مكتملة
          </div>
        </div>
      </section>

      {/* Secondary Activity & Anki SRS Metrics */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>هدف اليوم</span>
            <Target className="h-4 w-4 text-indigo-500" aria-hidden="true" />
          </div>
          <div className="mt-2 font-code text-xl font-extrabold tabular-nums text-slate-900 dark:text-slate-100">
            {settings.todayCount} / {settings.dailyGoal}
          </div>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
            <div
              className="h-full rounded-full bg-indigo-600 dark:bg-indigo-500"
              style={{ width: `${goalPct}%` }}
            />
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>أفضل سلسلة</span>
            <Trophy className="h-4 w-4 text-amber-500" aria-hidden="true" />
          </div>
          <div className="mt-2 font-code text-xl font-extrabold tabular-nums text-slate-900 dark:text-slate-100">
            {settings.bestStreak}
          </div>
          <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            الحالية: <span className="font-code font-bold tabular-nums">{settings.streak}</span>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>بطاقات أنكي (SRS)</span>
            <Brain className="h-4 w-4 text-cyan-500" aria-hidden="true" />
          </div>
          <div className="mt-2 font-code text-xl font-extrabold tabular-nums text-slate-900 dark:text-slate-100">
            {srsStats.totalTracked}
          </div>
          <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            مستحقة الآن:{' '}
            <span className="font-code font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
              {srsStats.dueNow}
            </span>{' '}
            · راسخة: <span className="font-code font-bold tabular-nums">{srsStats.mature}</span>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400">
            <span>الجمل والأخطاء</span>
            <MessageSquareText className="h-4 w-4 text-emerald-500" aria-hidden="true" />
          </div>
          <div className="mt-2 font-code text-xl font-extrabold tabular-nums text-slate-900 dark:text-slate-100">
            {(settings.practicedSentences || []).length} جملة
          </div>
          <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
            بنك الأخطاء:{' '}
            <span className="font-code font-bold text-rose-600 dark:text-rose-400 tabular-nums">
              {settings.mistakes.length}
            </span>{' '}
            · المفضلة:{' '}
            <span className="font-code font-bold tabular-nums">{settings.favorites.length}</span>
          </div>
        </div>
      </section>

      {/* Quick Action Row */}
      {(srsStats.dueNow > 0 || settings.mistakes.length > 0) && (
        <div className="flex flex-wrap items-center gap-3">
          {srsStats.dueNow > 0 && (
            <button
              type="button"
              onClick={onStartDueSrsReview}
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white hover:bg-indigo-700"
            >
              <Brain className="h-4 w-4" aria-hidden="true" />
              <span>راجع بطاقات أنكي المستحقة ({srsStats.dueNow})</span>
            </button>
          )}
          {settings.mistakes.length > 0 && (
            <button
              type="button"
              onClick={onReviewMistakes}
              className="inline-flex h-11 items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-5 text-sm font-bold text-rose-700 hover:bg-rose-100 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300"
            >
              <Flame className="h-4 w-4" aria-hidden="true" />
              <span>تدرّب على بنك الأخطاء ({settings.mistakes.length})</span>
            </button>
          )}
        </div>
      )}

      {/* CEFR A0–C2 Band Progress Breakdown */}
      <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]">
        <h2 className="mb-4 text-base font-extrabold text-slate-900 dark:text-slate-100">
          تقدمك حسب مستويات الكلمات (CEFR A0–C2)
        </h2>
        <div className="space-y-4">
          {BANDS.map((band) => {
            const meta = BAND_META[band];
            const bandIndices = store.byBand[band];
            const masteredInBand = bandIndices.filter((id) => masteredSet.has(id)).length;
            const subTot = getBandSubCount(store, band, settings.levelSize);
            const subDone = getBandDoneCount(store, band, settings.levelSize, settings.completed);
            const wordPct = Math.round((masteredInBand / Math.max(1, bandIndices.length)) * 100);

            return (
              <div key={band} className="space-y-1.5">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span
                      className={`inline-flex h-6 w-9 items-center justify-center rounded-md font-en text-xs font-extrabold text-white ${meta.bgClass}`}
                    >
                      {band}
                    </span>
                    <span className="font-bold text-slate-900 dark:text-slate-100">{meta.ar}</span>
                    <span className="text-slate-500 dark:text-slate-400">
                      ({masteredInBand.toLocaleString('en-US')} /{' '}
                      {bandIndices.length.toLocaleString('en-US')} كلمة متقنة)
                    </span>
                  </div>
                  <div className="font-code font-bold tabular-nums text-slate-600 dark:text-slate-300">
                    مستويات مكتملة: {subDone}/{subTot} ({wordPct}%)
                  </div>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${meta.bgClass}`}
                    style={{ width: `${wordPct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
