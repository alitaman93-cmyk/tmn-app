import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Film,
  Loader2,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  RefreshCw,
  RotateCcw,
  Subtitles,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import type { UiLanguageCode, WordVideoClip } from '../types';
import { getVideoReelsStrings } from '../i18n/videoReelsStrings';
import {
  fetchWordVideoClips,
  getCachedWordVideoClipsSync,
  getProxiedVideoUrl,
} from '../utils/mediaApi';
import { warmImageUrl, warmVideoUrl } from '../utils/prefetchEngine';
import {
  buildWordMatchRegex,
  computeWordClipWindow,
  dedupeVideoClips,
  getActiveCaptionAtTime,
  getNextPrefetchIndices,
} from '../utils/videoClipLogic';

interface WordVideoReelsPlayerProps {
  word: string;
  meaningAr?: string;
  uiLang?: UiLanguageCode;
}

const TARGET_MIN_CLIPS = 50;

function HighlightedCaption({ text, targetWord }: { text: string; targetWord: string }) {
  const parts = useMemo(() => {
    const cleanText = text || '';
    if (!cleanText || !targetWord) return [{ text: cleanText, match: false }];
    const baseRegex = buildWordMatchRegex(targetWord);
    const globalRegex = new RegExp(baseRegex.source, 'gi');
    const out: Array<{ text: string; match: boolean }> = [];
    let lastIdx = 0;
    let m: RegExpExecArray | null = null;
    while ((m = globalRegex.exec(cleanText)) !== null) {
      if (m.index > lastIdx) {
        out.push({ text: cleanText.slice(lastIdx, m.index), match: false });
      }
      out.push({ text: m[0], match: true });
      lastIdx = m.index + m[0].length;
      if (m[0].length === 0) break;
    }
    if (lastIdx < cleanText.length) {
      out.push({ text: cleanText.slice(lastIdx), match: false });
    }
    return out.length > 0 ? out : [{ text: cleanText, match: false }];
  }, [text, targetWord]);

  return (
    <span className="font-en" dir="ltr">
      {parts.map((part, idx) =>
        part.match ? (
          <mark
            key={idx}
            className="rounded bg-amber-400/95 px-1 py-0.5 font-extrabold text-slate-950 shadow-sm"
          >
            {part.text}
          </mark>
        ) : (
          <span key={idx}>{part.text}</span>
        )
      )}
    </span>
  );
}

interface ReelsSlideProps {
  clip: WordVideoClip;
  index: number;
  totalCount: number;
  isActive: boolean;
  shouldMountVideo: boolean;
  isPlaying: boolean;
  isMuted: boolean;
  showCaptions: boolean;
  targetWord: string;
  tapToPlayLabel: string;
  onTogglePlay: () => void;
  onSyncTime: (sec: number) => void;
  onNext: () => void;
  onPrev: () => void;
  onToggleCaptions: () => void;
  onToggleMute: () => void;
  onReplay: () => void;
  strings: ReturnType<typeof getVideoReelsStrings>;
}

function ReelsSlide({
  clip,
  index,
  totalCount,
  isActive,
  shouldMountVideo,
  isPlaying,
  isMuted,
  showCaptions,
  targetWord,
  tapToPlayLabel,
  onTogglePlay,
  onSyncTime,
  onNext,
  onPrev,
  onToggleCaptions,
  onToggleMute,
  onReplay,
  strings,
}: ReelsSlideProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [slideTime, setSlideTime] = useState(clip.startSec);
  const [isBuffering, setIsBuffering] = useState(false);
  const [useProxy, setUseProxy] = useState(false);
  const resolvedSrc = useProxy ? getProxiedVideoUrl(clip.videoUrl) : clip.videoUrl;

  const windowInfo = useMemo(
    () => computeWordClipWindow(clip.wordStartSec, clip.durationSec, 3, 3),
    [clip.wordStartSec, clip.durationSec]
  );

  const seekToStart = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    try {
      v.currentTime = clip.startSec;
      setSlideTime(clip.startSec);
      if (isActive) onSyncTime(clip.startSec);
    } catch {
      // Ignore seek errors before metadata loads
    }
  }, [clip.startSec, isActive, onSyncTime]);

  // Synchronize play / pause / mute when slide becomes active or inactive
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !isActive || isMuted;

    if (!isActive) {
      if (!v.paused) v.pause();
      if (v.readyState >= 1 && Math.abs(v.currentTime - clip.startSec) > 0.4) {
        try {
          v.currentTime = clip.startSec;
        } catch {
          // Ignore
        }
      }
      return;
    }

    if (isPlaying) {
      if (v.readyState >= 1 && (v.currentTime < clip.startSec - 0.25 || v.currentTime >= clip.endSec - 0.1)) {
        try {
          v.currentTime = clip.startSec;
        } catch {
          // Ignore
        }
      }
      const p = v.play();
      if (p && typeof p.catch === 'function') {
        p.catch(() => {
          // Browser autoplay guard if needed
        });
      }
    } else if (!v.paused) {
      v.pause();
    }
  }, [isActive, isPlaying, isMuted, clip.startSec, clip.endSec]);

  // Tight 80ms loop guard so the ±3s window repeats crisply without overshooting
  useEffect(() => {
    if (!isActive || !isPlaying) return;
    const timer = window.setInterval(() => {
      const v = videoRef.current;
      if (!v || v.paused) return;
      const t = v.currentTime;
      setSlideTime(t);
      onSyncTime(t);
      if (t >= clip.endSec - 0.08) {
        v.currentTime = clip.startSec;
        setSlideTime(clip.startSec);
        onSyncTime(clip.startSec);
      }
    }, 80);
    return () => window.clearInterval(timer);
  }, [isActive, isPlaying, clip.startSec, clip.endSec, onSyncTime]);

  const progressPct = useMemo(() => {
    const span = Math.max(0.5, clip.endSec - clip.startSec);
    return Math.max(0, Math.min(100, ((slideTime - clip.startSec) / span) * 100));
  }, [slideTime, clip.startSec, clip.endSec]);

  const activeCaption = useMemo(
    () => getActiveCaptionAtTime(clip, slideTime),
    [clip, slideTime]
  );

  return (
    <div
      data-reel-index={index}
      className="relative flex h-[100dvh] w-full shrink-0 snap-start snap-always items-center justify-center overflow-hidden bg-black select-none"
    >
      {/* Main cinema frame inside fullscreen Reels */}
      <div
        className="relative flex h-full w-full max-w-5xl items-center justify-center"
        onClick={() => {
          const v = videoRef.current;
          if (v && isActive) {
            if (!isPlaying) {
              v.muted = isMuted;
              if (v.readyState >= 1 && (v.currentTime < clip.startSec - 0.3 || v.currentTime >= clip.endSec - 0.1)) {
                try { v.currentTime = clip.startSec; } catch { /* ignore */ }
              }
              const p = v.play();
              if (p && typeof p.catch === 'function') {
                p.catch(() => {
                  v.muted = true;
                  void v.play().catch(() => {});
                });
              }
            } else if (!v.paused) {
              v.pause();
            }
          }
          onTogglePlay();
        }}
      >
        {shouldMountVideo ? (
          <video
            ref={videoRef}
            src={resolvedSrc}
            poster={clip.posterUrl || undefined}
            playsInline
            preload="auto"
            referrerPolicy="no-referrer"
            muted={!isActive || isMuted}
            onLoadedMetadata={() => {
              const v = videoRef.current;
              if (!v) return;
              if (Math.abs(v.currentTime - clip.startSec) > 0.35) {
                try {
                  v.currentTime = clip.startSec;
                } catch {
                  // Ignore
                }
              }
              if (isActive && isPlaying) {
                void v.play().catch(() => {
                  v.muted = true;
                  void v.play().catch(() => {});
                });
              }
            }}
            onError={() => {
              if (!useProxy) {
                setUseProxy(true);
              } else if (isActive) {
                setIsBuffering(false);
                onNext();
              }
            }}
            onWaiting={() => setIsBuffering(true)}
            onPlaying={() => setIsBuffering(false)}
            onCanPlay={() => setIsBuffering(false)}
            onTimeUpdate={() => {
              const v = videoRef.current;
              if (!v || !isActive) return;
              if (v.currentTime >= clip.endSec - 0.08) {
                v.currentTime = clip.startSec;
                setSlideTime(clip.startSec);
                onSyncTime(clip.startSec);
                return;
              }
              setSlideTime(v.currentTime);
              onSyncTime(v.currentTime);
            }}
            onEnded={() => {
              if (!isActive) return;
              seekToStart();
              if (isPlaying) {
                void videoRef.current?.play().catch(() => {});
              }
            }}
            className="max-h-[100dvh] w-full object-contain"
          />
        ) : clip.posterUrl ? (
          <img
            src={clip.posterUrl}
            alt={clip.title}
            loading="lazy"
            referrerPolicy="no-referrer"
            className="max-h-[100dvh] w-full object-contain opacity-80"
          />
        ) : (
          <div className="flex h-64 w-full items-center justify-center text-slate-500">
            <Film className="h-12 w-12" />
          </div>
        )}

        {/* Top & Bottom legibility scrims */}
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-black/80 via-black/35 to-transparent"
          aria-hidden="true"
        />
        <div
          className="pointer-events-none absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-black/90 via-black/55 to-transparent"
          aria-hidden="true"
        />

        {/* Center Play overlay when paused */}
        {isActive && !isPlaying && (
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/25">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white/95 text-slate-950 shadow-2xl">
              <Play className="h-7 w-7 translate-x-0.5 fill-current" aria-hidden="true" />
            </div>
            <span className="rounded-lg bg-black/70 px-3 py-1.5 text-xs font-bold text-white backdrop-blur-sm">
              {tapToPlayLabel}
            </span>
          </div>
        )}

        {/* Buffering indicator */}
        {isActive && isPlaying && isBuffering && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-black/65 text-white backdrop-blur-sm">
              <Loader2 className="h-6 w-6 animate-spin" aria-hidden="true" />
            </div>
          </div>
        )}
      </div>

      {/* Right-hand Instagram Reels vertical action rail */}
      <div
        className="absolute bottom-24 end-3 z-20 flex flex-col items-center gap-2.5 sm:end-6"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onPrev}
          disabled={index <= 0}
          aria-label={strings.prev}
          className="flex h-11 w-11 items-center justify-center rounded-full bg-black/55 text-white backdrop-blur-md transition hover:bg-black/80 disabled:opacity-35"
        >
          <ChevronUp className="h-5 w-5" aria-hidden="true" />
        </button>

        <button
          type="button"
          onClick={onTogglePlay}
          aria-label={isPlaying ? strings.pause : strings.play}
          className="flex h-12 w-12 items-center justify-center rounded-full bg-white/95 text-slate-950 shadow-lg transition hover:scale-105"
        >
          {isPlaying ? (
            <Pause className="h-5 w-5 fill-current" aria-hidden="true" />
          ) : (
            <Play className="h-5 w-5 translate-x-0.5 fill-current" aria-hidden="true" />
          )}
        </button>

        <button
          type="button"
          onClick={() => {
            seekToStart();
            onReplay();
          }}
          aria-label={strings.replay}
          className="flex h-11 w-11 items-center justify-center rounded-full bg-black/55 text-white backdrop-blur-md transition hover:bg-black/80"
        >
          <RotateCcw className="h-5 w-5" aria-hidden="true" />
        </button>

        <button
          type="button"
          onClick={onToggleCaptions}
          aria-label={showCaptions ? strings.captionsOn : strings.captionsOff}
          className={`flex h-11 w-11 items-center justify-center rounded-full backdrop-blur-md transition ${
            showCaptions
              ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
              : 'bg-black/55 text-white/75 hover:bg-black/80'
          }`}
        >
          <Subtitles className="h-5 w-5" aria-hidden="true" />
        </button>

        <button
          type="button"
          onClick={onToggleMute}
          aria-label={isMuted ? strings.unmute : strings.mute}
          className="flex h-11 w-11 items-center justify-center rounded-full bg-black/55 text-white backdrop-blur-md transition hover:bg-black/80"
        >
          {isMuted ? (
            <VolumeX className="h-5 w-5" aria-hidden="true" />
          ) : (
            <Volume2 className="h-5 w-5" aria-hidden="true" />
          )}
        </button>

        <button
          type="button"
          onClick={onNext}
          disabled={index >= totalCount - 1}
          aria-label={strings.next}
          className="flex h-11 w-11 items-center justify-center rounded-full bg-black/55 text-white backdrop-blur-md transition hover:bg-black/80 disabled:opacity-35"
        >
          <ChevronDown className="h-5 w-5" aria-hidden="true" />
        </button>
      </div>

      {/* Bottom captions + talk metadata + ±3s progress bar */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 mx-auto max-w-3xl px-4 pb-5 pe-16 sm:px-6 sm:pe-20">
        {showCaptions && activeCaption && (
          <div
            data-testid={isActive ? 'video-fs-caption-box' : undefined}
            className="mb-3 rounded-xl bg-black/75 px-4 py-2.5 text-center text-base font-semibold leading-relaxed text-white shadow-lg backdrop-blur-md sm:text-lg"
            dir="ltr"
          >
            <HighlightedCaption text={activeCaption} targetWord={targetWord} />
          </div>
        )}

        <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-200">
          <div className="min-w-0 truncate">
            <span className="font-bold text-white">{clip.speaker}</span>
            <span className="mx-1.5 text-slate-400">·</span>
            <span className="text-slate-300" dir="ltr">
              {clip.title}
            </span>
          </div>
          <span className="shrink-0 font-en font-bold text-amber-300" dir="ltr">
            {index + 1} / {totalCount} · {strings.windowLabel}
          </span>
        </div>

        {/* ±3s Loop Progress Track with exact spoken-word marker */}
        <div dir="ltr" className="relative mt-2.5 h-1.5 w-full overflow-hidden rounded-full bg-white/25">
          <div
            className="h-full rounded-full bg-amber-400 transition-[width] duration-75"
            style={{ width: `${progressPct}%` }}
          />
          <div
            className="absolute top-0 bottom-0 w-1 rounded-full bg-white shadow"
            style={{ left: `${windowInfo.wordOffsetPct}%` }}
            title={targetWord}
          />
        </div>
      </div>
    </div>
  );
}

export function WordVideoReelsPlayer({ word, meaningAr, uiLang = 'ar' }: WordVideoReelsPlayerProps) {
  const strings = useMemo(() => getVideoReelsStrings(uiLang), [uiLang]);

  const initialCached = useMemo(() => getCachedWordVideoClipsSync(word, 0), [word]);
  const [clips, setClips] = useState<WordVideoClip[]>(() =>
    initialCached?.clips ? dedupeVideoClips(initialCached.clips) : []
  );
  const [activeIdx, setActiveIdx] = useState(0);
  // MUST start paused / OFF when entering a word
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showCaptions, setShowCaptions] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const [loading, setLoading] = useState(() => !(initialCached?.clips && initialCached.clips.length > 0));
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(() => initialCached?.hasMore ?? true);
  const [nextPage, setNextPage] = useState(1);
  const [currentTimeSec, setCurrentTimeSec] = useState(() => initialCached?.clips?.[0]?.startSec ?? 0);
  const [buffering, setBuffering] = useState(false);
  const [proxiedClipIds, setProxiedClipIds] = useState<Record<string, boolean>>({});
  const [clipErrorMsg, setClipErrorMsg] = useState('');

  const inlineVideoRef = useRef<HTMLVideoElement | null>(null);
  const fullscreenOverlayRef = useRef<HTMLDivElement | null>(null);
  const reelsFeedRef = useRef<HTMLDivElement | null>(null);
  const wordSessionRef = useRef(0);
  const fetchingPageRef = useRef(false);

  const activeClip = clips[activeIdx] || null;

  const activeWindow = useMemo(() => {
    if (!activeClip) return { startSec: 0, endSec: 6, clipDurationSec: 6, wordOffsetPct: 50 };
    return computeWordClipWindow(activeClip.wordStartSec, activeClip.durationSec, 3, 3);
  }, [activeClip]);

  // Helper to fetch additional pages silently until we reach >= 50 clips
  const loadMorePagesUntilTarget = useCallback(
    async (
      targetWord: string,
      sessionId: number,
      startPage: number,
      existingClips: WordVideoClip[]
    ) => {
      let accumulated = existingClips;
      let page = startPage;
      let more = true;

      if (accumulated.length >= TARGET_MIN_CLIPS) return;
      setLoadingMore(true);

      try {
        while (
          sessionId === wordSessionRef.current &&
          accumulated.length < TARGET_MIN_CLIPS &&
          more &&
          page <= 5
        ) {
          fetchingPageRef.current = true;
          const res = await fetchWordVideoClips(targetWord, page, false);
          if (sessionId !== wordSessionRef.current) return;
          more = res.hasMore && res.clips.length > 0;
          page += 1;

          if (res.clips.length > 0) {
            accumulated = dedupeVideoClips([...accumulated, ...res.clips]);
            setClips(accumulated);
          }
          setNextPage(page);
          setHasMore(more);
        }
      } finally {
        fetchingPageRef.current = false;
        if (sessionId === wordSessionRef.current) {
          setLoadingMore(false);
        }
      }
    },
    []
  );

  const loadInitialClips = useCallback(
    async (force = false) => {
      const sessionId = ++wordSessionRef.current;
      setLoading(true);
      setLoadingMore(false);
      setClips([]);
      setActiveIdx(0);
      setIsPlaying(false); // Always OFF on word entry
      setIsFullscreen(false);
      setHasMore(true);
      setNextPage(1);
      setCurrentTimeSec(0);
      setBuffering(false);

      const firstPage = await fetchWordVideoClips(word, 0, force);
      if (sessionId !== wordSessionRef.current) return;

      const initial = dedupeVideoClips(firstPage.clips || []);
      setClips(initial);
      setCurrentTimeSec(initial[0]?.startSec ?? 0);
      setHasMore(firstPage.hasMore);
      setNextPage(1);
      setLoading(false);

      // Warm posters for the first few clips immediately
      for (const c of initial.slice(0, 4)) {
        if (c.posterUrl) warmImageUrl(c.posterUrl);
      }

      // Speculatively hydrate background pages so every word has >= 50 clips ready with zero wait
      if (initial.length > 0 && initial.length < TARGET_MIN_CLIPS && firstPage.hasMore) {
        void loadMorePagesUntilTarget(word, sessionId, 1, initial);
      }
    },
    [word, loadMorePagesUntilTarget]
  );

  useEffect(() => {
    void loadInitialClips(false);
  }, [loadInitialClips]);

  // Speculatively paginate even beyond 50 clips if user scrolls near the end
  useEffect(() => {
    if (!hasMore || fetchingPageRef.current || loading || loadingMore) return;
    if (clips.length === 0 || activeIdx < clips.length - 10) return;

    const sessionId = wordSessionRef.current;
    fetchingPageRef.current = true;
    setLoadingMore(true);

    void fetchWordVideoClips(word, nextPage, false)
      .then((res) => {
        if (sessionId !== wordSessionRef.current) return;
        if (res.clips.length > 0) {
          setClips((prev) => dedupeVideoClips([...prev, ...res.clips]));
        }
        setHasMore(res.hasMore && res.clips.length > 0);
        setNextPage((p) => p + 1);
      })
      .finally(() => {
        fetchingPageRef.current = false;
        if (sessionId === wordSessionRef.current) {
          setLoadingMore(false);
        }
      });
  }, [activeIdx, clips.length, hasMore, loading, loadingMore, nextPage, word]);

  // Warm poster images for upcoming lookahead clips
  const prefetchIndices = useMemo(
    () => getNextPrefetchIndices(activeIdx, clips.length, 3),
    [activeIdx, clips.length]
  );

  useEffect(() => {
    for (const idx of prefetchIndices) {
      const c = clips[idx];
      if (c?.posterUrl) warmImageUrl(c.posterUrl);
      if (c?.videoUrl) warmVideoUrl(c.videoUrl);
    }
  }, [prefetchIndices, clips]);

  // Inline video playback + ±3s auto-loop synchronization
  useEffect(() => {
    const v = inlineVideoRef.current;
    if (!v || !activeClip) return;

    if (isFullscreen) {
      if (!v.paused) v.pause();
      return;
    }

    v.muted = isMuted;
    if (isPlaying) {
      if (
        v.readyState >= 1 &&
        (v.currentTime < activeClip.startSec - 0.25 || v.currentTime >= activeClip.endSec - 0.1)
      ) {
        try {
          v.currentTime = activeClip.startSec;
        } catch {
          // Ignore
        }
      }
      const p = v.play();
      if (p && typeof p.catch === 'function') {
        p.catch(() => {});
      }
    } else if (!v.paused) {
      v.pause();
    }
  }, [activeClip, isPlaying, isMuted, isFullscreen]);

  // Tight 80ms loop guard for inline player
  useEffect(() => {
    if (isFullscreen || !isPlaying || !activeClip) return;
    const timer = window.setInterval(() => {
      const v = inlineVideoRef.current;
      if (!v || v.paused) return;
      const t = v.currentTime;
      setCurrentTimeSec(t);
      if (t >= activeClip.endSec - 0.08) {
        v.currentTime = activeClip.startSec;
        setCurrentTimeSec(activeClip.startSec);
      }
    }, 80);
    return () => window.clearInterval(timer);
  }, [isFullscreen, isPlaying, activeClip]);

  // Reset currentTime indicator whenever active clip changes
  useEffect(() => {
    if (activeClip) {
      setCurrentTimeSec(activeClip.startSec);
    }
  }, [activeClip]);

  const handleTogglePlay = useCallback(() => {
    if (!activeClip) return;
    setClipErrorMsg('');
    const nextPlaying = !isPlaying;
    const v = inlineVideoRef.current;
    if (v && !isFullscreen) {
      if (nextPlaying) {
        v.muted = isMuted;
        if (
          v.readyState >= 1 &&
          (v.currentTime < activeClip.startSec - 0.3 || v.currentTime >= activeClip.endSec - 0.1)
        ) {
          try {
            v.currentTime = activeClip.startSec;
          } catch {
            // Ignore
          }
        }
        const p = v.play();
        if (p && typeof p.catch === 'function') {
          p.catch(() => {
            // Fallback to muted playback if browser blocks unmuted gesture
            v.muted = true;
            setIsMuted(true);
            void v.play().catch(() => {
              setIsPlaying(false);
            });
          });
        }
      } else if (!v.paused) {
        v.pause();
      }
    }
    setIsPlaying(nextPlaying);
  }, [activeClip, isPlaying, isFullscreen, isMuted]);

  const handleReplay = useCallback(() => {
    if (!activeClip) return;
    setClipErrorMsg('');
    const v = inlineVideoRef.current;
    if (v && !isFullscreen) {
      try {
        v.currentTime = activeClip.startSec;
      } catch {
        // Ignore
      }
      v.muted = isMuted;
      const p = v.play();
      if (p && typeof p.catch === 'function') {
        p.catch(() => {
          v.muted = true;
          setIsMuted(true);
          void v.play().catch(() => {});
        });
      }
    }
    setCurrentTimeSec(activeClip.startSec);
    setIsPlaying(true);
  }, [activeClip, isFullscreen, isMuted]);

  const scrollToReelIndex = useCallback((targetIndex: number, behavior: ScrollBehavior = 'smooth') => {
    const feed = reelsFeedRef.current;
    if (!feed) return;
    const slideHeight = feed.clientHeight || window.innerHeight;
    feed.scrollTo({ top: targetIndex * slideHeight, behavior });
  }, []);

  const handlePrev = useCallback(() => {
    setActiveIdx((prev) => {
      const next = Math.max(0, prev - 1);
      if (isFullscreen) {
        scrollToReelIndex(next, 'smooth');
      }
      return next;
    });
  }, [isFullscreen, scrollToReelIndex]);

  const handleNext = useCallback(() => {
    setActiveIdx((prev) => {
      const next = Math.min(Math.max(0, clips.length - 1), prev + 1);
      if (isFullscreen) {
        scrollToReelIndex(next, 'smooth');
      }
      return next;
    });
  }, [clips.length, isFullscreen, scrollToReelIndex]);

  const openFullscreen = useCallback(() => {
    if (!clips.length) return;
    if (inlineVideoRef.current && !inlineVideoRef.current.paused) {
      inlineVideoRef.current.pause();
    }
    setIsFullscreen(true);
  }, [clips.length]);

  const closeFullscreen = useCallback(() => {
    setIsFullscreen(false);
    if (typeof document !== 'undefined' && document.fullscreenElement) {
      void document.exitFullscreen().catch(() => {});
    }
  }, []);

  // Lock body scroll & sync native fullscreen / Escape / Arrow keys when Fullscreen Reels is open
  useEffect(() => {
    if (!isFullscreen) return;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    // Jump straight to the active clip inside the vertical Reels feed
    const raf = window.requestAnimationFrame(() => {
      scrollToReelIndex(activeIdx, 'auto');
    });

    // Request browser fullscreen smoothly if supported (safe no-op in iframes/restricted contexts)
    const el = fullscreenOverlayRef.current;
    if (el && typeof el.requestFullscreen === 'function' && !document.fullscreenElement) {
      void el.requestFullscreen().catch(() => {});
    }

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        closeFullscreen();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        handleNext();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        handlePrev();
      } else if (e.key === ' ') {
        e.preventDefault();
        setIsPlaying((p) => !p);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => {
      window.cancelAnimationFrame(raf);
      window.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = prevOverflow;
    };
  }, [isFullscreen]);

  // IntersectionObserver for Instagram Reels vertical swipe/scroll snap tracking
  useEffect(() => {
    if (!isFullscreen) return;
    const feed = reelsFeedRef.current;
    if (!feed) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.6) {
            const idxAttr = entry.target.getAttribute('data-reel-index');
            const parsed = idxAttr ? Number.parseInt(idxAttr, 10) : NaN;
            if (Number.isFinite(parsed)) {
              setActiveIdx((prev) => (prev === parsed ? prev : parsed));
            }
          }
        }
      },
      { root: feed, threshold: [0.6, 0.85] }
    );

    const children = feed.querySelectorAll('[data-reel-index]');
    children.forEach((child) => observer.observe(child));

    return () => observer.disconnect();
  }, [isFullscreen, clips.length]);

  const inlineProgressPct = useMemo(() => {
    if (!activeClip) return 0;
    const span = Math.max(0.5, activeClip.endSec - activeClip.startSec);
    return Math.max(0, Math.min(100, ((currentTimeSec - activeClip.startSec) / span) * 100));
  }, [activeClip, currentTimeSec]);

  const activeCaptionText = useMemo(() => {
    if (!activeClip) return '';
    return getActiveCaptionAtTime(activeClip, currentTimeSec);
  }, [activeClip, currentTimeSec]);

  const isRtl = uiLang === 'ar';

  return (
    <>
      <section
        data-testid="word-video-reels-card"
        data-playing={String(isPlaying)}
        data-clip-count={clips.length}
        data-active-index={activeIdx}
        className="overflow-hidden rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#131c2e]"
      >
        {/* Clean Header Row */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-5 py-3.5 dark:border-slate-800">
          <div className="min-w-0">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-slate-100">
              <Film className="h-4 w-4 shrink-0 text-indigo-500" aria-hidden="true" />
              <span>{strings.title}</span>
            </div>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
              {strings.subtitle}
            </p>
          </div>

          {clips.length > 0 && (
            <div className="flex items-center gap-2.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
              <span data-testid="video-clip-counter" className="font-en font-bold text-slate-800 dark:text-slate-200" dir="ltr">
                {activeIdx + 1} / {clips.length}
              </span>
              <span aria-hidden="true">·</span>
              <span>{strings.windowLabel}</span>
              {loadingMore && (
                <Loader2 className="h-3.5 w-3.5 animate-spin text-indigo-500" aria-label={strings.loadingMore} />
              )}
            </div>
          )}
        </div>

        {/* Video Cinema Body */}
        <div className="p-4 sm:p-5">
          {loading ? (
            <div className="flex aspect-video max-h-[390px] w-full flex-col items-center justify-center gap-3 rounded-xl bg-slate-950 text-slate-300">
              <Loader2 className="h-7 w-7 animate-spin text-indigo-400" aria-hidden="true" />
              <p className="text-xs font-semibold text-slate-300">{strings.loading}</p>
            </div>
          ) : !activeClip ? (
            <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-slate-200 bg-slate-50 px-5 py-10 text-center dark:border-slate-700 dark:bg-slate-900/40">
              <Film className="h-8 w-8 text-slate-400" aria-hidden="true" />
              <p className="text-sm font-medium text-slate-600 dark:text-slate-300">
                {strings.empty}
              </p>
              <button
                type="button"
                onClick={() => void loadInitialClips(true)}
                className="inline-flex h-10 items-center gap-2 whitespace-nowrap rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white transition hover:bg-indigo-700"
              >
                <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{strings.retry}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-3.5">
              {/* Inline Cinema Viewport (true 16:9 uncropped frame) */}
              <div
                onClick={handleTogglePlay}
                className="group relative mx-auto aspect-video w-full max-w-[760px] cursor-pointer overflow-hidden rounded-xl bg-black shadow-sm ring-1 ring-slate-900/10 dark:ring-white/10"
              >
                <video
                  key={`${activeClip.id}-${proxiedClipIds[activeClip.id] ? 'px' : 'dir'}`}
                  ref={inlineVideoRef}
                  src={
                    proxiedClipIds[activeClip.id]
                      ? getProxiedVideoUrl(activeClip.videoUrl)
                      : activeClip.videoUrl
                  }
                  poster={activeClip.posterUrl || undefined}
                  playsInline
                  preload="auto"
                  referrerPolicy="no-referrer"
                  muted={isMuted}
                  onLoadedMetadata={() => {
                    const v = inlineVideoRef.current;
                    if (!v) return;
                    if (Math.abs(v.currentTime - activeClip.startSec) > 0.35) {
                      try {
                        v.currentTime = activeClip.startSec;
                      } catch {
                        // Ignore
                      }
                    }
                    if (isPlaying && !isFullscreen) {
                      void v.play().catch(() => {
                        v.muted = true;
                        setIsMuted(true);
                        void v.play().catch(() => {});
                      });
                    }
                  }}
                  onError={() => {
                    if (!proxiedClipIds[activeClip.id]) {
                      setProxiedClipIds((prev) => ({ ...prev, [activeClip.id]: true }));
                    } else if (activeIdx < clips.length - 1) {
                      setBuffering(false);
                      setActiveIdx((idx) => Math.min(clips.length - 1, idx + 1));
                    } else {
                      setBuffering(false);
                      setIsPlaying(false);
                      setClipErrorMsg('تعذر تشغيل هذا المقطع، جرّب المقطع التالي أو أعد المحاولة.');
                    }
                  }}
                  onWaiting={() => setBuffering(true)}
                  onPlaying={() => {
                    setBuffering(false);
                    setClipErrorMsg('');
                  }}
                  onCanPlay={() => setBuffering(false)}
                  onTimeUpdate={() => {
                    const v = inlineVideoRef.current;
                    if (!v || isFullscreen) return;
                    if (v.currentTime >= activeClip.endSec - 0.08) {
                      v.currentTime = activeClip.startSec;
                      setCurrentTimeSec(activeClip.startSec);
                      return;
                    }
                    setCurrentTimeSec(v.currentTime);
                  }}
                  onEnded={() => {
                    const v = inlineVideoRef.current;
                    if (!v || isFullscreen) return;
                    v.currentTime = activeClip.startSec;
                    setCurrentTimeSec(activeClip.startSec);
                    if (isPlaying) {
                      void v.play().catch(() => {});
                    }
                  }}
                  className="h-full w-full object-contain"
                />

                {/* Bottom Gradient Scrim */}
                <div
                  className="pointer-events-none absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-black/85 via-black/35 to-transparent"
                  aria-hidden="true"
                />

                {/* Top Quick Fullscreen Button on Viewport */}
                <div
                  className="absolute top-3 end-3 z-10 flex items-center gap-1.5"
                  onClick={(e) => e.stopPropagation()}
                >
                  <button
                    type="button"
                    data-testid="video-fullscreen-btn"
                    onClick={openFullscreen}
                    aria-label={strings.fullscreen}
                    title={strings.fullscreen}
                    className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-lg bg-black/65 px-2.5 text-xs font-bold text-white backdrop-blur-md transition hover:bg-black/85"
                  >
                    <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span className="hidden sm:inline">{strings.fullscreen}</span>
                  </button>
                </div>

                {/* Paused Center Play Trigger */}
                {!isPlaying && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-2.5 bg-black/30 transition">
                    <button
                      type="button"
                      data-testid="video-play-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTogglePlay();
                      }}
                      aria-label={strings.play}
                      className="flex h-16 w-16 items-center justify-center rounded-full bg-white text-slate-950 shadow-xl transition hover:scale-105"
                    >
                      <Play className="h-7 w-7 translate-x-0.5 fill-current" aria-hidden="true" />
                    </button>
                    <span className="rounded-lg bg-black/70 px-3 py-1 text-xs font-bold text-white backdrop-blur-sm">
                      {strings.tapToPlay}
                    </span>
                  </div>
                )}

                {/* Buffering Spinner */}
                {isPlaying && buffering && (
                  <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                    <div className="flex h-11 w-11 items-center justify-center rounded-full bg-black/65 text-white backdrop-blur-sm">
                      <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
                    </div>
                  </div>
                )}

                {/* Live Toggleable English Captions */}
                {showCaptions && activeCaptionText && (
                  <div className="pointer-events-none absolute inset-x-3 bottom-4 z-10 flex justify-center sm:inset-x-6">
                    <div
                      data-testid="video-caption-box"
                      className="max-w-2xl rounded-xl bg-black/75 px-3.5 py-2 text-center text-sm font-semibold leading-relaxed text-white shadow-lg backdrop-blur-md sm:text-base"
                      dir="ltr"
                    >
                      <HighlightedCaption text={activeCaptionText} targetWord={word} />
                    </div>
                  </div>
                )}

                {/* ±3s Loop Scrubber Bar at Bottom Edge */}
                <div dir="ltr" className="pointer-events-none absolute inset-x-0 bottom-0 h-1 bg-white/25">
                  <div
                    className="h-full bg-amber-400 transition-[width] duration-75"
                    style={{ width: `${inlineProgressPct}%` }}
                  />
                  <div
                    className="absolute top-0 bottom-0 w-1 bg-white"
                    style={{ left: `${activeWindow.wordOffsetPct}%` }}
                  />
                </div>
              </div>

              {clipErrorMsg && (
                <div className="flex items-center justify-between gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3.5 py-2 text-xs font-semibold text-amber-700 dark:text-amber-300">
                  <span>{clipErrorMsg}</span>
                  <button
                    type="button"
                    onClick={() => void loadInitialClips(true)}
                    className="shrink-0 rounded-lg bg-amber-500/20 px-2.5 py-1 font-bold hover:bg-amber-500/30"
                  >
                    {strings.retry}
                  </button>
                </div>
              )}

              {/* Clean Controls Bar */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                {/* Left/Primary Navigation: Prev · Play/Pause · Next */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    data-testid="video-prev-btn"
                    onClick={handlePrev}
                    disabled={activeIdx <= 0}
                    className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition hover:bg-slate-100 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  >
                    {isRtl ? (
                      <ChevronRight className="h-4 w-4" aria-hidden="true" />
                    ) : (
                      <ChevronLeft className="h-4 w-4" aria-hidden="true" />
                    )}
                    <span>{strings.prev}</span>
                  </button>

                  <button
                    type="button"
                    data-testid="video-toggle-play-btn"
                    onClick={handleTogglePlay}
                    className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white transition hover:bg-indigo-700"
                  >
                    {isPlaying ? (
                      <>
                        <Pause className="h-4 w-4 fill-current" aria-hidden="true" />
                        <span>{strings.pause}</span>
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 fill-current" aria-hidden="true" />
                        <span>{strings.play}</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    data-testid="video-next-btn"
                    onClick={handleNext}
                    disabled={activeIdx >= clips.length - 1}
                    className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition hover:bg-slate-100 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  >
                    <span>{strings.next}</span>
                    {isRtl ? (
                      <ChevronLeft className="h-4 w-4" aria-hidden="true" />
                    ) : (
                      <ChevronRight className="h-4 w-4" aria-hidden="true" />
                    )}
                  </button>
                </div>

                {/* Right/Secondary Controls: Replay · CC · Mute · Fullscreen */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleReplay}
                    title={strings.replay}
                    aria-label={strings.replay}
                    className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
                  >
                    <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  </button>

                  <button
                    type="button"
                    data-testid="video-cc-btn"
                    onClick={() => setShowCaptions((c) => !c)}
                    aria-pressed={showCaptions}
                    className={`inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-xl border px-3 text-xs font-bold transition ${
                      showCaptions
                        ? 'border-amber-300 bg-amber-50 text-amber-800 dark:border-amber-500/40 dark:bg-amber-500/15 dark:text-amber-300'
                        : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    <Subtitles className="h-4 w-4" aria-hidden="true" />
                    <span>CC</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsMuted((m) => !m)}
                    title={isMuted ? strings.unmute : strings.mute}
                    aria-label={isMuted ? strings.unmute : strings.mute}
                    className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-600 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
                  >
                    {isMuted ? (
                      <VolumeX className="h-4 w-4" aria-hidden="true" />
                    ) : (
                      <Volume2 className="h-4 w-4" aria-hidden="true" />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={openFullscreen}
                    title={strings.fullscreen}
                    aria-label={strings.fullscreen}
                    className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-xl border border-indigo-200 bg-indigo-50 px-3 text-xs font-bold text-indigo-700 transition hover:bg-indigo-100 dark:border-indigo-500/30 dark:bg-indigo-500/15 dark:text-indigo-300 dark:hover:bg-indigo-500/25"
                  >
                    <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
                    <span className="hidden md:inline">{strings.fullscreen}</span>
                  </button>
                </div>
              </div>

              {/* Clean Source Line */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-2.5 text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
                <span className="min-w-0 truncate">
                  <strong className="font-semibold text-slate-700 dark:text-slate-200">
                    {activeClip.speaker}
                  </strong>
                  {' · '}
                  <span dir="ltr">{activeClip.title}</span>
                </span>
                <span className="shrink-0 text-[11px] text-slate-400 dark:text-slate-500">
                  {strings.swipeHint}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Speculative Lookahead Video Prefetch Pool (Next 3 + Prev 1) */}
        {!isFullscreen && clips.length > 1 && (
          <div
            data-testid="video-prefetch-pool"
            aria-hidden="true"
            className="pointer-events-none fixed -left-[9999px] top-0 h-px w-px overflow-hidden opacity-0"
          >
            {prefetchIndices.map((idx) => {
              const upcoming = clips[idx];
              if (!upcoming) return null;
              return (
                <video
                  key={`pf-${upcoming.id}`}
                  src={upcoming.videoUrl}
                  preload="metadata"
                  referrerPolicy="no-referrer"
                  muted
                  playsInline
                />
              );
            })}
          </div>
        )}
      </section>

      {/* Fullscreen Instagram Reels Vertical Swipe / Scroll Overlay */}
      {isFullscreen && clips.length > 0 && (
        <div
          ref={fullscreenOverlayRef}
          data-testid="video-reels-fullscreen"
          role="dialog"
          aria-modal="true"
          aria-label={strings.title}
          className="fixed inset-0 z-[70] h-[100dvh] w-screen overflow-hidden bg-black text-white"
        >
          {/* Persistent Top Control Bar with Prominent Exit Fullscreen Button */}
          <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex items-center justify-between gap-3 px-4 pt-4 sm:px-6">
            <button
              type="button"
              data-testid="video-exit-fullscreen-btn"
              onClick={closeFullscreen}
              className="pointer-events-auto inline-flex h-10 items-center gap-2 whitespace-nowrap rounded-xl bg-black/70 px-3.5 text-xs font-bold text-white ring-1 ring-white/20 backdrop-blur-md transition hover:bg-black/90"
            >
              <Minimize2 className="h-4 w-4 sm:hidden" aria-hidden="true" />
              <X className="hidden h-4 w-4 sm:block" aria-hidden="true" />
              <span>{strings.exitFullscreen}</span>
            </button>

            <div className="pointer-events-auto flex items-center gap-2 rounded-xl bg-black/65 px-3 py-1.5 backdrop-blur-md ring-1 ring-white/15">
              <span className="font-en text-sm font-extrabold text-amber-300" dir="ltr">
                {word}
              </span>
              {meaningAr && (
                <>
                  <span className="text-white/35">·</span>
                  <span className="max-w-[120px] truncate text-xs font-semibold text-white/90 sm:max-w-[200px]">
                    {meaningAr}
                  </span>
                </>
              )}
            </div>

            <button
              type="button"
              data-testid="video-fs-cc-btn"
              onClick={() => setShowCaptions((c) => !c)}
              aria-pressed={showCaptions}
              className={`pointer-events-auto inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-xl px-3 text-xs font-bold backdrop-blur-md transition ${
                showCaptions
                  ? 'bg-amber-400 text-slate-950 hover:bg-amber-300'
                  : 'bg-black/70 text-white ring-1 ring-white/20 hover:bg-black/90'
              }`}
            >
              <Subtitles className="h-4 w-4" aria-hidden="true" />
              <span>CC</span>
            </button>
          </div>

          {/* True Vertical Scroll-Snap Instagram Reels Feed */}
          <div
            ref={reelsFeedRef}
            data-testid="video-reels-feed"
            className="h-[100dvh] w-full overflow-y-scroll snap-y snap-mandatory overscroll-y-contain [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
          >
            {clips.map((clip, idx) => {
              const shouldMountVideo = idx >= activeIdx - 1 && idx <= activeIdx + 3;
              return (
                <ReelsSlide
                  key={`reel-${clip.id}`}
                  clip={clip}
                  index={idx}
                  totalCount={clips.length}
                  isActive={idx === activeIdx}
                  shouldMountVideo={shouldMountVideo}
                  isPlaying={isPlaying}
                  isMuted={isMuted}
                  showCaptions={showCaptions}
                  targetWord={word}
                  tapToPlayLabel={strings.tapToPlay}
                  onTogglePlay={handleTogglePlay}
                  onSyncTime={setCurrentTimeSec}
                  onNext={handleNext}
                  onPrev={handlePrev}
                  onToggleCaptions={() => setShowCaptions((c) => !c)}
                  onToggleMute={() => setIsMuted((m) => !m)}
                  onReplay={handleReplay}
                  strings={strings}
                />
              );
            })}
          </div>
        </div>
      )}
    </>
  );
}
