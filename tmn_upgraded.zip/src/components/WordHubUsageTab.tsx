import {
  AlertTriangle,
  ArrowUpLeft,
  Bookmark,
  CheckCircle2,
  Compass,
  Link2,
  MessageSquareQuote,
  Scale,
  Sparkles,
  Volume2,
  XCircle,
} from 'lucide-react';
import type { SavedWordNote, SavedWordNoteKind, WordHubData } from '../types';
import { WordHubCollapsibleCard } from './WordHubCollapsibleCard';

interface WordHubUsageTabProps {
  wordEn: string;
  hub: WordHubData | null;
  loading: boolean;
  hideTranslation: boolean;
  savedNoteIds: Set<string>;
  onSpeak: (text: string) => void;
  onExploreWord: (targetWord: string, glossAr?: string) => void;
  onToggleSaveNote: (note: Omit<SavedWordNote, 'savedAt'>) => void;
}

function makeNoteId(parentWord: string, kind: SavedWordNoteKind, text: string): string {
  return `${parentWord.toLowerCase()}::${kind}::${text.toLowerCase().trim()}`;
}

function highlightTarget(sentence: string, target: string) {
  if (!target) return sentence;
  const escaped = target.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`(\\b${escaped}[a-z]*\\b)`, 'gi');
  const parts = sentence.split(re);
  return parts.map((part, idx) =>
    idx % 2 === 1 ? (
      <span
        key={idx}
        className="font-extrabold text-indigo-600 underline decoration-indigo-500/70 decoration-2 underline-offset-4 dark:text-cyan-400 dark:decoration-cyan-400/70"
      >
        {part}
      </span>
    ) : (
      <span key={idx}>{part}</span>
    )
  );
}

export function WordHubUsageTab({
  wordEn,
  hub,
  loading,
  hideTranslation,
  savedNoteIds,
  onSpeak,
  onExploreWord,
  onToggleSaveNote,
}: WordHubUsageTabProps) {
  if (loading && !hub) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((k) => (
          <div
            key={k}
            className="h-28 animate-pulse rounded-2xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#131c2e]"
          />
        ))}
      </div>
    );
  }

  const collocations = hub?.collocations || [];
  const examples = hub?.examples || [];
  const commonMistakes = hub?.commonMistakes || [];
  const usageNotes = hub?.usageNotes || [];
  const formalVsInformal = hub?.formalVsInformal || null;
  const idioms = hub?.idioms || [];
  const phrasalVerbs = hub?.phrasalVerbs || [];

  const hasAny =
    collocations.length > 0 ||
    examples.length > 0 ||
    commonMistakes.length > 0 ||
    usageNotes.length > 0 ||
    Boolean(formalVsInformal) ||
    idioms.length > 0 ||
    phrasalVerbs.length > 0;

  if (!hasAny) {
    return (
      <section className="rounded-2xl border border-slate-200 bg-white p-6 text-center dark:border-slate-800 dark:bg-[#131c2e]">
        <p className="text-sm font-bold text-slate-700 dark:text-slate-200">
          جاري تجهيز سياقات الاستخدام لهذه الكلمة أو لا تتوفر تفاصيل إضافية دون اتصال.
        </p>
      </section>
    );
  }

  return (
    <div className="space-y-4">
      {/* 1. Collocations */}
      {collocations.length > 0 && (
        <WordHubCollapsibleCard
          title="التلازمات اللفظية (Collocations)"
          subtitle="الكلمات التي تأتي معها بشكل طبيعي لدى المتحدثين الأصليين"
          count={collocations.length}
          icon={<Link2 className="h-4 w-4" aria-hidden="true" />}
          defaultOpen
        >
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {collocations.map((col) => {
              const noteId = makeNoteId(wordEn, 'collocation', col.phrase);
              const isSaved = savedNoteIds.has(noteId);
              return (
                <div key={col.phrase} className="py-3.5 first:pt-0 last:pb-0">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span dir="ltr" className="font-en text-sm font-extrabold text-slate-900 dark:text-slate-100 sm:text-base">
                        {col.phrase}
                      </span>
                      {!hideTranslation && (
                        <>
                          <span className="text-slate-300 dark:text-slate-600" aria-hidden="true">
                            ·
                          </span>
                          <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 sm:text-sm">
                            {col.ar}
                          </span>
                        </>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onSpeak(col.exampleEn || col.phrase)}
                        aria-label={`نطق ${col.phrase}`}
                        className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                      >
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onToggleSaveNote({
                            id: noteId,
                            parentWord: wordEn,
                            kind: 'collocation',
                            text: col.phrase,
                            meaningAr: col.ar,
                            extra: col.exampleEn,
                          })
                        }
                        aria-label={isSaved ? `إزالة ${col.phrase}` : `حفظ ${col.phrase}`}
                        className={`flex h-8 w-8 items-center justify-center rounded-lg border transition-colors ${
                          isSaved
                            ? 'border-indigo-500 bg-indigo-50 text-indigo-600 dark:border-indigo-400 dark:bg-indigo-500/20 dark:text-indigo-300'
                            : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400'
                        }`}
                      >
                        <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                  {col.exampleEn && (
                    <div className="mt-2 space-y-0.5 rounded-xl bg-slate-50 px-3.5 py-2 dark:bg-slate-900/60">
                      <p dir="ltr" className="text-left font-en text-xs font-medium text-slate-700 dark:text-slate-200 sm:text-sm">
                        {col.exampleEn}
                      </p>
                      {!hideTranslation && col.exampleAr && (
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {col.exampleAr}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </WordHubCollapsibleCard>
      )}

      {/* 2. Example Sentences */}
      {examples.length > 0 && (
        <WordHubCollapsibleCard
          title="أمثلة في الحياة اليومية"
          subtitle="جمل طبيعية مع نطق صوتي وترجمة اختيارية"
          count={examples.length}
          icon={<MessageSquareQuote className="h-4 w-4" aria-hidden="true" />}
          defaultOpen
        >
          <div className="space-y-3">
            {examples.map((ex, i) => {
              const noteId = makeNoteId(wordEn, 'example', ex.en);
              const isSaved = savedNoteIds.has(noteId);
              const regLabel =
                ex.register === 'formal'
                  ? 'رسمي'
                  : ex.register === 'informal'
                    ? 'يومي'
                    : null;
              return (
                <div
                  key={i}
                  className="flex items-start justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-slate-800 dark:bg-slate-900/50"
                >
                  <div className="min-w-0 flex-1 space-y-1">
                    <p
                      dir="ltr"
                      className="text-left font-en text-sm leading-relaxed font-medium text-slate-900 dark:text-slate-100 sm:text-[15px]"
                    >
                      {highlightTarget(ex.en, wordEn)}
                    </p>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      {!hideTranslation && ex.ar && <span>{ex.ar}</span>}
                      {regLabel && (
                        <>
                          {!hideTranslation && ex.ar && <span aria-hidden="true">·</span>}
                          <span className="font-semibold text-slate-600 dark:text-slate-300">
                            أسلوب {regLabel}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onSpeak(ex.en)}
                      aria-label={`نطق المثال ${i + 1}`}
                      className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
                    >
                      <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onToggleSaveNote({
                          id: noteId,
                          parentWord: wordEn,
                          kind: 'example',
                          text: ex.en,
                          meaningAr: ex.ar || '',
                        })
                      }
                      aria-label={isSaved ? 'إزالة المثال من المحفوظات' : 'حفظ المثال'}
                      className={`flex h-8 w-8 items-center justify-center rounded-lg border transition-colors ${
                        isSaved
                          ? 'border-indigo-500 bg-indigo-50 text-indigo-600 dark:border-indigo-400 dark:bg-indigo-500/20 dark:text-indigo-300'
                          : 'border-slate-200 bg-white text-slate-500 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-400'
                      }`}
                    >
                      <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} aria-hidden="true" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </WordHubCollapsibleCard>
      )}

      {/* 3. Formal vs Informal + Usage Notes */}
      {(formalVsInformal || usageNotes.length > 0) && (
        <WordHubCollapsibleCard
          title="الاستخدام الرسمي وغير الرسمي وملاحظات مهمة"
          subtitle="متى تستخدم الكلمة وما البدائل الأنسب حسب الموقف"
          icon={<Scale className="h-4 w-4" aria-hidden="true" />}
          defaultOpen
        >
          <div className="space-y-4">
            {formalVsInformal && (
              <div className="rounded-xl border border-slate-200 bg-slate-50/70 p-4 dark:border-slate-800 dark:bg-slate-900/50">
                <div className="flex flex-wrap items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300">
                  <span className="text-slate-900 dark:text-slate-100">مستوى الرسمية:</span>
                  <span>
                    {formalVsInformal.registerLabel} · {formalVsInformal.registerLabelAr}
                  </span>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-slate-700 dark:text-slate-200 sm:text-sm">
                  {formalVsInformal.noteAr}
                </p>
                {(formalVsInformal.formalAlt || formalVsInformal.informalAlt) && (
                  <div className="mt-3 flex flex-wrap items-center gap-4 border-t border-slate-200/70 pt-3 text-xs dark:border-slate-800">
                    {formalVsInformal.formalAlt && (
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-500 dark:text-slate-400">
                          البديل الرسمي:
                        </span>
                        <button
                          type="button"
                          onClick={() => onExploreWord(formalVsInformal.formalAlt!)}
                          className="inline-flex items-center gap-1 font-en font-extrabold text-indigo-600 hover:underline dark:text-indigo-400"
                          dir="ltr"
                        >
                          <span>{formalVsInformal.formalAlt}</span>
                          <ArrowUpLeft className="h-3 w-3" aria-hidden="true" />
                        </button>
                      </div>
                    )}
                    {formalVsInformal.informalAlt && (
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-500 dark:text-slate-400">
                          البديل غير الرسمي:
                        </span>
                        <button
                          type="button"
                          onClick={() => onExploreWord(formalVsInformal.informalAlt!)}
                          className="inline-flex items-center gap-1 font-en font-extrabold text-indigo-600 hover:underline dark:text-indigo-400"
                          dir="ltr"
                        >
                          <span>{formalVsInformal.informalAlt}</span>
                          <ArrowUpLeft className="h-3 w-3" aria-hidden="true" />
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {usageNotes.length > 0 && (
              <ul className="space-y-2 text-xs leading-relaxed text-slate-700 dark:text-slate-200 sm:text-sm">
                {usageNotes.map((note, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-500" aria-hidden="true" />
                    <span>{note}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </WordHubCollapsibleCard>
      )}

      {/* 4. Common Mistakes */}
      {commonMistakes.length > 0 && (
        <WordHubCollapsibleCard
          title="أخطاء شائعة تجنّبها"
          subtitle="مقارنة سريعة بين الخطأ الشائع والصواب"
          count={commonMistakes.length}
          icon={<AlertTriangle className="h-4 w-4" aria-hidden="true" />}
          defaultOpen={false}
        >
          <div className="space-y-3">
            {commonMistakes.map((m, idx) => (
              <div
                key={idx}
                className="space-y-2 rounded-xl border border-slate-200 bg-slate-50/70 p-3.5 dark:border-slate-800 dark:bg-slate-900/50"
              >
                <div className="flex items-start gap-2 text-rose-700 dark:text-rose-400">
                  <XCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                  <span dir="ltr" className="font-en text-sm font-semibold line-through">
                    {m.wrong}
                  </span>
                </div>
                <div className="flex items-start justify-between gap-2 text-emerald-700 dark:text-emerald-400">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                    <span dir="ltr" className="font-en text-sm font-bold">
                      {m.right}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSpeak(m.right)}
                    aria-label="نطق الجملة الصحيحة"
                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-emerald-700 hover:bg-emerald-100 dark:text-emerald-300 dark:hover:bg-emerald-950/60"
                  >
                    <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                </div>
                {m.noteAr && (
                  <p className="border-t border-slate-200/70 pt-2 text-xs text-slate-600 dark:border-slate-800 dark:text-slate-300">
                    {m.noteAr}
                  </p>
                )}
              </div>
            ))}
          </div>
        </WordHubCollapsibleCard>
      )}

      {/* 5. Idioms & Expressions (ONLY shown when real idioms exist) */}
      {idioms.length > 0 && (
        <WordHubCollapsibleCard
          title="التعبيرات الاصطلاحية (Idioms & Expressions)"
          subtitle="تعبيرات متداولة حقيقية تتضمن هذه الكلمة"
          count={idioms.length}
          icon={<Sparkles className="h-4 w-4" aria-hidden="true" />}
          defaultOpen={false}
        >
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {idioms.map((item) => {
              const noteId = makeNoteId(wordEn, 'idiom', item.phrase);
              const isSaved = savedNoteIds.has(noteId);
              return (
                <div key={item.phrase} className="py-3.5 first:pt-0 last:pb-0">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span dir="ltr" className="font-en text-sm font-extrabold text-slate-900 dark:text-slate-100">
                        {item.phrase}
                      </span>
                      {!hideTranslation && (
                        <>
                          <span className="text-slate-300 dark:text-slate-600" aria-hidden="true">
                            ·
                          </span>
                          <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                            {item.ar}
                          </span>
                        </>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onSpeak(item.exampleEn || item.phrase)}
                        aria-label={`نطق ${item.phrase}`}
                        className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
                      >
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onToggleSaveNote({
                            id: noteId,
                            parentWord: wordEn,
                            kind: 'idiom',
                            text: item.phrase,
                            meaningAr: item.ar,
                            extra: item.exampleEn,
                          })
                        }
                        aria-label={isSaved ? `إزالة ${item.phrase}` : `حفظ ${item.phrase}`}
                        className={`flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${
                          isSaved
                            ? 'text-indigo-600 dark:text-indigo-400'
                            : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                  {item.exampleEn && (
                    <p dir="ltr" className="mt-1.5 text-left font-en text-xs text-slate-600 dark:text-slate-300">
                      {item.exampleEn}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </WordHubCollapsibleCard>
      )}

      {/* 6. Phrasal Verbs (ONLY shown when real phrasal verbs exist) */}
      {phrasalVerbs.length > 0 && (
        <WordHubCollapsibleCard
          title="الأفعال المركبة (Phrasal Verbs)"
          subtitle="أفعال مركبة حقيقية مرتبطة بهذه الكلمة"
          count={phrasalVerbs.length}
          icon={<Compass className="h-4 w-4" aria-hidden="true" />}
          defaultOpen={false}
        >
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {phrasalVerbs.map((pv) => {
              const noteId = makeNoteId(wordEn, 'phrasal_verb', pv.phrase);
              const isSaved = savedNoteIds.has(noteId);
              return (
                <div key={pv.phrase} className="py-3.5 first:pt-0 last:pb-0">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span dir="ltr" className="font-en text-sm font-extrabold text-slate-900 dark:text-slate-100">
                        {pv.phrase}
                      </span>
                      {!hideTranslation && (
                        <>
                          <span className="text-slate-300 dark:text-slate-600" aria-hidden="true">
                            ·
                          </span>
                          <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                            {pv.ar}
                          </span>
                        </>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => onSpeak(pv.exampleEn || pv.phrase)}
                        aria-label={`نطق ${pv.phrase}`}
                        className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
                      >
                        <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onToggleSaveNote({
                            id: noteId,
                            parentWord: wordEn,
                            kind: 'phrasal_verb',
                            text: pv.phrase,
                            meaningAr: pv.ar,
                            extra: pv.exampleEn,
                          })
                        }
                        aria-label={isSaved ? `إزالة ${pv.phrase}` : `حفظ ${pv.phrase}`}
                        className={`flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${
                          isSaved
                            ? 'text-indigo-600 dark:text-indigo-400'
                            : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <Bookmark className={`h-3.5 w-3.5 ${isSaved ? 'fill-current' : ''}`} aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                  {pv.exampleEn && (
                    <p dir="ltr" className="mt-1.5 text-left font-en text-xs text-slate-600 dark:text-slate-300">
                      {pv.exampleEn}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </WordHubCollapsibleCard>
      )}
    </div>
  );
}
