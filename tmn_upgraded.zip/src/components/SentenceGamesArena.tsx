import { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowLeft,
  CheckCircle2,
  Eye,
  Headphones,
  Lightbulb,
  RotateCcw,
  Trophy,
  Volume2,
} from 'lucide-react';
import { useI18n } from '../contexts/LanguageContext';
import type { SentenceGameModeId } from '../types';
import {
  buildErrorDetectionRound,
  buildSentenceDictationRound,
  buildSentenceOrderRound,
  checkSentenceDictation,
  checkSentenceOrder,
  ERROR_TYPE_LABELS,
  type SentenceDictationCheckResult,
  type SentenceDictationQuestion,
  type SentenceErrorCategory,
  type SentenceErrorQuestion,
  type SentenceOrderQuestion,
  type SentenceOrderTile,
} from '../utils/sentenceGamesLogic';

interface SentenceGamesArenaProps {
  mode: SentenceGameModeId;
  ttsRate: number;
  onSpeak: (text: string) => void;
  onSpeakSlow: (text: string) => void;
  onSfx: (type: 'ok' | 'err' | 'tap' | 'win') => void;
  onEarnXp: (xpDelta: number) => void;
  onHudChange: (hud: { current: number; total: number; correct: number; wrong: number }) => void;
  onRoundComplete?: () => void;
  onExit: () => void;
}

const ROUND_SIZE = 10;

export function SentenceGamesArena({
  mode,
  onSpeak,
  onSpeakSlow,
  onSfx,
  onEarnXp,
  onHudChange,
  onRoundComplete,
  onExit,
}: SentenceGamesArenaProps) {
  const { t } = useI18n();
  const [roundSeed, setRoundSeed] = useState(() => Date.now());
  const [errorCategory, setErrorCategory] = useState<'all' | SentenceErrorCategory>('all');

  const orderQuestions = useMemo(
    () => (mode === 'sentence_order' ? buildSentenceOrderRound(ROUND_SIZE, roundSeed) : []),
    [mode, roundSeed]
  );

  const errorQuestions = useMemo(
    () =>
      mode === 'sentence_error'
        ? buildErrorDetectionRound(ROUND_SIZE, errorCategory, roundSeed)
        : [],
    [mode, errorCategory, roundSeed]
  );

  const dictationQuestions = useMemo(
    () => (mode === 'sentence_dictation' ? buildSentenceDictationRound(8, roundSeed) : []),
    [mode, roundSeed]
  );

  const total =
    mode === 'sentence_order'
      ? orderQuestions.length
      : mode === 'sentence_error'
        ? errorQuestions.length
        : dictationQuestions.length;

  const [qIdx, setQIdx] = useState(0);
  const [pickedTiles, setPickedTiles] = useState<SentenceOrderTile[]>([]);
  const [pickedErrorIndex, setPickedErrorIndex] = useState<number | null>(null);
  const [dictInput, setDictInput] = useState('');
  const [dictShowMeaning, setDictShowMeaning] = useState(false);
  const [dictResult, setDictResult] = useState<SentenceDictationCheckResult | null>(null);
  const [answered, setAnswered] = useState(false);
  const [lastCorrect, setLastCorrect] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [wrongCount, setWrongCount] = useState(0);
  const [finished, setFinished] = useState(false);

  const dictInputRef = useRef<HTMLInputElement | null>(null);

  const curOrder: SentenceOrderQuestion | undefined =
    mode === 'sentence_order' ? orderQuestions[qIdx] : undefined;
  const curError: SentenceErrorQuestion | undefined =
    mode === 'sentence_error' ? errorQuestions[qIdx] : undefined;
  const curDict: SentenceDictationQuestion | undefined =
    mode === 'sentence_dictation' ? dictationQuestions[qIdx] : undefined;

  useEffect(() => {
    onHudChange({
      current: finished ? total : Math.min(qIdx + 1, Math.max(1, total)),
      total,
      correct: correctCount,
      wrong: wrongCount,
    });
  }, [finished, qIdx, total, correctCount, wrongCount, onHudChange]);

  // Auto-speak sentence when entering a new dictation question
  useEffect(() => {
    if (mode !== 'sentence_dictation' || !curDict || finished) return;
    const timer = window.setTimeout(() => {
      onSpeak(curDict.en);
      dictInputRef.current?.focus();
    }, 180);
    return () => window.clearTimeout(timer);
  }, [mode, curDict, finished, onSpeak]);

  const resetQuestionState = () => {
    setPickedTiles([]);
    setPickedErrorIndex(null);
    setDictInput('');
    setDictShowMeaning(false);
    setDictResult(null);
    setAnswered(false);
    setLastCorrect(false);
  };

  const handleRestart = (nextCategory?: 'all' | SentenceErrorCategory) => {
    if (nextCategory) setErrorCategory(nextCategory);
    setRoundSeed(Date.now());
    setQIdx(0);
    setCorrectCount(0);
    setWrongCount(0);
    setFinished(false);
    resetQuestionState();
    window.scrollTo({ top: 0 });
  };

  const handleNext = () => {
    if (qIdx >= total - 1) {
      setFinished(true);
      onSfx('win');
      onRoundComplete?.();
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    setQIdx((i) => i + 1);
    resetQuestionState();
    window.scrollTo({ top: 0 });
  };

  // --- Sentence Order Handlers ---
  const handlePickWordTile = (tile: SentenceOrderTile) => {
    if (answered || !curOrder) return;
    if (pickedTiles.some((x) => x.id === tile.id)) return;
    onSfx('tap');
    setPickedTiles((prev) => [...prev, tile]);
  };

  const handleRemovePickedTile = (tileId: number) => {
    if (answered) return;
    onSfx('tap');
    setPickedTiles((prev) => prev.filter((x) => x.id !== tileId));
  };

  const handleOrderHint = () => {
    if (answered || !curOrder) return;
    let prefixLen = 0;
    while (
      prefixLen < pickedTiles.length &&
      pickedTiles[prefixLen].word.toLowerCase() === curOrder.targetWords[prefixLen].toLowerCase()
    ) {
      prefixLen += 1;
    }
    if (prefixLen >= curOrder.targetWords.length) return;

    const validPrefix = pickedTiles.slice(0, prefixLen);
    const usedIds = new Set(validPrefix.map((x) => x.id));
    const neededWord = curOrder.targetWords[prefixLen].toLowerCase();
    const matchTile = curOrder.tiles.find(
      (x) => !usedIds.has(x.id) && x.word.toLowerCase() === neededWord
    );
    if (!matchTile) return;
    onSfx('tap');
    setPickedTiles([...validPrefix, matchTile]);
  };

  const handleCheckOrder = () => {
    if (answered || !curOrder || pickedTiles.length === 0) return;
    const ok = checkSentenceOrder(
      pickedTiles.map((x) => x.word),
      curOrder.targetWords
    );
    setAnswered(true);
    setLastCorrect(ok);
    if (ok) {
      setCorrectCount((c) => c + 1);
      onEarnXp(15);
      onSfx('ok');
      onSpeak(curOrder.en);
    } else {
      setWrongCount((c) => c + 1);
      onSfx('err');
    }
  };

  // --- Error Detection Handlers ---
  const handlePickUnderlined = (tokenIdx: number) => {
    if (answered || !curError) return;
    const ok = tokenIdx === curError.errorIndex;
    setPickedErrorIndex(tokenIdx);
    setAnswered(true);
    setLastCorrect(ok);
    if (ok) {
      setCorrectCount((c) => c + 1);
      onEarnXp(15);
      onSfx('ok');
    } else {
      setWrongCount((c) => c + 1);
      onSfx('err');
    }
  };

  // --- Sentence Dictation Handlers ---
  const handleCheckDictation = () => {
    if (answered || !curDict || !dictInput.trim()) return;
    const res = checkSentenceDictation(dictInput, curDict.en);
    setDictResult(res);
    const ok = res.isExact || res.accuracyPct >= 90;
    setAnswered(true);
    setLastCorrect(ok);
    if (ok) {
      setCorrectCount((c) => c + 1);
      onEarnXp(20);
      onSfx('ok');
    } else {
      setWrongCount((c) => c + 1);
      onSfx('err');
    }
  };

  // Keyboard shortcuts for desktop comfort (Enter -> Check/Next, Ctrl+Space -> replay)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (finished) return;
      if (e.ctrlKey && e.code === 'Space') {
        e.preventDefault();
        if (curDict) onSpeak(curDict.en);
        else if (curOrder) onSpeak(curOrder.en);
        return;
      }
      if (e.key === 'Enter' && !e.shiftKey) {
        if (answered) {
          e.preventDefault();
          handleNext();
        } else if (mode === 'sentence_dictation' && dictInput.trim()) {
          e.preventDefault();
          handleCheckDictation();
        } else if (
          mode === 'sentence_order' &&
          curOrder &&
          pickedTiles.length === curOrder.targetWords.length
        ) {
          e.preventDefault();
          handleCheckOrder();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  // ===================== SUMMARY SCREEN =====================
  if (finished) {
    const pct = Math.round((correctCount / Math.max(1, correctCount + wrongCount)) * 100);
    return (
      <div className="mx-auto max-w-2xl space-y-5 pb-20">
        <div className="rounded-2xl border border-slate-200 bg-white p-8 text-center dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-400">
            <Trophy className="h-7 w-7" aria-hidden="true" />
          </div>
          <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100">
            {mode === 'sentence_order'
              ? t.sentOrderTitle
              : mode === 'sentence_error'
                ? t.sentErrorTitle
                : t.sentDictTitle}
          </h1>
          <div
            className={`mt-2 font-code text-5xl font-extrabold tabular-nums ${
              pct >= 80
                ? 'text-emerald-600 dark:text-emerald-400'
                : pct >= 50
                  ? 'text-amber-600 dark:text-amber-400'
                  : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {pct}%
          </div>
          <div className="mt-3 flex flex-wrap items-center justify-center gap-3 text-sm font-bold">
            <span className="text-emerald-600 dark:text-emerald-400">✓ {correctCount}</span>
            <span aria-hidden="true">·</span>
            <span className="text-rose-600 dark:text-rose-400">✕ {wrongCount}</span>
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => handleRestart()}
              className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-5 text-sm font-bold text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
            >
              <RotateCcw className="h-4 w-4" aria-hidden="true" />
              <span>{t.retry}</span>
            </button>
            <button
              type="button"
              onClick={onExit}
              className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-6 text-sm font-bold text-white hover:bg-indigo-700"
            >
              <span>{t.back}</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const pct = Math.round(((qIdx + (answered ? 1 : 0)) / Math.max(1, total)) * 100);
  const pickedIdSet = new Set(pickedTiles.map((x) => x.id));

  return (
    <div className="mx-auto max-w-3xl space-y-5 pb-40">
      {/* Progress Bar */}
      <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
        <div
          className="h-full rounded-full bg-indigo-600 transition-all duration-200 dark:bg-indigo-500"
          style={{ width: `${pct}%` }}
        />
      </div>

      {/* Category Filter for Error Detection */}
      {mode === 'sentence_error' && (
        <div className="flex flex-wrap items-center justify-center gap-2">
          {(
            [
              { id: 'all', label: 'كل الأخطاء' },
              { id: 'grammar', label: 'قواعدي' },
              { id: 'spelling', label: 'إملائي' },
              { id: 'meaning', label: 'بالمعنى' },
            ] as const
          ).map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => handleRestart(cat.id)}
              className={`h-9 rounded-xl border px-3.5 text-xs font-bold transition-colors ${
                errorCategory === cat.id
                  ? 'border-indigo-500 bg-indigo-600 text-white'
                  : 'border-slate-200 bg-white text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-[#131c2e] dark:text-slate-300'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      )}

      {/* ===================== SENTENCE DICTATION MODE (3RD GAME) ===================== */}
      {mode === 'sentence_dictation' && curDict && (
        <div
          data-testid="sentence-dictation-card"
          className="rounded-2xl border border-slate-200 bg-white p-6 text-center dark:border-slate-800 dark:bg-[#131c2e] sm:p-8"
        >
          <div className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
            <Headphones className="h-3.5 w-3.5" aria-hidden="true" />
            <span>{t.sentDictTitle}</span>
          </div>

          <p className="mt-3 text-sm font-semibold text-slate-600 dark:text-slate-300">
            {t.dictationListenHint}
          </p>

          {/* Audio Controls */}
          <div className="mt-5 flex flex-wrap items-center justify-center gap-2.5">
            <button
              type="button"
              data-testid="dictation-play-btn"
              onClick={() => onSpeak(curDict.en)}
              className="inline-flex h-12 items-center gap-2 rounded-2xl bg-indigo-600 px-6 text-sm font-extrabold text-white shadow-md hover:bg-indigo-700"
            >
              <Volume2 className="h-5 w-5" aria-hidden="true" />
              <span>{t.listen}</span>
            </button>
            <button
              type="button"
              onClick={() => onSpeakSlow(curDict.en)}
              className="inline-flex h-12 items-center gap-1.5 rounded-2xl border border-slate-200 bg-slate-50 px-4 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            >
              <span>{t.slow} (0.65x)</span>
            </button>
            <button
              type="button"
              onClick={() => setDictShowMeaning((v) => !v)}
              className="inline-flex h-12 items-center gap-1.5 rounded-2xl border border-slate-200 bg-slate-50 px-4 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            >
              <Eye className="h-4 w-4" aria-hidden="true" />
              <span>{t.dictationShowMeaning}</span>
            </button>
          </div>

          {dictShowMeaning && (
            <div className="mt-3 rounded-xl border border-indigo-500/25 bg-indigo-50/70 px-4 py-2 text-sm font-bold text-indigo-800 dark:bg-indigo-500/10 dark:text-indigo-200">
              {curDict.ar}
            </div>
          )}

          {/* English Dictation Input */}
          <div className="mt-6">
            <input
              ref={dictInputRef}
              type="text"
              dir="ltr"
              data-testid="dictation-input"
              disabled={answered}
              value={dictInput}
              onChange={(e) => setDictInput(e.target.value)}
              placeholder={t.dictationPlaceholder}
              className="w-full rounded-2xl border-2 border-slate-300 bg-slate-50 px-4 py-4 text-left font-en text-base font-bold text-slate-900 outline-none transition focus:border-indigo-500 focus:bg-white disabled:opacity-75 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-100 sm:text-lg"
            />
            <div className="mt-2 flex items-center justify-between text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              <span>{curDict.wordCount} words</span>
              <span dir="ltr">Ctrl + Space = Replay · Enter = {t.check}</span>
            </div>
          </div>

          {/* Word-by-Word Diff Comparison */}
          {answered && dictResult && (
            <div
              data-testid="dictation-feedback"
              className={`mt-5 rounded-2xl border p-4 text-start ${
                lastCorrect
                  ? 'border-emerald-500/40 bg-emerald-50/70 dark:bg-emerald-500/10'
                  : 'border-rose-500/40 bg-rose-50/70 dark:bg-rose-500/10'
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span
                  className={`inline-flex items-center gap-1.5 text-sm font-extrabold ${
                    lastCorrect
                      ? 'text-emerald-700 dark:text-emerald-300'
                      : 'text-rose-700 dark:text-rose-300'
                  }`}
                >
                  <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                  <span>{lastCorrect ? t.dictationCorrectMsg : t.dictationWrongMsg}</span>
                </span>
                <span className="rounded-lg bg-slate-900 px-2.5 py-0.5 font-code text-xs font-extrabold text-white dark:bg-slate-800">
                  {dictResult.accuracyPct}%
                </span>
              </div>

              <div
                dir="ltr"
                className="mt-3 flex flex-wrap gap-1.5 rounded-xl border border-slate-200/80 bg-white/80 p-3 font-en text-base font-bold dark:border-slate-700/80 dark:bg-slate-900/60"
              >
                {dictResult.tokens.map((tk, idx) => (
                  <span
                    key={idx}
                    className={`rounded-lg px-2 py-0.5 ${
                      tk.correct
                        ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                        : 'bg-rose-500/20 text-rose-700 underline decoration-rose-500 decoration-wavy underline-offset-4 dark:text-rose-300'
                    }`}
                  >
                    {tk.expected}
                  </span>
                ))}
              </div>

              <p className="mt-2.5 text-xs font-bold text-slate-600 dark:text-slate-300">
                {curDict.ar}
              </p>
            </div>
          )}
        </div>
      )}

      {/* ===================== SENTENCE ORDERING MODE ===================== */}
      {mode === 'sentence_order' && curOrder && (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center dark:border-slate-800 dark:bg-[#131c2e] sm:p-8">
          <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
            رتّب الكلمات التالية لتكوين الجملة الإنجليزية الصحيحة
          </p>

          <div className="mt-3 text-xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-2xl">
            {curOrder.ar}
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => onSpeak(curOrder.en)}
              className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{t.listen}</span>
            </button>
            <button
              type="button"
              onClick={() => onSpeakSlow(curOrder.en)}
              className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
            >
              <span>{t.slow}</span>
            </button>
            {!answered && pickedTiles.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  onSfx('tap');
                  setPickedTiles([]);
                }}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                <span>مسح</span>
              </button>
            )}
          </div>

          {/* Sentence Construction Tray */}
          <div
            dir="ltr"
            className="mt-6 flex min-h-[76px] flex-wrap items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-slate-300 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-900/50"
          >
            {pickedTiles.length === 0 ? (
              <span className="text-xs font-semibold text-slate-400" dir="rtl">
                اضغط على الكلمات بالأسفل بالترتيب الصحيح...
              </span>
            ) : (
              pickedTiles.map((tile, idx) => {
                const isWordOk =
                  answered &&
                  tile.word.toLowerCase() === (curOrder.targetWords[idx] || '').toLowerCase();
                return (
                  <button
                    key={tile.id}
                    type="button"
                    disabled={answered}
                    onClick={() => handleRemovePickedTile(tile.id)}
                    className={`rounded-xl border-2 px-3.5 py-2 font-en text-base font-bold transition-colors ${
                      answered
                        ? isWordOk
                          ? 'border-emerald-500 bg-emerald-600 text-white'
                          : 'border-rose-500 bg-rose-600 text-white'
                        : 'border-indigo-600 bg-indigo-600 text-white hover:bg-indigo-700'
                    }`}
                  >
                    {tile.word}
                  </button>
                );
              })
            )}
          </div>

          {/* Shuffled Word Bank */}
          {!answered && (
            <div dir="ltr" className="mt-6 flex flex-wrap justify-center gap-2.5">
              {curOrder.tiles.map((tile) => {
                const used = pickedIdSet.has(tile.id);
                return (
                  <button
                    key={tile.id}
                    type="button"
                    disabled={used}
                    onClick={() => handlePickWordTile(tile)}
                    className="min-h-[44px] rounded-xl border-2 border-slate-300 bg-white px-4 py-2 font-en text-base font-bold text-slate-900 shadow-xs transition-all hover:border-indigo-500 active:scale-95 disabled:opacity-20 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                  >
                    {tile.word}
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ===================== SENTENCE ERROR DETECTION MODE ===================== */}
      {mode === 'sentence_error' && curError && (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center dark:border-slate-800 dark:bg-[#131c2e] sm:p-8">
          <div className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-50 px-3 py-1 text-xs font-bold text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300">
            <AlertCircle className="h-3.5 w-3.5" aria-hidden="true" />
            <span>اضغط على الكلمة الخاطئة من بين الكلمات الـ 4 التي تحتها خط</span>
          </div>

          <p className="mt-3 text-sm font-semibold text-slate-500 dark:text-slate-400">
            المعنى المقصود:{' '}
            <span className="font-bold text-slate-800 dark:text-slate-200">{curError.ar}</span>
          </p>

          <div
            dir="ltr"
            className="mt-6 rounded-2xl border border-slate-200 bg-slate-50 px-5 py-7 text-center font-en text-xl leading-[2.4] font-bold text-slate-900 dark:border-slate-700/80 dark:bg-slate-900/50 dark:text-slate-100 sm:text-2xl"
          >
            {curError.tokens.map((token, idx) => {
              const underlinePos = curError.underlinedIndices.indexOf(idx);
              if (underlinePos === -1) {
                return (
                  <span key={idx} className="mx-1 inline-block">
                    {token}
                  </span>
                );
              }

              const isErrorWord = idx === curError.errorIndex;
              const isPicked = idx === pickedErrorIndex;

              let btnClass =
                'border-b-[3px] border-indigo-500 text-indigo-700 hover:bg-indigo-100/70 dark:border-cyan-400 dark:text-cyan-300 dark:hover:bg-cyan-500/20';
              if (answered) {
                if (isErrorWord) {
                  btnClass =
                    'border-b-[3px] border-emerald-500 bg-emerald-100 text-emerald-800 dark:bg-emerald-500/25 dark:text-emerald-200';
                } else if (isPicked) {
                  btnClass =
                    'border-b-[3px] border-rose-500 bg-rose-100 text-rose-800 dark:bg-rose-500/25 dark:text-rose-200';
                } else {
                  btnClass =
                    'border-b-[3px] border-slate-400 text-slate-500 opacity-70 dark:text-slate-400';
                }
              }

              return (
                <button
                  key={idx}
                  type="button"
                  disabled={answered}
                  onClick={() => handlePickUnderlined(idx)}
                  aria-label={`الكلمة رقم ${underlinePos + 1}: ${token}`}
                  className={`mx-1 inline-flex items-baseline gap-1 rounded-md px-2 py-0.5 transition-colors ${btnClass}`}
                >
                  <span>{token}</span>
                  <sup className="font-code text-[10px] font-extrabold opacity-75">
                    {underlinePos + 1}
                  </sup>
                </button>
              );
            })}
          </div>

          <div className="mt-5 grid grid-cols-2 gap-2.5 sm:grid-cols-4" dir="ltr">
            {curError.underlinedIndices.map((tokenIdx, optNum) => {
              const wordLabel = curError.tokens[tokenIdx];
              const isErrorWord = tokenIdx === curError.errorIndex;
              const isPicked = tokenIdx === pickedErrorIndex;
              let cls =
                'border-slate-200 bg-slate-50 text-slate-800 hover:border-indigo-500 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-100';
              if (answered) {
                if (isErrorWord) {
                  cls =
                    'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300';
                } else if (isPicked) {
                  cls =
                    'border-rose-500 bg-rose-50 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300';
                }
              }
              return (
                <button
                  key={tokenIdx}
                  type="button"
                  disabled={answered}
                  onClick={() => handlePickUnderlined(tokenIdx)}
                  className={`flex min-h-[48px] items-center justify-center gap-2 rounded-xl border-2 px-3 py-2 font-en text-sm font-extrabold transition-colors ${cls}`}
                >
                  <span className="flex h-5 w-5 items-center justify-center rounded bg-slate-200/80 font-code text-[11px] text-slate-700 dark:bg-slate-700 dark:text-slate-200">
                    {optNum + 1}
                  </span>
                  <span className="underline decoration-2 underline-offset-4">{wordLabel}</span>
                </button>
              );
            })}
          </div>

          {answered && (
            <div
              className={`mt-5 rounded-2xl border p-4 text-right ${
                lastCorrect
                  ? 'border-emerald-500/40 bg-emerald-50/70 dark:bg-emerald-500/10'
                  : 'border-rose-500/40 bg-rose-50/70 dark:bg-rose-500/10'
              }`}
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span
                  className={`inline-flex items-center gap-1.5 text-sm font-extrabold ${
                    lastCorrect
                      ? 'text-emerald-700 dark:text-emerald-300'
                      : 'text-rose-700 dark:text-rose-300'
                  }`}
                >
                  <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                  <span>{lastCorrect ? 'أحسنت! اكتشفت الخطأ بنجاح' : 'ليست هذه الكلمة الخاطئة'}</span>
                </span>
                <span className="rounded-lg bg-indigo-600 px-2.5 py-0.5 text-xs font-bold text-white">
                  {ERROR_TYPE_LABELS[curError.errorType]}
                </span>
              </div>

              <div className="mt-2.5 text-sm font-bold text-slate-900 dark:text-slate-100">
                التصحيح:{' '}
                <span dir="ltr" className="mx-1 font-en text-rose-600 line-through dark:text-rose-400">
                  {curError.wrongWord}
                </span>
                ⟵
                <span dir="ltr" className="mx-1 font-en text-emerald-600 dark:text-emerald-400">
                  {curError.correctWord}
                </span>
              </div>

              <p className="mt-1.5 text-xs leading-relaxed font-semibold text-slate-700 dark:text-slate-300">
                {curError.explanationAr}
              </p>

              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-slate-200/70 pt-3 dark:border-slate-700/70">
                <p dir="ltr" className="font-en text-sm font-bold text-slate-900 dark:text-slate-100">
                  {curError.correctSentence}
                </p>
                <button
                  type="button"
                  onClick={() => onSpeak(curError.correctSentence)}
                  className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  <Volume2 className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{t.listen}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Bottom Action Dock */}
      <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-200 bg-white/95 p-3 backdrop-blur-md dark:border-slate-800 dark:bg-[#0f172a]/95">
        <div className="mx-auto max-w-3xl space-y-2.5">
          {answered ? (
            <>
              {mode === 'sentence_order' && curOrder && (
                <div
                  className={`flex flex-wrap items-center justify-between gap-2 rounded-xl border px-4 py-2.5 ${
                    lastCorrect
                      ? 'border-emerald-500/40 bg-emerald-50 dark:bg-emerald-500/15'
                      : 'border-rose-500/40 bg-rose-50 dark:bg-rose-500/15'
                  }`}
                >
                  <div className="text-right">
                    <div
                      className={`text-xs font-extrabold ${
                        lastCorrect
                          ? 'text-emerald-700 dark:text-emerald-300'
                          : 'text-rose-700 dark:text-rose-300'
                      }`}
                    >
                      {lastCorrect ? 'ترتيب صحيح ممتاز! (+15 XP)' : 'الترتيب الصحيح هو:'}
                    </div>
                    <div dir="ltr" className="font-en text-sm font-bold text-slate-900 dark:text-slate-100">
                      {curOrder.en}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSpeak(curOrder.en)}
                    className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                    aria-label={t.listen}
                  >
                    <Volume2 className="h-4 w-4" aria-hidden="true" />
                  </button>
                </div>
              )}

              <button
                type="button"
                data-testid="sentence-next-btn"
                onClick={handleNext}
                className={`inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl px-6 text-base font-bold text-white transition-colors ${
                  lastCorrect
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-indigo-600 hover:bg-indigo-700'
                }`}
              >
                <span>{t.next}</span>
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
              </button>
            </>
          ) : mode === 'sentence_order' ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleOrderHint}
                className="inline-flex h-11 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              >
                <Lightbulb className="h-4 w-4" aria-hidden="true" />
                <span>تلميح</span>
              </button>
              <button
                type="button"
                disabled={!curOrder || pickedTiles.length !== curOrder.targetWords.length}
                onClick={handleCheckOrder}
                className="h-11 flex-1 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white hover:bg-indigo-700 disabled:opacity-45"
              >
                {t.check}
              </button>
            </div>
          ) : mode === 'sentence_dictation' ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => curDict && onSpeak(curDict.en)}
                className="inline-flex h-11 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <Volume2 className="h-4 w-4" aria-hidden="true" />
                <span>{t.listen}</span>
              </button>
              <button
                type="button"
                data-testid="dictation-check-btn"
                disabled={!dictInput.trim()}
                onClick={handleCheckDictation}
                className="h-11 flex-1 rounded-xl bg-emerald-600 px-5 text-sm font-bold text-white hover:bg-emerald-700 disabled:opacity-45"
              >
                {t.check}
              </button>
            </div>
          ) : (
            <div className="text-center text-xs font-semibold text-slate-500 dark:text-slate-400">
              {t.sentErrorDesc}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

