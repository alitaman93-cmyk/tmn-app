import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Film,
  Headphones,
  ListOrdered,
  Mic,
  Play,
  RefreshCw,
  Search,
  Sparkles,
  Square,
  Star,
  Volume2,
  X,
} from 'lucide-react';
import { useI18n } from '../contexts/LanguageContext';
import type { SentenceEntry, SentenceGameModeId, SpeechEvalResult } from '../types';
import { blobToBase64, evaluateSpeechWithAi, translateSentencesBatch } from '../utils/aiApi';
import { speakEn } from '../utils/audio';
import { fetchWordVideoClips } from '../utils/mediaApi';
import { prefetchSentenceTranslations, prefetchWordVideoClips } from '../utils/prefetchEngine';
import {
  evaluateSpokenMatch,
  filterSentences,
  parseSentencesTSV,
  SENTENCE_SECTIONS,
  STARTER_AR_TRANSLATIONS,
  STARTER_SENTENCES_TSV,
} from '../utils/sentenceLogic';
import { extractSentenceVideoTargets } from '../utils/sentenceVideoLogic';
import {
  getHotSentenceTranslationsSync,
  idbGetSentenceTranslations,
  idbLoadDataset,
  idbSaveDataset,
  idbSetSentenceTranslations,
} from '../utils/storage';
import { WordVideoReelsPlayer } from './WordVideoReelsPlayer';

interface SentencesViewProps {
  ttsRate: number;
  favoriteSentences: number[];
  practicedSentences: number[];
  onToggleFavoriteSentence: (num: number) => void;
  onMarkPracticedSentence: (num: number) => void;
  onStartSentenceGame?: (mode: SentenceGameModeId) => void;
  onToast: (msg: string) => void;
}

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

type SpeechRecognitionCtor = new () => SpeechRecognitionLike;

interface PracticeState {
  audioUrl?: string;
  audioBlob?: Blob;
  audioMimeType?: string;
  evalResult?: SpeechEvalResult;
  evaluatingAi?: boolean;
  errorMsg?: string;
}

const PAGE_SIZE = 15;

function getSpeechRecognitionCtor(): SpeechRecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

export function SentencesView({
  ttsRate,
  favoriteSentences,
  practicedSentences,
  onToggleFavoriteSentence,
  onMarkPracticedSentence,
  onStartSentenceGame,
  onToast,
}: SentencesViewProps) {
  const { lang, t } = useI18n();
  const [sentences, setSentences] = useState<SentenceEntry[]>(() =>
    parseSentencesTSV(STARTER_SENTENCES_TSV)
  );
  const [loadingCorpus, setLoadingCorpus] = useState(true);

  const [tab, setTab] = useState<'all' | 'favorites' | 'practiced'>('all');
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [page, setPage] = useState(0);
  const [activeSectionId, setActiveSectionId] = useState<string>('all');
  const [showAllCategories, setShowAllCategories] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query), query ? 220 : 0);
    return () => clearTimeout(t);
  }, [query]);

  // Arabic translations cache in memory (hydrated from Starter + IndexedDB + Gemini API)
  const [arMap, setArMap] = useState<Record<string, string>>(() => ({
    ...STARTER_AR_TRANSLATIONS,
    ...getHotSentenceTranslationsSync(),
  }));
  const [translatingPage, setTranslatingPage] = useState(false);
  const [translationError, setTranslationError] = useState('');

  // Voice recording & speaking practice state
  const [recordingNum, setRecordingNum] = useState<number | null>(null);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [practiceByNum, setPracticeByNum] = useState<Record<number, PracticeState>>({});

  // Real-speech Video Clips Reels drawer state (only 1 sentence open at a time for zero lag)
  const [videoSentenceNum, setVideoSentenceNum] = useState<number | null>(null);
  const [videoKeywordByNum, setVideoKeywordByNum] = useState<Record<number, string>>({});

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const speechRecRef = useRef<SpeechRecognitionLike | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const transcriptRef = useRef('');
  const activeTargetRef = useRef<SentenceEntry | null>(null);
  const arMapRef = useRef<Record<string, string>>(arMap);
  const audioUrlsRef = useRef<string[]>([]);

  useEffect(() => {
    arMapRef.current = arMap;
  }, [arMap]);

  // Load full 21,708 sentences dataset (IndexedDB instant offline first -> network sync)
  useEffect(() => {
    let active = true;
    const load = async () => {
      let hydratedFromIdb = false;
      try {
        const cached = await idbLoadDataset('sentences-21k.tsv');
        if (active && cached && cached.length > 2000) {
          const parsed = parseSentencesTSV(cached);
          if (active && parsed.length > 100) {
            setSentences(parsed);
            setLoadingCorpus(false);
            hydratedFromIdb = true;
          }
        }
      } catch {
        // Ignore IDB error
      }

      if (hydratedFromIdb) return;

      try {
        const res = await fetch('/sentences-21k.tsv');
        if (res.ok) {
          const text = await res.text();
          void idbSaveDataset('sentences-21k.tsv', text);
          const parsed = parseSentencesTSV(text);
          if (active && parsed.length > 0) {
            setSentences(parsed);
          }
        }
      } catch {
        // Keep starter sentences if offline before precache
      } finally {
        if (active) setLoadingCorpus(false);
      }
    };
    void load();
    return () => {
      active = false;
    };
  }, []);

  // Cleanup active media stream & object URLs on unmount
  useEffect(() => {
    return () => {
      try {
        speechRecRef.current?.stop();
      } catch {
        // Ignore
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        try {
          mediaRecorderRef.current.stop();
        } catch {
          // Ignore
        }
      }
      mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
      audioUrlsRef.current.forEach((u) => URL.revokeObjectURL(u));
    };
  }, []);

  const favSet = useMemo(() => new Set(favoriteSentences), [favoriteSentences]);
  const practicedSet = useMemo(() => new Set(practicedSentences), [practicedSentences]);

  const sectionCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const sec of SENTENCE_SECTIONS) counts[sec.id] = 0;
    for (const s of sentences) {
      for (const sec of SENTENCE_SECTIONS) {
        if (s.num >= sec.startNum && s.num <= sec.endNum) {
          counts[sec.id] += 1;
          break;
        }
      }
    }
    return counts;
  }, [sentences]);

  const filtered = useMemo(
    () => filterSentences(sentences, debouncedQuery, arMap, tab, favSet, practicedSet, activeSectionId),
    [sentences, debouncedQuery, arMap, tab, favSet, practicedSet, activeSectionId]
  );

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages - 1);

  const visibleSentences = useMemo(() => {
    const start = safePage * PAGE_SIZE;
    return filtered.slice(start, start + PAGE_SIZE);
  }, [filtered, safePage]);

  const nextPageSentences = useMemo(() => {
    const start = (safePage + 1) * PAGE_SIZE;
    return start < filtered.length ? filtered.slice(start, start + PAGE_SIZE * 2) : [];
  }, [filtered, safePage]);

  // Automatically hydrate Arabic translations for visible sentences immediately (IDB -> fast browser GTX -> Server AI)
  const fetchMissingTranslations = useCallback(
    async (items: SentenceEntry[], signal?: AbortSignal, silent = false) => {
      const keys = items.map((s) => s.en);
      if (!keys.length) return;

      const missingFromMem = keys.filter((k) => !arMapRef.current[k]);
      if (!missingFromMem.length) {
        if (!silent) setTranslationError('');
        return;
      }

      // Check IndexedDB cache first
      const cached = await idbGetSentenceTranslations(missingFromMem);
      if (signal?.aborted) return;

      if (Object.keys(cached).length > 0) {
        setArMap((prev) => ({ ...prev, ...cached }));
      }

      const stillMissing = missingFromMem.filter((k) => !cached[k]);
      if (!stillMissing.length) {
        if (!silent) setTranslationError('');
        return;
      }

      if (!silent) {
        setTranslatingPage(true);
        setTranslationError('');
      }
      try {
        const fetched = await translateSentencesBatch(stillMissing, signal);
        if (signal?.aborted) return;
        if (Object.keys(fetched).length > 0) {
          setArMap((prev) => ({ ...prev, ...fetched }));
          void idbSetSentenceTranslations(fetched);
        }
      } catch (err) {
        if (!signal?.aborted && !silent) {
          setTranslationError(
            err instanceof Error ? err.message : 'تعذر ترجمة هذه الصفحة حالياً.'
          );
        }
      } finally {
        if (!signal?.aborted && !silent) {
          setTranslatingPage(false);
        }
      }
    },
    []
  );

  useEffect(() => {
    const controller = new AbortController();
    void (async () => {
      await fetchMissingTranslations(visibleSentences, controller.signal, false);
      // Proactively warm video clips for the first 4 visible sentences so tapping "فيديوهات للجملة" is instant
      if (!controller.signal.aborted) {
        const seenKw = new Set<string>();
        for (const s of visibleSentences.slice(0, 4)) {
          const kw = extractSentenceVideoTargets(s.en).primaryQuery;
          if (kw && !seenKw.has(kw)) {
            seenKw.add(kw);
            prefetchWordVideoClips(kw, false);
          }
        }
      }
      // Silently prefetch the next 2 pages so tapping "Next" is 0ms instant!
      if (!controller.signal.aborted && nextPageSentences.length > 0) {
        prefetchSentenceTranslations(nextPageSentences.map((s) => s.en), true);
      }
    })();
    return () => {
      controller.abort();
    };
  }, [visibleSentences, nextPageSentences, fetchMissingTranslations]);

  const stopTracks = () => {
    mediaStreamRef.current?.getTracks().forEach((t) => t.stop());
    mediaStreamRef.current = null;
  };

  const evaluateWithAiFallback = useCallback(
    async (entry: SentenceEntry, blob?: Blob, mimeType?: string, spokenText?: string) => {
      setPracticeByNum((prev) => ({
        ...prev,
        [entry.num]: {
          ...prev[entry.num],
          evaluatingAi: true,
          errorMsg: undefined,
        },
      }));
      try {
        const audioBase64 = blob ? await blobToBase64(blob) : undefined;
        const result = await evaluateSpeechWithAi({
          targetSentence: entry.en,
          spokenText: spokenText || undefined,
          audioBase64,
          audioMimeType: mimeType || blob?.type || 'audio/webm',
        });
        // Merge token highlighting if heardText is available
        const localHighlight = result.heardText
          ? evaluateSpokenMatch(entry.en, result.heardText)
          : null;
        const merged: SpeechEvalResult = {
          ...result,
          tokens: localHighlight?.tokens,
        };
        setPracticeByNum((prev) => ({
          ...prev,
          [entry.num]: {
            ...prev[entry.num],
            evalResult: merged,
            evaluatingAi: false,
            errorMsg: undefined,
          },
        }));
        if (merged.isMatch) {
          onMarkPracticedSentence(entry.num);
        }
      } catch (err) {
        setPracticeByNum((prev) => ({
          ...prev,
          [entry.num]: {
            ...prev[entry.num],
            evaluatingAi: false,
            errorMsg: err instanceof Error ? err.message : 'تعذر تقييم الصوت حالياً.',
          },
        }));
      }
    },
    [onMarkPracticedSentence]
  );

  const finalizeRecording = useCallback(
    (entry: SentenceEntry, blob: Blob | null, mimeType: string, capturedText: string) => {
      let audioUrl: string | undefined;
      if (blob && blob.size > 0) {
        audioUrl = URL.createObjectURL(blob);
        audioUrlsRef.current.push(audioUrl);
      }

      const trimmedText = capturedText.trim();
      if (trimmedText) {
        const localEval = evaluateSpokenMatch(entry.en, trimmedText);
        setPracticeByNum((prev) => ({
          ...prev,
          [entry.num]: {
            audioUrl,
            audioBlob: blob || undefined,
            audioMimeType: mimeType,
            evalResult: localEval,
            evaluatingAi: false,
          },
        }));
        if (localEval.isMatch) {
          onMarkPracticedSentence(entry.num);
        }
      } else if (blob && blob.size > 500) {
        // Browser SpeechRecognition wasn't available or didn't fire -> evaluate audio directly via Gemini
        setPracticeByNum((prev) => ({
          ...prev,
          [entry.num]: {
            audioUrl,
            audioBlob: blob,
            audioMimeType: mimeType,
            evaluatingAi: true,
          },
        }));
        void evaluateWithAiFallback(entry, blob, mimeType);
      } else {
        setPracticeByNum((prev) => ({
          ...prev,
          [entry.num]: {
            ...prev[entry.num],
            errorMsg: 'لم يتم التقاط صوت كافٍ. اضغط للتسجيل وتحدث بوضوح ثم أوقف التسجيل.',
          },
        }));
      }
    },
    [evaluateWithAiFallback, onMarkPracticedSentence]
  );

  const stopRecording = useCallback(() => {
    const target = activeTargetRef.current;
    try {
      speechRecRef.current?.stop();
    } catch {
      // Ignore
    }
    speechRecRef.current = null;

    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      recorder.stop();
    } else if (target) {
      stopTracks();
      setRecordingNum(null);
      finalizeRecording(target, null, 'audio/webm', transcriptRef.current);
      activeTargetRef.current = null;
    }
  }, [finalizeRecording]);

  const startRecording = useCallback(
    async (entry: SentenceEntry) => {
      if (recordingNum !== null) {
        stopRecording();
        if (recordingNum === entry.num) return;
      }

      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }

      activeTargetRef.current = entry;
      transcriptRef.current = '';
      chunksRef.current = [];
      setLiveTranscript('');
      setRecordingNum(entry.num);
      setPracticeByNum((prev) => ({
        ...prev,
        [entry.num]: {
          ...prev[entry.num],
          errorMsg: undefined,
        },
      }));

      // Start Web Speech Recognition (en-US) in parallel when available
      const SR = getSpeechRecognitionCtor();
      if (SR) {
        try {
          const rec = new SR();
          rec.lang = 'en-US';
          rec.continuous = true;
          rec.interimResults = true;
          rec.onresult = (event) => {
            let combined = '';
            for (let i = 0; i < event.results.length; i++) {
              combined += event.results[i][0].transcript + ' ';
            }
            const clean = combined.trim();
            transcriptRef.current = clean;
            setLiveTranscript(clean);
          };
          rec.onerror = () => {
            // Silently fall back to MediaRecorder audio evaluation
          };
          rec.start();
          speechRecRef.current = rec;
        } catch {
          speechRecRef.current = null;
        }
      }

      // Start MediaRecorder so user can ALWAYS play back their own voice & use AI audio grading
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          mediaStreamRef.current = stream;

          const preferredMime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
            ? 'audio/webm;codecs=opus'
            : MediaRecorder.isTypeSupported('audio/webm')
              ? 'audio/webm'
              : MediaRecorder.isTypeSupported('audio/mp4')
                ? 'audio/mp4'
                : '';

          const recorder = preferredMime
            ? new MediaRecorder(stream, { mimeType: preferredMime })
            : new MediaRecorder(stream);

          const actualMime = (recorder.mimeType || preferredMime || 'audio/webm').split(';')[0];

          recorder.ondataavailable = (ev) => {
            if (ev.data && ev.data.size > 0) {
              chunksRef.current.push(ev.data);
            }
          };

          recorder.onstop = () => {
            const blob = new Blob(chunksRef.current, { type: actualMime });
            chunksRef.current = [];
            stopTracks();
            mediaRecorderRef.current = null;
            setRecordingNum(null);
            const currentEntry = activeTargetRef.current;
            activeTargetRef.current = null;
            if (currentEntry) {
              finalizeRecording(currentEntry, blob, actualMime, transcriptRef.current);
            }
          };

          mediaRecorderRef.current = recorder;
          recorder.start();
        } catch {
          if (!speechRecRef.current) {
            setRecordingNum(null);
            activeTargetRef.current = null;
            onToast('يرجى السماح بصلاحية الميكروفون من المتصفح للتدرب بصوتك.');
          }
        }
      } else if (!speechRecRef.current) {
        setRecordingNum(null);
        activeTargetRef.current = null;
        onToast('الميكروفون غير مدعوم في هذا المتصفح.');
      }
    },
    [recordingNum, stopRecording, finalizeRecording, onToast]
  );

  const playUserRecording = (audioUrl: string) => {
    const audio = new Audio(audioUrl);
    void audio.play().catch(() => {
      onToast('تعذر تشغيل التسجيل الصوتي.');
    });
  };

  const handleSelectSection = (sectionId: string) => {
    setActiveSectionId(sectionId);
    setPage(0);
  };

  const activeSectionMeta = useMemo(
    () => SENTENCE_SECTIONS.find((s) => s.id === activeSectionId) || null,
    [activeSectionId]
  );

  const visibleCategories = showAllCategories
    ? SENTENCE_SECTIONS
    : SENTENCE_SECTIONS.slice(0, 12);

  return (
    <div className="space-y-5">
      {/* Header & Summary */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#162032]">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-2xl">
              مكتبة الجمل الإنجليزية ({sentences.length.toLocaleString('en-US')} جملة)
            </h1>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              استمع للنطق الصحيح، اقرأ الترجمة العربية، وسجّل صوتك للتدريب الفوري على كل جملة.
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs font-bold">
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-emerald-700 dark:border-emerald-800/60 dark:bg-emerald-950/40 dark:text-emerald-300">
              تدرّبت على{' '}
              <span className="font-code tabular-nums">
                {practicedSentences.length.toLocaleString('en-US')}
              </span>
            </div>
            <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-amber-700 dark:border-amber-800/60 dark:bg-amber-950/40 dark:text-amber-300">
              المفضلة{' '}
              <span className="font-code tabular-nums">
                {favoriteSentences.length.toLocaleString('en-US')}
              </span>
            </div>
          </div>
        </div>

        {/* Sentence Games Quick Launchers */}
        {onStartSentenceGame && (
          <div className="mt-4 flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => onStartSentenceGame('sentence_order')}
              className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-4 text-xs font-bold text-white transition-colors hover:bg-indigo-700"
            >
              <ListOrdered className="h-4 w-4" aria-hidden="true" />
              <span>{t.sentOrderTitle}</span>
            </button>
            <button
              type="button"
              onClick={() => onStartSentenceGame('sentence_error')}
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-4 text-xs font-bold text-amber-900 transition-colors hover:bg-amber-100 dark:border-amber-600/50 dark:bg-amber-950/40 dark:text-amber-200 dark:hover:bg-amber-900/50"
            >
              <AlertCircle className="h-4 w-4" aria-hidden="true" />
              <span>{t.sentErrorTitle}</span>
            </button>
            <button
              type="button"
              onClick={() => onStartSentenceGame('sentence_dictation')}
              className="inline-flex h-10 items-center gap-2 rounded-xl border border-sky-300 bg-sky-50 px-4 text-xs font-bold text-sky-900 transition-colors hover:bg-sky-100 dark:border-sky-600/50 dark:bg-sky-950/40 dark:text-sky-200 dark:hover:bg-sky-900/50"
            >
              <Headphones className="h-4 w-4" aria-hidden="true" />
              <span>{t.sentDictTitle}</span>
            </button>
          </div>
        )}

        {/* Search & Filter Row */}
        <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search
              className="pointer-events-none absolute top-1/2 right-3.5 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setPage(0);
              }}
              placeholder="ابحث بالإنجليزية أو برقم الجملة (مثلاً: airport أو 4484)..."
              className="h-11 w-full rounded-lg border border-slate-200 bg-slate-50 pr-10 pl-9 text-sm text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:bg-white focus:outline-none dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-100 dark:focus:border-indigo-400 dark:focus:bg-slate-900"
            />
            {query && (
              <button
                type="button"
                onClick={() => {
                  setQuery('');
                  setPage(0);
                }}
                aria-label="مسح البحث"
                className="absolute top-1/2 left-2.5 -translate-y-1/2 rounded p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 p-1 dark:border-slate-700 dark:bg-slate-900/60">
            {(
              [
                { id: 'all', label: 'الكل' },
                { id: 'favorites', label: 'المفضلة' },
                { id: 'practiced', label: 'تدرّبت عليها' },
              ] as const
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setTab(item.id);
                  setPage(0);
                }}
                className={`h-9 rounded-md px-3 text-xs font-bold transition-colors ${
                  tab === item.id
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        {/* Thematic Categories Browser (36 Categories) */}
        <div className="mt-4 border-t border-slate-100 pt-3.5 dark:border-slate-800">
          <div className="mb-2.5 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300">
              <span>تصنيفات الجمل ({SENTENCE_SECTIONS.length} تصنيفاً):</span>
              {activeSectionMeta && (
                <span className="rounded bg-indigo-50 px-2 py-0.5 text-[11px] font-bold text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
                  {activeSectionMeta.label}
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={() => setShowAllCategories((v) => !v)}
              className="text-xs font-bold text-indigo-600 hover:underline dark:text-indigo-400"
            >
              {showAllCategories
                ? 'إخفاء التصنيفات الإضافية'
                : `عرض كل التصنيفات (${SENTENCE_SECTIONS.length})`}
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => handleSelectSection('all')}
              className={`rounded-lg border px-3 py-1.5 text-xs font-bold transition-colors ${
                activeSectionId === 'all'
                  ? 'border-indigo-500 bg-indigo-600 text-white'
                  : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-300 dark:hover:border-indigo-500'
              }`}
            >
              الكل ({sentences.length.toLocaleString('en-US')})
            </button>

            {visibleCategories.map((sec) => {
              const isActive = activeSectionId === sec.id;
              const count = sectionCounts[sec.id] || 0;
              return (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => handleSelectSection(sec.id)}
                  className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
                    isActive
                      ? 'border-indigo-500 bg-indigo-600 text-white'
                      : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-300 dark:hover:border-indigo-500'
                  }`}
                >
                  <span>{sec.label}</span>
                  {count > 0 && (
                    <span
                      className={`mr-1.5 font-code text-[10px] tabular-nums ${
                        isActive ? 'text-indigo-100' : 'text-slate-400'
                      }`}
                    >
                      ({count})
                    </span>
                  )}
                </button>
              );
            })}

            {!showAllCategories && (
              <button
                type="button"
                onClick={() => setShowAllCategories(true)}
                className="rounded-lg border border-dashed border-indigo-400 bg-indigo-50/60 px-3 py-1.5 text-xs font-bold text-indigo-700 hover:bg-indigo-100 dark:border-indigo-500/60 dark:bg-indigo-950/40 dark:text-indigo-300"
              >
                + {SENTENCE_SECTIONS.length - visibleCategories.length} تصنيفاً إضافياً
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Pagination & Status Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-1">
        <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
          {loadingCorpus
            ? 'جاري تحميل جميع الجمل...'
            : `عرض ${filtered.length === 0 ? 0 : safePage * PAGE_SIZE + 1}–${Math.min(
                (safePage + 1) * PAGE_SIZE,
                filtered.length
              )} من ${filtered.length.toLocaleString('en-US')} جملة`}
          {translatingPage && (
            <span className="mr-2 text-indigo-600 dark:text-indigo-400">
              • جاري تجهيز الترجمة العربية...
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {translationError && (
            <button
              type="button"
              onClick={() => void fetchMissingTranslations(visibleSentences)}
              className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-amber-300 bg-amber-50 px-3 text-xs font-bold text-amber-800 dark:border-amber-700 dark:bg-amber-950/50 dark:text-amber-200"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              إعادة الترجمة
            </button>
          )}
          <button
            type="button"
            disabled={safePage <= 0}
            onClick={() => {
              setPage((p) => Math.max(0, p - 1));
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex h-9 items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-[#162032] dark:text-slate-200"
          >
            <ChevronRight className="h-4 w-4" />
            السابق
          </button>
          <span className="font-code text-xs font-bold text-slate-600 tabular-nums dark:text-slate-300">
            {safePage + 1} / {totalPages}
          </span>
          <button
            type="button"
            disabled={safePage >= totalPages - 1}
            onClick={() => {
              setPage((p) => Math.min(totalPages - 1, p + 1));
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex h-9 items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 transition-colors hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-[#162032] dark:text-slate-200"
          >
            التالي
            <ChevronLeft className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Empty State */}
      {visibleSentences.length === 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center dark:border-slate-800 dark:bg-[#162032]">
          <p className="text-sm font-bold text-slate-700 dark:text-slate-200">
            لا توجد جمل مطابقة للبحث أو الفلتر الحالي.
          </p>
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setTab('all');
              setPage(0);
            }}
            className="mt-3 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-700"
          >
            عرض جميع الجمل
          </button>
        </div>
      )}

      {/* Sentences List */}
      <div className="space-y-3">
        {visibleSentences.map((item) => {
          const ar = arMap[item.en];
          const isFav = favSet.has(item.num);
          const isPracticed = practicedSet.has(item.num);
          const isRecordingThis = recordingNum === item.num;
          const practice = practiceByNum[item.num];
          const isVideoOpen = videoSentenceNum === item.num;
          const videoTargets = extractSentenceVideoTargets(item.en);
          const activeVideoKeyword =
            videoKeywordByNum[item.num] || videoTargets.primaryQuery;

          return (
            <article
              key={item.num}
              className={`tmn-card-lift rounded-2xl border bg-white p-4 dark:bg-[#11192b] sm:p-5 ${
                isRecordingThis
                  ? 'border-rose-500 ring-2 ring-rose-500/20 dark:border-rose-500'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              {/* Top Row: Number, English Sentence, Favorite & Practiced */}
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="mb-1.5 flex items-center gap-2">
                    <span className="font-code rounded bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-600 tabular-nums dark:bg-slate-800 dark:text-slate-300">
                      #{item.num}
                    </span>
                    {isPracticed && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        تم التدريب
                      </span>
                    )}
                  </div>

                  <p
                    dir="ltr"
                    className="text-left text-base font-bold leading-relaxed text-slate-900 dark:text-slate-50 sm:text-lg"
                  >
                    {item.en}
                  </p>

                  {/* Arabic Translation */}
                  <div className="mt-2 min-h-[24px]">
                    {ar ? (
                      <p className="text-sm font-medium text-indigo-700 dark:text-indigo-300">
                        {ar}
                      </p>
                    ) : translatingPage ? (
                      <div className="h-4 w-48 animate-pulse rounded bg-slate-200 dark:bg-slate-700/70" />
                    ) : (
                      <button
                        type="button"
                        onClick={() => void fetchMissingTranslations([item])}
                        className="text-xs font-semibold text-slate-400 underline hover:text-indigo-500"
                      >
                        اضغط لعرض الترجمة العربية
                      </button>
                    )}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onToggleFavoriteSentence(item.num)}
                  aria-label={isFav ? 'إزالة من المفضلة' : 'إضافة للمفضلة'}
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border transition-colors ${
                    isFav
                      ? 'border-amber-300 bg-amber-50 text-amber-500 dark:border-amber-700/70 dark:bg-amber-950/40'
                      : 'border-slate-200 bg-slate-50 text-slate-400 hover:text-amber-500 dark:border-slate-700 dark:bg-slate-800/70'
                  }`}
                >
                  <Star className={`h-4 w-4 ${isFav ? 'fill-current' : ''}`} />
                </button>
              </div>

              {/* Controls Bar: Listen, Slow Listen, Record Voice */}
              <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => speakEn(item.en.split('=')[0].trim(), ttsRate, onToast)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3.5 text-xs font-bold text-slate-700 transition-colors hover:border-indigo-400 hover:bg-indigo-50 hover:text-indigo-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:border-indigo-500 dark:hover:bg-indigo-950/50 dark:hover:text-indigo-300"
                >
                  <Volume2 className="h-4 w-4" />
                  استمع للنطق
                </button>

                <button
                  type="button"
                  onClick={() => speakEn(item.en.split('=')[0].trim(), 0.65, onToast)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-semibold text-slate-600 transition-colors hover:border-slate-300 hover:text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:text-white"
                >
                  نطق بطيء
                </button>

                {isRecordingThis ? (
                  <button
                    type="button"
                    onClick={stopRecording}
                    className="inline-flex h-10 items-center gap-2 rounded-lg bg-rose-600 px-4 text-xs font-bold text-white shadow-sm transition-colors hover:bg-rose-700"
                  >
                    <Square className="h-3.5 w-3.5 fill-current" />
                    إيقاف وتقييم النطق
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => void startRecording(item)}
                    className="inline-flex h-10 items-center gap-2 rounded-lg bg-indigo-600 px-4 text-xs font-bold text-white transition-colors hover:bg-indigo-700"
                  >
                    <Mic className="h-4 w-4" />
                    سجّل صوتك للتدريب
                  </button>
                )}

                {videoTargets.primaryQuery && (
                  <button
                    type="button"
                    data-testid={`sentence-video-btn-${item.num}`}
                    onMouseEnter={() => {
                      if (videoTargets.primaryQuery) {
                        void fetchWordVideoClips(videoTargets.primaryQuery, 0).catch(() => {});
                      }
                    }}
                    onClick={() =>
                      setVideoSentenceNum((curr) => (curr === item.num ? null : item.num))
                    }
                    className={`inline-flex h-10 items-center gap-1.5 rounded-lg border px-3.5 text-xs font-bold transition-colors ${
                      isVideoOpen
                        ? 'border-sky-500 bg-sky-500 text-slate-950 shadow-sm'
                        : 'border-sky-300/80 bg-sky-50 text-sky-700 hover:border-sky-500 hover:bg-sky-100 dark:border-sky-500/40 dark:bg-sky-500/10 dark:text-sky-300 dark:hover:bg-sky-500/20'
                    }`}
                  >
                    <Film className="h-4 w-4" />
                    <span>{isVideoOpen ? 'إخفاء الفيديوهات' : 'فيديوهات للجملة'}</span>
                  </button>
                )}

                {practice?.audioUrl && !isRecordingThis && (
                  <button
                    type="button"
                    onClick={() => playUserRecording(practice.audioUrl!)}
                    className="inline-flex h-10 items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 text-xs font-bold text-emerald-700 hover:bg-emerald-100 dark:border-emerald-800/70 dark:bg-emerald-950/40 dark:text-emerald-300"
                  >
                    <Play className="h-3.5 w-3.5 fill-current" />
                    اسمع تسجيلك
                  </button>
                )}

                {practice?.audioBlob &&
                  !isRecordingThis &&
                  !practice.evaluatingAi &&
                  practice.evalResult?.source !== 'ai' && (
                    <button
                      type="button"
                      onClick={() =>
                        void evaluateWithAiFallback(
                          item,
                          practice.audioBlob,
                          practice.audioMimeType,
                          practice.evalResult?.heardText
                        )
                      }
                      className="inline-flex h-10 items-center gap-1.5 rounded-lg border border-indigo-200 bg-indigo-50 px-3 text-xs font-bold text-indigo-700 hover:bg-indigo-100 dark:border-indigo-800/60 dark:bg-indigo-950/40 dark:text-indigo-300"
                    >
                      <Sparkles className="h-3.5 w-3.5" />
                      تقييم دقيق بـ AI
                    </button>
                  )}
              </div>

              {/* Active Recording Live Banner */}
              {isRecordingThis && (
                <div className="mt-3 rounded-lg border border-rose-200 bg-rose-50 p-3 dark:border-rose-800/70 dark:bg-rose-950/30">
                  <div className="flex items-center gap-2 text-xs font-bold text-rose-700 dark:text-rose-300">
                    <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-rose-600" />
                    جاري التسجيل... انطق الجملة الإنجليزية الآن ثم اضغط «إيقاف وتقييم النطق»
                  </div>
                  {liveTranscript && (
                    <p
                      dir="ltr"
                      className="mt-1.5 text-left text-xs font-semibold text-slate-700 dark:text-slate-200"
                    >
                      {liveTranscript}
                    </p>
                  )}
                </div>
              )}

              {/* AI Evaluating Indicator */}
              {practice?.evaluatingAi && (
                <div className="mt-3 rounded-lg border border-indigo-200 bg-indigo-50 p-3 text-xs font-bold text-indigo-700 dark:border-indigo-800/60 dark:bg-indigo-950/40 dark:text-indigo-300">
                  جاري تحليل نطقك بالذكاء الاصطناعي...
                </div>
              )}

              {/* Practice Error */}
              {practice?.errorMsg && !isRecordingThis && (
                <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs font-semibold text-amber-800 dark:border-amber-800/60 dark:bg-amber-950/40 dark:text-amber-200">
                  {practice.errorMsg}
                </div>
              )}

              {/* Evaluation Result Box */}
              {practice?.evalResult && !isRecordingThis && !practice.evaluatingAi && (
                <div
                  className={`mt-3 rounded-lg border p-3.5 ${
                    practice.evalResult.isMatch
                      ? 'border-emerald-200 bg-emerald-50/70 dark:border-emerald-800/60 dark:bg-emerald-950/25'
                      : 'border-amber-200 bg-amber-50/70 dark:border-amber-800/60 dark:bg-amber-950/25'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span
                      className={`text-xs font-extrabold ${
                        practice.evalResult.isMatch
                          ? 'text-emerald-700 dark:text-emerald-300'
                          : 'text-amber-800 dark:text-amber-300'
                      }`}
                    >
                      {practice.evalResult.feedbackAr}
                    </span>
                    <span
                      className={`font-code rounded-md px-2.5 py-0.5 text-xs font-extrabold tabular-nums ${
                        practice.evalResult.score >= 80
                          ? 'bg-emerald-600 text-white'
                          : practice.evalResult.score >= 60
                            ? 'bg-amber-500 text-white'
                            : 'bg-rose-600 text-white'
                      }`}
                    >
                      الدقة {practice.evalResult.score}%
                    </span>
                  </div>

                  {/* Word-by-word color highlight */}
                  {practice.evalResult.tokens && practice.evalResult.tokens.length > 0 && (
                    <div
                      dir="ltr"
                      className="mt-2.5 flex flex-wrap gap-1.5 text-left text-sm font-bold"
                    >
                      {practice.evalResult.tokens.map((tk, idx) => (
                        <span
                          key={`${tk.word}-${idx}`}
                          className={`rounded px-1.5 py-0.5 ${
                            tk.matched
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-200'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-900/50 dark:text-rose-200'
                          }`}
                        >
                          {tk.word}
                        </span>
                      ))}
                    </div>
                  )}

                  {practice.evalResult.heardText && (
                    <div className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                      <span className="font-bold">ما تم سماعه: </span>
                      <span dir="ltr" className="inline-block font-semibold">
                        “{practice.evalResult.heardText}”
                      </span>
                    </div>
                  )}

                  {practice.evalResult.tipAr && (
                    <div className="mt-1.5 text-xs font-medium text-slate-700 dark:text-slate-300">
                      <span className="font-bold">نصيحة النطق: </span>
                      {practice.evalResult.tipAr}
                    </div>
                  )}
                </div>
              )}

              {/* Real-Speech Sentence Video Clips Player (same Reels engine as Words) */}
              {isVideoOpen && activeVideoKeyword && (
                <div
                  data-testid={`sentence-video-panel-${item.num}`}
                  className="mt-4 space-y-3 rounded-2xl border border-sky-500/30 bg-slate-50/90 p-3.5 dark:bg-slate-950/60 sm:p-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-xs font-extrabold text-slate-700 dark:text-slate-200">
                        اختر كلمة من الجملة لمقاطع الفيديو:
                      </span>
                      {videoTargets.keywords.map((kw) => {
                        const selected = kw === activeVideoKeyword;
                        return (
                          <button
                            key={kw}
                            type="button"
                            dir="ltr"
                            onClick={() =>
                              setVideoKeywordByNum((prev) => ({ ...prev, [item.num]: kw }))
                            }
                            className={`rounded-lg border px-2.5 py-1 font-en text-xs font-bold transition-colors ${
                              selected
                                ? 'border-sky-500 bg-sky-500 text-slate-950 shadow-xs'
                                : 'border-slate-300 bg-white text-slate-700 hover:border-sky-400 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200'
                            }`}
                          >
                            {kw}
                          </button>
                        );
                      })}
                    </div>

                    <button
                      type="button"
                      onClick={() => setVideoSentenceNum(null)}
                      aria-label="إغلاق مشغل الفيديو"
                      className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-300 bg-white text-slate-500 hover:text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400 dark:hover:text-white"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>

                  <WordVideoReelsPlayer
                    key={`${item.num}-${activeVideoKeyword}`}
                    word={activeVideoKeyword}
                    meaningAr={ar || item.en}
                    uiLang={lang}
                  />
                </div>
              )}
            </article>
          );
        })}
      </div>

      {/* Bottom Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            type="button"
            disabled={safePage <= 0}
            onClick={() => {
              setPage((p) => Math.max(0, p - 1));
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex h-10 items-center gap-1 rounded-lg border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-[#162032] dark:text-slate-200"
          >
            <ChevronRight className="h-4 w-4" />
            الصفحة السابقة
          </button>
          <span className="font-code text-xs font-bold text-slate-600 tabular-nums dark:text-slate-300">
            {safePage + 1} / {totalPages}
          </span>
          <button
            type="button"
            disabled={safePage >= totalPages - 1}
            onClick={() => {
              setPage((p) => Math.min(totalPages - 1, p + 1));
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex h-10 items-center gap-1 rounded-lg border border-slate-200 bg-white px-4 text-xs font-bold text-slate-700 hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-[#162032] dark:text-slate-200"
          >
            الصفحة التالية
            <ChevronLeft className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
}
