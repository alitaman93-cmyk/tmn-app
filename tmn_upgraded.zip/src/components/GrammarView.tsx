import { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  BookOpenCheck,
  CheckCircle2,
  ChevronLeft,
  Loader2,
  RotateCcw,
  Search,
  Shuffle,
  Sparkles,
  Volume2,
  XCircle,
} from 'lucide-react';
import { useI18n } from '../contexts/LanguageContext';
import { BAND_META } from '../data/constants';
import { GRAMMAR_CATEGORIES, GRAMMAR_LESSONS } from '../data/grammarLessons';
import { getListeningGrammarStrings } from '../i18n/listeningGrammarStrings';
import type {
  CefrBand,
  GrammarCategoryId,
  GrammarExercise,
  GrammarExerciseType,
  GrammarLesson,
  LocalizedGrammarPayload,
  PersistedSettings,
} from '../types';
import type { SfxType } from '../utils/audio';
import {
  buildGrammarReorderTiles,
  checkFillBlankAnswer,
  checkGrammarReorderAnswer,
  computeGrammarMastery,
  filterGrammarLessons,
} from '../utils/grammarLogic';
import {
  buildGrammarPracticeRound,
  getExpandedGrammarExercises,
  getTotalCurriculumExerciseCount,
} from '../utils/grammarPracticeBank';
import { fetchLocalizedGrammarLesson } from '../utils/listeningGrammarApi';

interface GrammarViewProps {
  settings: PersistedSettings;
  onSpeak: (text: string) => void;
  onSfx: (type: SfxType) => void;
  onCompleteRule: (lessonId: string, xpDelta: number) => void;
  onToast: (msg: string) => void;
}

const BAND_FILTERS: Array<CefrBand | 'all'> = ['all', 'A0', 'A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
const EXERCISE_MODES: Array<GrammarExerciseType | 'all'> = [
  'all',
  'mcq',
  'fill_blank',
  'spot_error',
  'reorder',
];

export function GrammarView({
  settings,
  onSpeak,
  onSfx,
  onCompleteRule,
  onToast,
}: GrammarViewProps) {
  const { lang } = useI18n();
  const s = useMemo(() => getListeningGrammarStrings(lang), [lang]);

  const completedIds = settings.completedGrammarIds || [];
  const completedSet = useMemo(() => new Set(completedIds), [completedIds]);
  const mastery = useMemo(
    () => computeGrammarMastery(GRAMMAR_LESSONS.length, completedIds),
    [completedIds]
  );
  const totalCurriculumExercises = useMemo(
    () => getTotalCurriculumExerciseCount(GRAMMAR_LESSONS),
    []
  );

  // Directory filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<GrammarCategoryId | 'all'>('all');
  const [selectedBand, setSelectedBand] = useState<CefrBand | 'all'>('all');

  // Active lesson state
  const [activeLesson, setActiveLesson] = useState<GrammarLesson | null>(null);
  const [lessonTab, setLessonTab] = useState<'learn' | 'practice'>('learn');
  const [localized, setLocalized] = useState<LocalizedGrammarPayload | null>(null);
  const [localizing, setLocalizing] = useState(false);

  // Practice arena state
  const [practiceMode, setPracticeMode] = useState<GrammarExerciseType | 'all'>('all');
  const [roundSize, setRoundSize] = useState<10 | 20 | 'all'>('all');
  const [shuffleSeed, setShuffleSeed] = useState(0);
  const [exIndex, setExIndex] = useState(0);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [fillInput, setFillInput] = useState('');
  const [reorderChosen, setReorderChosen] = useState<Array<{ id: number; text: string }>>([]);
  const [checkedStatus, setCheckedStatus] = useState<'idle' | 'correct' | 'wrong'>('idle');
  const [practiceCorrect, setPracticeCorrect] = useState(0);
  const [practiceDone, setPracticeDone] = useState(false);

  // Localize active grammar lesson into user's selected Settings language
  useEffect(() => {
    if (!activeLesson) {
      setLocalized(null);
      return;
    }
    let active = true;
    setLocalizing(lang !== 'ar');
    void fetchLocalizedGrammarLesson(activeLesson, lang)
      .then((res) => {
        if (active) setLocalized(res);
      })
      .finally(() => {
        if (active) setLocalizing(false);
      });
    return () => {
      active = false;
    };
  }, [activeLesson, lang]);

  const filteredLessons = useMemo(
    () =>
      filterGrammarLessons(GRAMMAR_LESSONS, {
        category: selectedCategory,
        band: selectedBand,
        query: searchQuery,
      }),
    [selectedCategory, selectedBand, searchQuery]
  );

  const expandedLessonExercises = useMemo<GrammarExercise[]>(() => {
    if (!activeLesson) return [];
    return getExpandedGrammarExercises(activeLesson);
  }, [activeLesson]);

  const modeCounts = useMemo(() => {
    const counts: Record<GrammarExerciseType | 'all', number> = {
      all: expandedLessonExercises.length,
      mcq: 0,
      fill_blank: 0,
      spot_error: 0,
      reorder: 0,
    };
    for (const ex of expandedLessonExercises) {
      counts[ex.type] += 1;
    }
    return counts;
  }, [expandedLessonExercises]);

  const practicePool = useMemo<GrammarExercise[]>(
    () => buildGrammarPracticeRound(expandedLessonExercises, practiceMode, roundSize, shuffleSeed),
    [expandedLessonExercises, practiceMode, roundSize, shuffleSeed]
  );

  const currentEx = practicePool[exIndex] || null;

  const reorderData = useMemo(() => {
    if (!currentEx || currentEx.type !== 'reorder' || !currentEx.targetSentence) return null;
    return buildGrammarReorderTiles(currentEx.targetSentence);
  }, [currentEx]);

  const resetExerciseInput = () => {
    setSelectedOpt(null);
    setFillInput('');
    setReorderChosen([]);
    setCheckedStatus('idle');
  };

  const openLesson = (lesson: GrammarLesson, startTab: 'learn' | 'practice' = 'learn') => {
    setActiveLesson(lesson);
    setLessonTab(startTab);
    setPracticeMode('all');
    setRoundSize('all');
    setShuffleSeed(0);
    setExIndex(0);
    setPracticeCorrect(0);
    setPracticeDone(false);
    resetExerciseInput();
    window.scrollTo({ top: 0 });
  };

  const handleSwitchPracticeMode = (mode: GrammarExerciseType | 'all') => {
    setPracticeMode(mode);
    setExIndex(0);
    setPracticeCorrect(0);
    setPracticeDone(false);
    resetExerciseInput();
  };

  const handleSwitchRoundSize = (size: 10 | 20 | 'all') => {
    setRoundSize(size);
    setExIndex(0);
    setPracticeCorrect(0);
    setPracticeDone(false);
    resetExerciseInput();
  };

  const handleShuffleRound = () => {
    setShuffleSeed((n) => n + 1);
    setExIndex(0);
    setPracticeCorrect(0);
    setPracticeDone(false);
    resetExerciseInput();
  };

  const evaluateChoice = (idx: number) => {
    if (!currentEx || checkedStatus !== 'idle') return;
    setSelectedOpt(idx);
    const ok = idx === currentEx.correctIndex;
    setCheckedStatus(ok ? 'correct' : 'wrong');
    onSfx(ok ? 'ok' : 'err');
    if (ok) setPracticeCorrect((c) => c + 1);
  };

  const evaluateFillBlank = () => {
    if (!currentEx || checkedStatus !== 'idle' || !fillInput.trim()) return;
    const ok = checkFillBlankAnswer(fillInput, currentEx.acceptedAnswers || []);
    setCheckedStatus(ok ? 'correct' : 'wrong');
    onSfx(ok ? 'ok' : 'err');
    if (ok) setPracticeCorrect((c) => c + 1);
  };

  const evaluateReorder = () => {
    if (!currentEx || checkedStatus !== 'idle' || !currentEx.targetSentence) return;
    const ok = checkGrammarReorderAnswer(
      reorderChosen.map((t) => t.text),
      currentEx.targetSentence
    );
    setCheckedStatus(ok ? 'correct' : 'wrong');
    onSfx(ok ? 'ok' : 'err');
    if (ok) setPracticeCorrect((c) => c + 1);
  };

  const handleNextExercise = () => {
    if (exIndex + 1 < practicePool.length) {
      setExIndex((i) => i + 1);
      resetExerciseInput();
      return;
    }
    setPracticeDone(true);
    if (activeLesson) {
      onCompleteRule(activeLesson.id, 20);
      onToast(`${s.grammarRuleCompleted} · +20 XP`);
    }
  };

  // Highlight target phrase inside English example cleanly
  const renderHighlightedExample = (sentence: string, highlight?: string) => {
    if (!highlight) return sentence;
    const idx = sentence.toLowerCase().indexOf(highlight.toLowerCase());
    if (idx < 0) return sentence;
    const before = sentence.slice(0, idx);
    const match = sentence.slice(idx, idx + highlight.length);
    const after = sentence.slice(idx + highlight.length);
    return (
      <>
        {before}
        <span className="rounded bg-indigo-500/15 px-1 font-extrabold text-indigo-700 dark:bg-sky-500/20 dark:text-sky-300">
          {match}
        </span>
        {after}
      </>
    );
  };

  // ───────────────────────────────────────────────────────────────────────────
  // VIEW 2: GRAMMAR LESSON & INTERACTIVE PRACTICE ARENA
  // ───────────────────────────────────────────────────────────────────────────
  if (activeLesson) {
    const isMastered = completedSet.has(activeLesson.id);
    const bandColor = BAND_META[activeLesson.band]?.color || '#4f46e5';
    const displayTitle = localized?.title || activeLesson.titleAr;
    const displaySummary = localized?.summary || activeLesson.summaryAr;
    const displayHow = localized?.howToUse?.length ? localized.howToUse : activeLesson.howToUseAr;
    const displayWhen = localized?.whenToUse?.length
      ? localized.whenToUse
      : activeLesson.whenToUseAr;
    const displayMistakeNotes = localized?.mistakeNotes || [];
    const displayExampleNotes = localized?.exampleNotes || [];

    return (
      <section data-testid="grammar-lesson-view" className="mx-auto max-w-4xl space-y-6">
        {/* Top bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setActiveLesson(null)}
            className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-200 bg-white px-3.5 text-sm font-bold text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-[#111b2e] dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
            <span>{s.grammarBackToAll}</span>
          </button>

          <div className="flex items-center gap-2">
            {localizing && (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-sky-400">
                <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                <span>{s.grammarLocalizing}</span>
              </span>
            )}
            {isMastered ? (
              <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                <span>{s.grammarRuleCompleted}</span>
              </span>
            ) : (
              <button
                type="button"
                onClick={() => {
                  onCompleteRule(activeLesson.id, 10);
                  onToast(`${s.grammarRuleCompleted} · +10 XP`);
                }}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-bold text-slate-700 hover:border-emerald-400 hover:text-emerald-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
                <span>{s.grammarMarkComplete}</span>
              </button>
            )}
          </div>
        </div>

        {/* Lesson Header & Learn/Practice Switch */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-[#111b2e] sm:p-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400">
                <span className="font-en font-black" style={{ color: bandColor }}>
                  {activeLesson.band}
                </span>
                <span aria-hidden="true">·</span>
                <span>{s.categories[activeLesson.category]}</span>
              </div>
              <h1 className="text-start font-en text-2xl font-extrabold text-slate-900 dark:text-white sm:text-3xl">
                <span dir="ltr" className="inline-block">
                  {activeLesson.titleEn}
                </span>
              </h1>
              <p className="text-base font-bold text-indigo-600 dark:text-sky-400">
                {displayTitle}
              </p>
              <p className="pt-1 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                {displaySummary}
              </p>
            </div>

            {/* Segmented Mode Switch */}
            <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1 dark:bg-slate-900">
              <button
                type="button"
                data-testid="grammar-tab-learn"
                onClick={() => setLessonTab('learn')}
                className={`rounded-lg px-4 py-2 text-xs font-bold whitespace-nowrap transition-colors sm:text-sm ${
                  lessonTab === 'learn'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                }`}
              >
                {s.grammarTabLearn}
              </button>
              <button
                type="button"
                data-testid="grammar-tab-practice"
                onClick={() => setLessonTab('practice')}
                className={`rounded-lg px-4 py-2 text-xs font-bold whitespace-nowrap transition-colors sm:text-sm ${
                  lessonTab === 'practice'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                }`}
              >
                {s.grammarTabPractice} ({expandedLessonExercises.length})
              </button>
            </div>
          </div>

          {/* Formula Banner */}
          <div className="mt-5 rounded-xl border border-indigo-200 bg-indigo-50/70 p-4 dark:border-indigo-500/25 dark:bg-indigo-950/35">
            <div className="mb-1 text-xs font-bold text-indigo-700 dark:text-sky-300">
              {s.grammarFormulaTitle}
            </div>
            <div className="text-start font-code text-sm font-bold text-slate-900 dark:text-white sm:text-base">
              <span dir="ltr" className="inline-block">
                {activeLesson.formula}
              </span>
            </div>
          </div>
        </div>

        {/* LEARN TAB */}
        {lessonTab === 'learn' ? (
          <div className="space-y-6">
            {/* How & When to Use (2-column balanced grid) */}
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#111b2e]">
                <h2 className="mb-3 text-base font-extrabold text-slate-900 dark:text-white">
                  {s.grammarHowTitle}
                </h2>
                <ol className="space-y-2.5 text-sm leading-relaxed text-slate-700 dark:text-slate-200">
                  {displayHow.map((step, i) => (
                    <li key={i} className="flex items-start gap-2.5">
                      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-indigo-600/15 font-code text-xs font-bold text-indigo-700 tabular-nums dark:text-sky-300">
                        {i + 1}
                      </span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#111b2e]">
                <h2 className="mb-3 text-base font-extrabold text-slate-900 dark:text-white">
                  {s.grammarWhenTitle}
                </h2>
                <ol className="space-y-2.5 text-sm leading-relaxed text-slate-700 dark:text-slate-200">
                  {displayWhen.map((when, i) => (
                    <li key={i} className="flex items-start gap-2.5">
                      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-emerald-600/15 font-code text-xs font-bold text-emerald-700 tabular-nums dark:text-emerald-300">
                        {i + 1}
                      </span>
                      <span>{when}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>

            {/* Spoken English Examples */}
            <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#111b2e]">
              <h2 className="mb-4 text-base font-extrabold text-slate-900 dark:text-white">
                {s.grammarExamplesTitle}
              </h2>
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {activeLesson.examples.map((ex, i) => (
                  <div
                    key={i}
                    className="flex items-start justify-between gap-3 py-3 first:pt-0 last:pb-0"
                  >
                    <div className="min-w-0 flex-1 space-y-1 text-start">
                      <p className="font-en text-sm font-bold text-slate-900 dark:text-slate-100 sm:text-base">
                        <span dir="ltr" className="inline-block">
                          {renderHighlightedExample(ex.en, ex.highlight)}
                        </span>
                      </p>
                      <p className="text-xs text-slate-600 dark:text-slate-300 sm:text-sm">
                        {displayExampleNotes[i] || ex.ar}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onSpeak(ex.en)}
                      aria-label={`Listen: ${ex.en}`}
                      className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-indigo-600 hover:bg-indigo-50 dark:border-slate-700 dark:bg-slate-800 dark:text-sky-400 dark:hover:bg-slate-700"
                    >
                      <Volume2 className="h-4 w-4" aria-hidden="true" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Common Mistakes */}
            {activeLesson.commonMistakes.length > 0 && (
              <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#111b2e]">
                <h2 className="mb-4 text-base font-extrabold text-slate-900 dark:text-white">
                  {s.grammarMistakesTitle}
                </h2>
                <div className="space-y-3">
                  {activeLesson.commonMistakes.map((m, i) => (
                    <div
                      key={i}
                      className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-900/60"
                    >
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                        <div
                          dir="ltr"
                          className="flex items-center gap-2 font-en text-sm font-semibold text-rose-600 dark:text-rose-400"
                        >
                          <XCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                          <span className="line-through">{m.wrong}</span>
                        </div>
                        <div
                          dir="ltr"
                          className="flex items-center gap-2 font-en text-sm font-bold text-emerald-700 dark:text-emerald-400"
                        >
                          <CheckCircle2 className="h-4 w-4 shrink-0" aria-hidden="true" />
                          <span>{m.right}</span>
                        </div>
                      </div>
                      <p className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                        {displayMistakeNotes[i] || m.noteAr}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Launch Interactive Tests CTA */}
            <div className="flex justify-center pt-1">
              <button
                type="button"
                data-testid="grammar-start-practice-cta"
                onClick={() => {
                  setLessonTab('practice');
                  window.scrollTo({ top: 0 });
                }}
                className="inline-flex h-12 items-center gap-2 rounded-xl bg-indigo-600 px-7 text-sm font-extrabold text-white shadow-sm hover:bg-indigo-500"
              >
                <Sparkles className="h-4 w-4" aria-hidden="true" />
                <span>
                  {s.grammarPracticeTitle} ({activeLesson.exercises.length})
                </span>
              </button>
            </div>
          </div>
        ) : (
          /* PRACTICE ARENA TAB */
          <div
            data-testid="grammar-practice-arena"
            className="space-y-5 rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-[#111b2e] sm:p-6"
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  {s.grammarPracticeTitle}
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">{s.grammarPracticeSub}</p>
              </div>
              {!practiceDone && practicePool.length > 0 && (
                <div className="flex items-center gap-3">
                  <span className="font-code text-xs font-bold text-emerald-600 tabular-nums dark:text-emerald-400">
                    ✓ {practiceCorrect}
                  </span>
                  <span
                    data-testid="grammar-exercise-counter"
                    className="font-code text-xs font-bold text-indigo-600 tabular-nums dark:text-sky-400"
                  >
                    {exIndex + 1} / {practicePool.length}
                  </span>
                </div>
              )}
            </div>

            {/* Progress Bar */}
            {!practiceDone && practicePool.length > 0 && (
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                <div
                  className="h-full rounded-full bg-indigo-600 transition-all duration-300 dark:bg-sky-400"
                  style={{ width: `${Math.round(((exIndex + (checkedStatus !== 'idle' ? 1 : 0)) / practicePool.length) * 100)}%` }}
                />
              </div>
            )}

            {/* Exercise Type Filter Bar with live counts */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-1.5 rounded-xl bg-slate-100 p-1 dark:bg-slate-900">
                {EXERCISE_MODES.map((m) => (
                  <button
                    key={m}
                    type="button"
                    data-testid={`grammar-mode-${m}`}
                    onClick={() => handleSwitchPracticeMode(m)}
                    className={`rounded-lg px-3 py-1.5 text-xs font-bold whitespace-nowrap transition-colors ${
                      practiceMode === m
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                    }`}
                  >
                    {s.exerciseTypes[m]} ({modeCounts[m]})
                  </button>
                ))}
              </div>

              {/* Round Size & Shuffle Controls */}
              <div className="flex flex-wrap items-center gap-1.5">
                {([10, 20, 'all'] as const).map((sz) => (
                  <button
                    key={String(sz)}
                    type="button"
                    data-testid={`grammar-round-size-${sz}`}
                    onClick={() => handleSwitchRoundSize(sz)}
                    className={`rounded-lg border px-2.5 py-1 text-xs font-bold transition-colors ${
                      roundSize === sz
                        ? 'border-sky-500 bg-sky-500/15 text-sky-700 dark:text-sky-300'
                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-400 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300'
                    }`}
                  >
                    {sz === 'all' ? (lang === 'ar' ? `الكل (${modeCounts[practiceMode]})` : `All (${modeCounts[practiceMode]})`) : sz}
                  </button>
                ))}
                <button
                  type="button"
                  data-testid="grammar-shuffle-btn"
                  onClick={handleShuffleRound}
                  className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 py-1 text-xs font-bold text-slate-700 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                >
                  <Shuffle className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{lang === 'ar' ? 'خلط' : 'Shuffle'}</span>
                </button>
              </div>
            </div>

            {practiceDone ? (
              <div className="space-y-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-6 text-center">
                <CheckCircle2 className="mx-auto h-10 w-10 text-emerald-500" aria-hidden="true" />
                <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  {s.grammarRuleCompleted}
                </h3>
                <p className="font-code text-sm font-bold text-emerald-700 tabular-nums dark:text-emerald-300">
                  {practiceCorrect} / {practicePool.length}
                </p>
                <div className="flex flex-wrap justify-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleShuffleRound}
                    className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 text-sm font-bold text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                  >
                    <Shuffle className="h-4 w-4" aria-hidden="true" />
                    <span>{lang === 'ar' ? 'جولة جديدة مخلوطة' : 'New Shuffled Round'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSwitchPracticeMode(practiceMode)}
                    className="inline-flex h-10 items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 text-sm font-bold text-slate-800 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                  >
                    <RotateCcw className="h-4 w-4" aria-hidden="true" />
                    <span>{s.quizRetryBtn}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveLesson(null)}
                    className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white hover:bg-indigo-500"
                  >
                    <span>{s.grammarBackToAll}</span>
                  </button>
                </div>
              </div>
            ) : currentEx ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs font-bold text-indigo-600 dark:text-sky-400">
                  <span>{s.exerciseTypes[currentEx.type]}</span>
                  {currentEx.hint && (
                    <span dir="ltr" className="font-en text-slate-500 dark:text-slate-400">
                      Hint: {currentEx.hint}
                    </span>
                  )}
                </div>

                {/* Exercise Prompt */}
                <p
                  dir="ltr"
                  className="rounded-xl border border-slate-200 bg-slate-50 p-4 font-en text-base font-bold text-slate-900 dark:border-slate-800 dark:bg-slate-900/70 dark:text-white"
                >
                  {currentEx.prompt}
                </p>

                {/* 1) MCQ */}
                {currentEx.type === 'mcq' && currentEx.options && (
                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                    {currentEx.options.map((opt, idx) => {
                      const isSel = selectedOpt === idx;
                      const isRight = idx === currentEx.correctIndex;
                      let cls =
                        'border-slate-200 bg-white text-slate-800 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-100';
                      if (checkedStatus !== 'idle') {
                        if (isRight) {
                          cls =
                            'border-emerald-500 bg-emerald-500/15 text-emerald-800 dark:text-emerald-200';
                        } else if (isSel) {
                          cls = 'border-rose-500 bg-rose-500/15 text-rose-800 dark:text-rose-200';
                        }
                      }
                      return (
                        <button
                          key={idx}
                          type="button"
                          data-testid={`grammar-mcq-opt-${idx}`}
                          disabled={checkedStatus !== 'idle'}
                          onClick={() => evaluateChoice(idx)}
                          dir="ltr"
                          className={`min-h-[48px] rounded-xl border px-4 py-3 text-left font-en text-sm font-bold transition-colors ${cls}`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                )}

                {/* 2) FILL IN THE BLANK */}
                {currentEx.type === 'fill_blank' && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      evaluateFillBlank();
                    }}
                    className="flex flex-wrap items-center gap-2.5"
                  >
                    <input
                      type="text"
                      dir="ltr"
                      data-testid="grammar-fill-input"
                      disabled={checkedStatus !== 'idle'}
                      value={fillInput}
                      onChange={(e) => setFillInput(e.target.value)}
                      placeholder={s.grammarTypePlaceholder}
                      aria-label={s.grammarTypePlaceholder}
                      className="h-12 min-w-[220px] flex-1 rounded-xl border border-slate-300 bg-white px-4 font-en text-base font-bold text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                    />
                    {checkedStatus === 'idle' && (
                      <button
                        type="submit"
                        data-testid="grammar-fill-submit"
                        disabled={!fillInput.trim()}
                        className="h-12 rounded-xl bg-indigo-600 px-6 text-sm font-extrabold text-white hover:bg-indigo-500 disabled:opacity-40"
                      >
                        {s.grammarCheckBtn}
                      </button>
                    )}
                  </form>
                )}

                {/* 3) SPOT & FIX THE ERROR */}
                {currentEx.type === 'spot_error' && currentEx.options && (
                  <div className="space-y-3">
                    <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
                      {s.grammarTapWrongWord}
                    </p>
                    <div className="flex flex-wrap gap-2.5" dir="ltr">
                      {currentEx.options.map((token, idx) => {
                        const isSel = selectedOpt === idx;
                        const isErrorToken = idx === currentEx.correctIndex;
                        let cls =
                          'border-slate-300 bg-white text-slate-900 underline decoration-indigo-400 decoration-2 underline-offset-4 hover:border-indigo-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100';
                        if (checkedStatus !== 'idle') {
                          if (isErrorToken) {
                            cls =
                              'border-emerald-500 bg-emerald-500/15 text-emerald-800 dark:text-emerald-200';
                          } else if (isSel) {
                            cls = 'border-rose-500 bg-rose-500/15 text-rose-800 dark:text-rose-200';
                          }
                        }
                        return (
                          <button
                            key={idx}
                            type="button"
                            data-testid={`grammar-spot-opt-${idx}`}
                            disabled={checkedStatus !== 'idle'}
                            onClick={() => evaluateChoice(idx)}
                            className={`min-h-[44px] rounded-xl border px-4 py-2 font-en text-sm font-bold transition-colors ${cls}`}
                          >
                            {token}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 4) SENTENCE REORDER */}
                {currentEx.type === 'reorder' && reorderData && (
                  <div className="space-y-3">
                    <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
                      {s.grammarTapReorderHint}
                    </p>

                    {/* Built Answer Tray */}
                    <div
                      dir="ltr"
                      data-testid="grammar-reorder-tray"
                      className="flex min-h-[58px] flex-wrap items-center gap-2 rounded-xl border-2 border-dashed border-slate-300 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-900/60"
                    >
                      {reorderChosen.map((tile) => (
                        <button
                          key={tile.id}
                          type="button"
                          disabled={checkedStatus !== 'idle'}
                          onClick={() =>
                            setReorderChosen((prev) => prev.filter((t) => t.id !== tile.id))
                          }
                          className="rounded-lg bg-indigo-600 px-3 py-1.5 font-en text-sm font-bold text-white hover:bg-indigo-500"
                        >
                          {tile.text}
                        </button>
                      ))}
                    </div>

                    {/* Available Shuffled Tiles */}
                    <div dir="ltr" className="flex flex-wrap gap-2">
                      {reorderData.shuffledTiles.map((tile, idx) => {
                        const used = reorderChosen.some((c) => c.id === tile.id);
                        return (
                          <button
                            key={tile.id}
                            type="button"
                            data-testid={`grammar-reorder-tile-${idx}`}
                            disabled={used || checkedStatus !== 'idle'}
                            onClick={() => setReorderChosen((prev) => [...prev, tile])}
                            className={`min-h-[40px] rounded-lg border px-3.5 py-1.5 font-en text-sm font-bold transition-colors ${
                              used
                                ? 'border-slate-200 bg-slate-100 text-slate-400 opacity-40 dark:border-slate-800 dark:bg-slate-900'
                                : 'border-slate-300 bg-white text-slate-800 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100'
                            }`}
                          >
                            {tile.text}
                          </button>
                        );
                      })}
                    </div>

                    {checkedStatus === 'idle' && (
                      <div className="flex flex-wrap items-center gap-2.5 pt-1">
                        <button
                          type="button"
                          data-testid="grammar-reorder-submit"
                          disabled={reorderChosen.length === 0}
                          onClick={evaluateReorder}
                          className="h-10 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white hover:bg-indigo-500 disabled:opacity-40"
                        >
                          {s.grammarCheckBtn}
                        </button>
                        <button
                          type="button"
                          onClick={() => setReorderChosen([])}
                          className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-300 bg-white px-3.5 text-xs font-bold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                        >
                          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>{s.grammarResetOrder}</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Feedback & Next Button */}
                {checkedStatus !== 'idle' && (
                  <div
                    data-testid="grammar-exercise-feedback"
                    className={`space-y-2.5 rounded-xl border p-4 ${
                      checkedStatus === 'correct'
                        ? 'border-emerald-500/40 bg-emerald-500/10'
                        : 'border-rose-500/40 bg-rose-500/10'
                    }`}
                  >
                    <div className="flex items-center gap-2 text-sm font-extrabold">
                      {checkedStatus === 'correct' ? (
                        <>
                          <CheckCircle2 className="h-4 w-4 text-emerald-500" aria-hidden="true" />
                          <span className="text-emerald-700 dark:text-emerald-300">
                            {s.grammarCorrectLabel}
                          </span>
                        </>
                      ) : (
                        <>
                          <XCircle className="h-4 w-4 text-rose-500" aria-hidden="true" />
                          <span className="text-rose-700 dark:text-rose-300">
                            {s.grammarWrongLabel}
                          </span>
                        </>
                      )}
                    </div>

                    {currentEx.correctedSentence && (
                      <div className="flex items-center justify-between gap-2">
                        <p dir="ltr" className="font-en text-sm font-bold text-slate-900 dark:text-white">
                          ✓ {currentEx.correctedSentence}
                        </p>
                        <button
                          type="button"
                          onClick={() => onSpeak(currentEx.correctedSentence!)}
                          aria-label="Listen"
                          className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-300 bg-white text-indigo-600 hover:bg-indigo-50 dark:border-slate-700 dark:bg-slate-800 dark:text-sky-400"
                        >
                          <Volume2 className="h-4 w-4" aria-hidden="true" />
                        </button>
                      </div>
                    )}
                    {currentEx.targetSentence && (
                      <div className="flex items-center justify-between gap-2">
                        <p dir="ltr" className="font-en text-sm font-bold text-slate-900 dark:text-white">
                          ✓ {currentEx.targetSentence}
                        </p>
                        <button
                          type="button"
                          onClick={() => onSpeak(currentEx.targetSentence!)}
                          aria-label="Listen"
                          className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-slate-300 bg-white text-indigo-600 hover:bg-indigo-50 dark:border-slate-700 dark:bg-slate-800 dark:text-sky-400"
                        >
                          <Volume2 className="h-4 w-4" aria-hidden="true" />
                        </button>
                      </div>
                    )}
                    {currentEx.type === 'fill_blank' && currentEx.acceptedAnswers?.[0] && (
                      <p dir="ltr" className="font-en text-sm font-bold text-slate-900 dark:text-white">
                        ✓ {currentEx.acceptedAnswers[0]}
                      </p>
                    )}

                    <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-200 sm:text-sm">
                      {currentEx.explanationAr}
                    </p>

                    <div className="pt-1">
                      <button
                        type="button"
                        data-testid="grammar-next-ex-btn"
                        onClick={handleNextExercise}
                        className="inline-flex h-10 items-center gap-2 rounded-xl bg-indigo-600 px-5 text-sm font-bold text-white hover:bg-indigo-500"
                      >
                        <span>
                          {exIndex + 1 < practicePool.length
                            ? s.grammarNextQuestion
                            : s.grammarFinishPractice}
                        </span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </div>
        )}
      </section>
    );
  }

  // ───────────────────────────────────────────────────────────────────────────
  // VIEW 1: GRAMMAR ACADEMY DIRECTORY (All 36 English Grammar Rules A0–C2)
  // ───────────────────────────────────────────────────────────────────────────
  return (
    <section data-testid="grammar-directory" className="space-y-6">
      {/* Header & Mastery Progress */}
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-xs dark:border-slate-800 dark:bg-[#111b2e] sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-2xl space-y-2">
            <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
              {s.grammarTitle}
            </h1>
            <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              {s.grammarDesc}
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-1 text-xs font-bold text-indigo-600 dark:text-sky-400">
              <span data-testid="grammar-total-exercises">
                {GRAMMAR_LESSONS.length} قاعدة · {totalCurriculumExercises.toLocaleString('en-US')} تمرين تفاعلي
              </span>
            </div>
          </div>

          <div className="min-w-[180px] rounded-xl border border-slate-200 bg-slate-50 p-3.5 dark:border-slate-800 dark:bg-slate-900/70">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
              <span>{s.grammarMasteredProgress}</span>
              <span className="font-code font-bold text-indigo-600 tabular-nums dark:text-sky-400">
                {mastery.percent}%
              </span>
            </div>
            <div className="mt-1 font-code text-xl font-extrabold text-slate-900 tabular-nums dark:text-white">
              {mastery.completedCount} / {mastery.totalCount}
            </div>
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
              <div
                className="h-full rounded-full bg-indigo-600 transition-all duration-300 dark:bg-sky-400"
                style={{ width: `${mastery.percent}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Search + CEFR Level + Category Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search
            className="pointer-events-none absolute start-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
            aria-hidden="true"
          />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={s.grammarSearchPlaceholder}
            aria-label={s.grammarSearchPlaceholder}
            className="h-11 w-full rounded-xl border border-slate-200 bg-white ps-10 pe-4 text-sm text-slate-900 placeholder:text-slate-400 focus:border-indigo-500 focus:outline-none dark:border-slate-800 dark:bg-[#111b2e] dark:text-white"
          />
        </div>

        {/* CEFR Level Filter Row */}
        <div className="flex flex-wrap items-center gap-1.5">
          {BAND_FILTERS.map((b) => (
            <button
              key={b}
              type="button"
              onClick={() => setSelectedBand(b)}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold whitespace-nowrap transition-colors ${
                selectedBand === b
                  ? 'bg-indigo-600 text-white'
                  : 'border border-slate-200 bg-white text-slate-600 hover:border-indigo-400 dark:border-slate-800 dark:bg-[#111b2e] dark:text-slate-300'
              }`}
            >
              {b === 'all' ? s.grammarAllLevels : b}
            </button>
          ))}
        </div>

        {/* Grammar Category Filter Row */}
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`rounded-lg px-3 py-1.5 text-xs font-bold whitespace-nowrap transition-colors ${
              selectedCategory === 'all'
                ? 'bg-slate-900 text-white dark:bg-sky-500 dark:text-slate-950'
                : 'border border-slate-200 bg-white text-slate-600 hover:border-slate-400 dark:border-slate-800 dark:bg-[#111b2e] dark:text-slate-300'
            }`}
          >
            {s.grammarAllCategories} ({GRAMMAR_LESSONS.length})
          </button>
          {GRAMMAR_CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`rounded-lg px-3 py-1.5 text-xs font-bold whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-slate-900 text-white dark:bg-sky-500 dark:text-slate-950'
                  : 'border border-slate-200 bg-white text-slate-600 hover:border-slate-400 dark:border-slate-800 dark:bg-[#111b2e] dark:text-slate-300'
              }`}
            >
              {s.categories[cat]}
            </button>
          ))}
        </div>
      </div>

      {/* Lessons Grid */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {filteredLessons.map((lesson) => {
          const done = completedSet.has(lesson.id);
          const color = BAND_META[lesson.band]?.color || '#4f46e5';

          return (
            <button
              key={lesson.id}
              type="button"
              data-testid={`grammar-card-${lesson.id}`}
              onClick={() => openLesson(lesson, 'learn')}
              className="group flex flex-col justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-5 text-start transition-colors hover:border-indigo-400 dark:border-slate-800 dark:bg-[#111b2e] dark:hover:border-indigo-500"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-2 font-bold">
                    <span className="font-en font-black" style={{ color }}>
                      {lesson.band}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{s.categories[lesson.category]}</span>
                  </div>
                  {done ? (
                    <span className="inline-flex items-center gap-1 font-bold text-emerald-600 dark:text-emerald-400">
                      <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                      <span>{s.completedBadge}</span>
                    </span>
                  ) : (
                    <ChevronLeft
                      className="h-4 w-4 text-slate-400 transition-transform group-hover:-translate-x-0.5 group-hover:text-indigo-500"
                      aria-hidden="true"
                    />
                  )}
                </div>

                <h2 className="text-start font-en text-lg font-extrabold text-slate-900 group-hover:text-indigo-600 dark:text-white dark:group-hover:text-sky-300">
                  <span dir="ltr" className="inline-block">
                    {lesson.titleEn}
                  </span>
                </h2>
                <p className="text-sm font-bold text-slate-700 dark:text-slate-200">
                  {lesson.titleAr}
                </p>
                <div className="truncate rounded-lg bg-slate-50 px-3 py-1.5 text-start font-code text-xs font-semibold text-slate-600 dark:bg-slate-900/70 dark:text-slate-300">
                  <span dir="ltr" className="inline-block">
                    {lesson.formula}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-slate-100 pt-3 text-xs font-semibold text-slate-500 dark:border-slate-800/80 dark:text-slate-400">
                <span className="inline-flex items-center gap-1.5">
                  <BookOpenCheck className="h-3.5 w-3.5 text-indigo-500" aria-hidden="true" />
                  <span>
                    {lesson.examples.length} أمثلة · {getExpandedGrammarExercises(lesson).length} تمرين تفاعلي
                  </span>
                </span>
                <span className="font-bold text-indigo-600 dark:text-sky-400">
                  {s.grammarTabLearn}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}
