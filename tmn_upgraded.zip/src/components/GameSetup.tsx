import { ChevronLeft, ChevronRight, Play } from 'lucide-react';
import { BANDS, BAND_META, GAME_MAP } from '../data/constants';
import type { CefrBand, GameModeId, PersistedSettings, SourceType, VocabStore } from '../types';
import { getBandSubCount, getBandSubIndices, lvlKey } from '../utils/vocabLogic';
import { GameIcon } from './GameIcon';

interface GameSetupProps {
  store: VocabStore;
  settings: PersistedSettings;
  gameMode: GameModeId;
  source: SourceType;
  band: CefrBand;
  subIdx: number;
  onChangeSource: (src: SourceType) => void;
  onChangeBand: (b: CefrBand) => void;
  onChangeSub: (idx: number) => void;
  onChangeMcqDir: (dir: 'en2ar' | 'ar2en') => void;
  onLaunch: () => void;
}

export function GameSetup({
  store,
  settings,
  gameMode,
  source,
  band,
  subIdx,
  onChangeSource,
  onChangeBand,
  onChangeSub,
  onChangeMcqDir,
  onLaunch,
}: GameSetupProps) {
  const game = GAME_MAP[gameMode];
  const subTot = getBandSubCount(store, band, settings.levelSize);
  const safeSub = Math.min(Math.max(0, subIdx), subTot - 1);
  const score = settings.completed[lvlKey(band, safeSub)] || 0;
  const previewIndices = getBandSubIndices(store, band, safeSub, settings.levelSize);
  const previewWords = previewIndices
    .slice(0, 5)
    .map((id) => store.words[id]?.en)
    .filter(Boolean)
    .join(' · ');

  const canStart =
    source === 'mistakes'
      ? settings.mistakes.length > 0
      : source === 'favorites'
        ? settings.favorites.length > 0
        : previewIndices.length > 0 || store.words.length > 0;

  return (
    <div className="mx-auto max-w-3xl space-y-5 pb-24">
      {/* Selected Game Summary */}
      <div className="flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white">
          <GameIcon mode={gameMode} className="h-6 w-6" />
        </div>
        <div>
          <h1 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">
            {game.name}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">{game.desc}</p>
        </div>
      </div>

      {/* Source Selector */}
      <div
        role="tablist"
        aria-label="مصدر الكلمات"
        className="grid grid-cols-2 gap-1.5 rounded-xl bg-slate-200/70 p-1 dark:bg-slate-800/80 sm:grid-cols-4"
      >
        {(
          [
            { id: 'level', label: 'مستوى محدد' },
            { id: 'random', label: 'عشوائي' },
            { id: 'mistakes', label: `الأخطاء (${settings.mistakes.length})` },
            { id: 'favorites', label: `المفضلة (${settings.favorites.length})` },
          ] as Array<{ id: SourceType; label: string }>
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={source === tab.id}
            onClick={() => onChangeSource(tab.id)}
            className={`min-h-[42px] whitespace-nowrap rounded-lg px-3 py-2 text-xs font-bold transition-colors sm:text-sm ${
              source === tab.id
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Band & Sub-level Selection */}
      {(source === 'level' || source === 'random') && (
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]">
          <h2 className="mb-3 text-sm font-bold text-slate-900 dark:text-slate-100">
            1. اختر مستوى اللغة (CEFR)
          </h2>
          <div className="grid grid-cols-4 gap-2 sm:grid-cols-7">
            {BANDS.map((b) => {
              const active = band === b;
              const meta = BAND_META[b];
              return (
                <button
                  key={b}
                  type="button"
                  onClick={() => onChangeBand(b)}
                  className={`flex min-h-[60px] flex-col items-center justify-center rounded-xl border-2 p-2 text-center transition-colors ${
                    active
                      ? 'border-indigo-600 bg-indigo-50 dark:border-indigo-400 dark:bg-indigo-500/15'
                      : 'border-slate-200 bg-slate-50 hover:border-slate-300 dark:border-slate-700 dark:bg-slate-800/60 dark:hover:border-slate-600'
                  }`}
                >
                  <span className={`font-en text-base font-extrabold ${meta.textClass}`}>{b}</span>
                  <span className="mt-0.5 text-[11px] font-semibold text-slate-600 dark:text-slate-300">
                    {meta.ar}
                  </span>
                </button>
              );
            })}
          </div>
          <p className="mt-3 text-center text-xs text-slate-500 dark:text-slate-400">
            {BAND_META[band].ar} ·{' '}
            <span className="font-code tabular-nums">
              {store.byBand[band].length.toLocaleString('en-US')}
            </span>{' '}
            كلمة · <span className="font-code tabular-nums">{subTot}</span> مستوى
          </p>
        </div>
      )}

      {source === 'level' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]">
          <div className="mb-3 flex items-center justify-between gap-2">
            <label htmlFor="setupSubLevelSelect" className="text-sm font-bold text-slate-900 dark:text-slate-100">
              2. اختر رقم المستوى داخل {band}
            </label>
            <span
              className={`font-code text-xs font-bold tabular-nums ${
                score >= 80
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : score > 0
                    ? 'text-amber-600 dark:text-amber-400'
                    : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              {score > 0 ? `أفضل نتيجة ${score}%` : 'مستوى جديد'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={safeSub === 0}
              onClick={() => onChangeSub(Math.max(0, safeSub - 1))}
              aria-label="المستوى السابق"
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <ChevronRight className="h-5 w-5" aria-hidden="true" />
            </button>

            <select
              id="setupSubLevelSelect"
              value={safeSub}
              onChange={(e) => onChangeSub(parseInt(e.target.value, 10) || 0)}
              className="h-11 flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3 text-center text-sm font-bold text-slate-900 focus:border-indigo-500 focus:outline-none dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              {Array.from({ length: subTot }, (_, i) => {
                const sc = settings.completed[lvlKey(band, i)] || 0;
                return (
                  <option key={i} value={i}>
                    المستوى {i + 1} {sc >= 80 ? '✓' : sc > 0 ? `(${sc}%)` : ''}
                  </option>
                );
              })}
            </select>

            <button
              type="button"
              disabled={safeSub >= subTot - 1}
              onClick={() => onChangeSub(Math.min(subTot - 1, safeSub + 1))}
              aria-label="المستوى التالي"
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <ChevronLeft className="h-5 w-5" aria-hidden="true" />
            </button>
          </div>

          {previewWords && (
            <p className="mt-3 text-center font-en text-xs text-slate-500 dark:text-slate-400" dir="ltr">
              {previewWords}
            </p>
          )}
        </div>
      )}

      {source === 'mistakes' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center dark:border-slate-800 dark:bg-[#131c2e]">
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
            بنك الأخطاء ({settings.mistakes.length} كلمة)
          </h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            {settings.mistakes.length > 0
              ? 'ستتدرب على الكلمات التي أخطأت بها سابقاً حتى تتقنها.'
              : 'لا توجد أخطاء مسجلة حالياً — أداؤك ممتاز!'}
          </p>
        </div>
      )}

      {source === 'favorites' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 text-center dark:border-slate-800 dark:bg-[#131c2e]">
          <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
            الكلمات المفضلة ({settings.favorites.length} كلمة)
          </h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            {settings.favorites.length > 0
              ? 'ستتدرب على الكلمات التي أضفتها إلى قائمتك المفضلة.'
              : 'لم تضف كلمات إلى المفضلة بعد. يمكنك تمييز أي كلمة بنجمة من القاموس.'}
          </p>
        </div>
      )}

      {gameMode === 'mcq' && (
        <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#131c2e]">
          <h2 className="mb-3 text-sm font-bold text-slate-900 dark:text-slate-100">
            اتجاه السؤال
          </h2>
          <div className="grid grid-cols-2 gap-1.5 rounded-xl bg-slate-100 p-1 dark:bg-slate-800">
            <button
              type="button"
              onClick={() => onChangeMcqDir('en2ar')}
              className={`min-h-[42px] rounded-lg px-3 text-sm font-bold transition-colors ${
                settings.mcqDir === 'en2ar'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              إنكليزي ⟵ عربي
            </button>
            <button
              type="button"
              onClick={() => onChangeMcqDir('ar2en')}
              className={`min-h-[42px] rounded-lg px-3 text-sm font-bold transition-colors ${
                settings.mcqDir === 'ar2en'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              عربي ⟵ إنكليزي
            </button>
          </div>
        </div>
      )}

      {/* Fixed Bottom Action Dock */}
      <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-slate-200 bg-white/95 p-3 backdrop-blur-md dark:border-slate-800 dark:bg-[#0f172a]/95">
        <div className="mx-auto max-w-3xl">
          <button
            type="button"
            disabled={!canStart}
            onClick={onLaunch}
            className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 px-6 text-base font-bold text-white transition-colors hover:bg-indigo-700 disabled:opacity-45"
          >
            <Play className="h-4 w-4 fill-current" aria-hidden="true" />
            <span>ابدأ اللعب الآن</span>
          </button>
        </div>
      </div>
    </div>
  );
}
