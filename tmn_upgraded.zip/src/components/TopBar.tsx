import { useEffect, useState } from 'react';
import {
  ArrowRight,
  Award,
  BarChart3,
  BookOpen,
  BookOpenText,
  Gamepad2,
  Globe,
  GraduationCap,
  Headphones,
  Layers,
  LogIn,
  LogOut,
  Menu,
  MessageSquareText,
  Moon,
  Settings,
  ShieldCheck,
  Sparkles,
  Sun,
  User as UserIcon,
  UserPlus,
  X,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useI18n } from '../contexts/LanguageContext';
import { TMN_LOGO_URL } from '../data/constants';
import { getListeningGrammarStrings } from '../i18n/listeningGrammarStrings';
import type { NavTab, ScreenId } from '../types';

interface TopBarProps {
  screen: ScreenId;
  navTab: NavTab;
  subTitle: string;
  mistakesCount: number;
  srsDueCount: number;
  gameHud?: {
    current: number;
    total: number;
    correct: number;
    wrong: number;
  } | null;
  onSelectTab: (tab: NavTab) => void;
  onBack: () => void;
  onOpenAuth: (mode: 'signup' | 'signin') => void;
  onOpenPlacement: () => void;
  onToast: (msg: string) => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
}

export function TopBar({
  screen,
  navTab,
  subTitle,
  mistakesCount,
  srsDueCount,
  gameHud,
  onSelectTab,
  onBack,
  onOpenAuth,
  onOpenPlacement,
  onToast,
  theme = 'dark',
  onToggleTheme,
}: TopBarProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { user, signOutUser, clearAuthError } = useAuth();
  const { lang, languages, setLang, t } = useI18n();
  const lgStrings = getListeningGrammarStrings(lang);

  const primaryNavItems: Array<{ id: NavTab; label: string }> = [
    { id: 'games', label: t.navGames },
    { id: 'levels', label: t.navWords },
    { id: 'sentences', label: t.navSentences },
    { id: 'listening', label: lgStrings.navListening },
    { id: 'ai_coach', label: t.navCoach },
    { id: 'articles', label: t.navReading },
    { id: 'grammar', label: lgStrings.navGrammar },
  ];

  const isInGame = screen === 'game' || screen === 'study' || screen === 'sentence_game';
  const isSubScreen =
    screen === 'game_setup' ||
    screen === 'band_levels' ||
    screen === 'level_detail' ||
    screen === 'word_detail';

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [menuOpen]);

  const handleDrawerNav = (tab: NavTab) => {
    setMenuOpen(false);
    onSelectTab(tab);
  };

  const handleSignOut = async () => {
    await signOutUser();
    onToast(t.signOut);
    setMenuOpen(false);
  };

  return (
    <>
      <header className="tmn-glass-header sticky top-0 z-40 h-16">
        <div className="mx-auto flex h-full max-w-6xl items-center justify-between gap-3 px-4 sm:gap-6 sm:px-6">
          {/* Start side: Hamburger Menu (3 lines) or Back Button */}
          <div className="flex min-w-0 items-center gap-2.5">
            {isInGame || isSubScreen ? (
              <>
                <button
                  type="button"
                  onClick={onBack}
                  aria-label={isInGame ? t.close : t.back}
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                >
                  {isInGame ? (
                    <X className="h-4 w-4" aria-hidden="true" />
                  ) : (
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  )}
                </button>
                <span className="truncate text-sm font-bold text-slate-900 dark:text-slate-100 sm:text-base">
                  {subTitle}
                </span>
              </>
            ) : (
              <button
                type="button"
                data-testid="menu-open-btn"
                onClick={() => {
                  clearAuthError();
                  setMenuOpen(true);
                }}
                aria-label={t.menuTitle}
                aria-expanded={menuOpen}
                aria-controls="tmn-main-drawer"
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-800 transition-colors hover:border-indigo-400 hover:bg-indigo-50 hover:text-indigo-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100 dark:hover:border-indigo-500 dark:hover:bg-slate-700"
              >
                <Menu className="h-5 w-5" aria-hidden="true" />
              </button>
            )}
          </div>

          {/* CENTER: Primary Navigation Tabs (Desktop Pill Bar) */}
          {!isInGame && (
            <nav
              aria-label={t.menuMain}
              className="hidden items-center gap-1 rounded-2xl border border-slate-200/80 bg-slate-100/75 p-1 dark:border-slate-800/80 dark:bg-slate-900/70 md:flex"
            >
              {primaryNavItems.map((item) => {
                const active = navTab === item.id && !isSubScreen;
                return (
                  <button
                    key={item.id}
                    type="button"
                    data-testid={`nav-tab-${item.id}`}
                    onClick={() => onSelectTab(item.id)}
                    aria-current={active ? 'page' : undefined}
                    className={`relative shrink-0 whitespace-nowrap rounded-xl px-3.5 py-1.5 text-[13px] font-bold transition-all ${
                      active
                        ? 'bg-white text-indigo-600 shadow-xs ring-1 ring-slate-200/70 dark:bg-indigo-500/20 dark:text-indigo-300 dark:ring-indigo-400/25'
                        : 'text-slate-600 hover:bg-white/60 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800/70 dark:hover:text-slate-100'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>
          )}

          {/* End side: TMN Brand Logo + Name OR Live Game HUD */}
          <div className="flex shrink-0 items-center gap-3">
            {isInGame && gameHud ? (
              <div className="flex items-center gap-3 font-code text-xs font-semibold tabular-nums sm:text-sm">
                <span className="text-slate-600 dark:text-slate-300">
                  {gameHud.current}/{gameHud.total}
                </span>
                {(gameHud.correct + gameHud.wrong > 0 ||
                  screen === 'game' ||
                  screen === 'sentence_game') && (
                  <>
                    <span className="text-emerald-600 dark:text-emerald-400">
                      ✓ {gameHud.correct}
                    </span>
                    <span className="text-rose-600 dark:text-rose-400">✕ {gameHud.wrong}</span>
                  </>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                {onToggleTheme && (
                  <button
                    type="button"
                    onClick={onToggleTheme}
                    aria-label={theme === 'dark' ? 'الوضع النهاري' : 'الوضع الليلي'}
                    title={theme === 'dark' ? 'الوضع النهاري' : 'الوضع الليلي'}
                    className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-200/80 bg-slate-100/80 text-slate-600 transition-colors hover:border-indigo-300 hover:bg-indigo-50 hover:text-indigo-600 dark:border-slate-700/80 dark:bg-slate-800/80 dark:text-amber-300 dark:hover:border-indigo-500/50 dark:hover:bg-slate-700"
                  >
                    {theme === 'dark' ? (
                      <Sun className="h-4 w-4" aria-hidden="true" />
                    ) : (
                      <Moon className="h-4 w-4" aria-hidden="true" />
                    )}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onSelectTab('games')}
                  aria-label="TMN"
                  dir="ltr"
                  className="flex shrink-0 items-center gap-2 rounded-xl px-1.5 py-1 transition-opacity hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500"
                >
                  <img
                    src={TMN_LOGO_URL}
                    alt="TMN"
                    className="h-9 w-9 rounded-xl border border-indigo-400/35 object-cover shadow-sm ring-2 ring-indigo-500/10"
                  />
                  <span className="bg-gradient-to-r from-slate-900 via-indigo-700 to-sky-600 bg-clip-text font-en text-lg font-extrabold tracking-wider text-transparent dark:from-white dark:via-indigo-200 dark:to-sky-300 sm:text-xl">
                    TMN
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Slide-Over Drawer for ☰ Menu */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 flex justify-start">
          <div
            className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
            onClick={() => setMenuOpen(false)}
            aria-hidden="true"
          />
          <aside
            id="tmn-main-drawer"
            role="dialog"
            aria-modal="true"
            aria-label={t.menuTitle}
            className="relative z-10 flex h-full w-80 max-w-[86vw] flex-col border-e border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-[#0f172a]"
          >
            {/* Drawer Header */}
            <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <img
                  src={TMN_LOGO_URL}
                  alt="TMN"
                  className="h-9 w-9 rounded-lg border border-sky-400/40 object-cover"
                />
                <div>
                  <div className="font-en text-base font-extrabold tracking-wider text-slate-900 dark:text-white">
                    TMN
                  </div>
                  <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                    {t.appTagline}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setMenuOpen(false)}
                aria-label={t.close}
                className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            {/* Account Section */}
            <div className="border-b border-slate-200 p-4 dark:border-slate-800">
              {user ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    {user.photoURL ? (
                      <img
                        src={user.photoURL}
                        alt={user.displayName || 'TMN'}
                        referrerPolicy="no-referrer"
                        className="h-11 w-11 rounded-full border border-indigo-400/40 object-cover"
                      />
                    ) : (
                      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-indigo-600 text-white">
                        <UserIcon className="h-5 w-5" aria-hidden="true" />
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-bold text-slate-900 dark:text-slate-100">
                        {user.displayName || 'TMN'}
                      </div>
                      <div
                        className="truncate text-xs text-slate-500 dark:text-slate-400"
                        dir="ltr"
                      >
                        {user.email}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                      <ShieldCheck className="h-3.5 w-3.5" aria-hidden="true" />
                      {t.accountSynced}
                    </span>
                    <button
                      type="button"
                      onClick={() => void handleSignOut()}
                      className="inline-flex h-8 items-center gap-1 rounded-lg border border-rose-200 bg-rose-50 px-2.5 text-xs font-bold text-rose-700 hover:bg-rose-100 dark:border-rose-500/30 dark:bg-rose-500/15 dark:text-rose-300"
                    >
                      <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>{t.signOut}</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      data-testid="drawer-signup-btn"
                      onClick={() => {
                        setMenuOpen(false);
                        onOpenAuth('signup');
                      }}
                      className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl bg-sky-500 px-3 text-xs font-extrabold text-slate-950 hover:bg-sky-400"
                    >
                      <UserPlus className="h-4 w-4" aria-hidden="true" />
                      <span>{t.signUp}</span>
                    </button>
                    <button
                      type="button"
                      data-testid="drawer-signin-btn"
                      onClick={() => {
                        setMenuOpen(false);
                        onOpenAuth('signin');
                      }}
                      className="inline-flex h-10 items-center justify-center gap-1.5 rounded-xl bg-indigo-600 px-3 text-xs font-bold text-white hover:bg-indigo-700"
                    >
                      <LogIn className="h-4 w-4" aria-hidden="true" />
                      <span>{t.signIn}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Placement Test quick CTA */}
              <button
                type="button"
                data-testid="drawer-placement-btn"
                onClick={() => {
                  setMenuOpen(false);
                  onOpenPlacement();
                }}
                className="mt-2.5 flex w-full items-center justify-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs font-extrabold text-emerald-600 hover:bg-emerald-500/20 dark:text-emerald-300"
              >
                <Award className="h-4 w-4" aria-hidden="true" />
                <span>{t.takePlacementBtn}</span>
              </button>
            </div>

            {/* Menu Items */}
            <nav aria-label={t.menuTools} className="flex-1 space-y-1.5 overflow-y-auto p-4">
              <div className="mb-2 px-2 text-[11px] font-bold text-slate-400">{t.menuTools}</div>

              <button
                type="button"
                onClick={() => handleDrawerNav('stats')}
                className={`flex w-full items-center justify-between rounded-xl px-3.5 py-3 text-sm font-bold transition-colors ${
                  navTab === 'stats'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-800 hover:bg-slate-100 dark:text-slate-100 dark:hover:bg-slate-800/80'
                }`}
              >
                <span className="flex items-center gap-3">
                  <BarChart3 className="h-4 w-4" aria-hidden="true" />
                  <span>{t.navStats}</span>
                </span>
                {srsDueCount > 0 && (
                  <span
                    className={`rounded-md px-2 py-0.5 font-code text-[11px] font-bold tabular-nums ${
                      navTab === 'stats'
                        ? 'bg-white/20 text-white'
                        : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/20 dark:text-indigo-300'
                    }`}
                  >
                    {srsDueCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => handleDrawerNav('dict')}
                className={`flex w-full items-center justify-between rounded-xl px-3.5 py-3 text-sm font-bold transition-colors ${
                  navTab === 'dict'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-800 hover:bg-slate-100 dark:text-slate-100 dark:hover:bg-slate-800/80'
                }`}
              >
                <span className="flex items-center gap-3">
                  <BookOpen className="h-4 w-4" aria-hidden="true" />
                  <span>{t.navDict}</span>
                </span>
                {mistakesCount > 0 && (
                  <span
                    className={`rounded-md px-2 py-0.5 font-code text-[11px] font-bold tabular-nums ${
                      navTab === 'dict'
                        ? 'bg-white/20 text-white'
                        : 'bg-rose-50 text-rose-700 dark:bg-rose-500/20 dark:text-rose-300'
                    }`}
                  >
                    {mistakesCount > 99 ? '99+' : mistakesCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                data-testid="drawer-settings-btn"
                onClick={() => handleDrawerNav('settings')}
                className={`flex w-full items-center justify-between rounded-xl px-3.5 py-3 text-sm font-bold transition-colors ${
                  navTab === 'settings'
                    ? 'bg-indigo-600 text-white'
                    : 'text-slate-800 hover:bg-slate-100 dark:text-slate-100 dark:hover:bg-slate-800/80'
                }`}
              >
                <span className="flex items-center gap-3">
                  <Settings className="h-4 w-4" aria-hidden="true" />
                  <span>{t.navSettings}</span>
                </span>
              </button>

              {/* Compact 10-Language Selector in Drawer */}
              <div className="my-3 border-t border-slate-200 pt-3 dark:border-slate-800">
                <div className="mb-2 flex items-center gap-1.5 px-2 text-[11px] font-bold text-slate-400">
                  <Globe className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{t.languageLabel}</span>
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  {languages.map((opt) => (
                    <button
                      key={opt.code}
                      type="button"
                      data-testid={`drawer-lang-${opt.code}`}
                      onClick={() => setLang(opt.code)}
                      className={`flex items-center gap-1.5 rounded-lg border px-2 py-1.5 text-[11px] font-bold transition ${
                        lang === opt.code
                          ? 'border-sky-400 bg-sky-500/15 text-sky-600 dark:text-sky-300'
                          : 'border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-900/50 dark:text-slate-300'
                      }`}
                    >
                      <span>{opt.flag}</span>
                      <span className="truncate">{opt.nativeName}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="my-3 border-t border-slate-200 dark:border-slate-800" />
              <div className="mb-2 px-2 text-[11px] font-bold text-slate-400">{t.menuMain}</div>

              {primaryNavItems.map((item) => {
                const active = navTab === item.id && !isSubScreen;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleDrawerNav(item.id)}
                    className={`flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-bold transition-colors ${
                      active
                        ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300'
                        : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/80'
                    }`}
                  >
                    {item.id === 'games' && <Gamepad2 className="h-4 w-4" aria-hidden="true" />}
                    {item.id === 'levels' && <Layers className="h-4 w-4" aria-hidden="true" />}
                    {item.id === 'sentences' && (
                      <MessageSquareText className="h-4 w-4" aria-hidden="true" />
                    )}
                    {item.id === 'listening' && (
                      <Headphones className="h-4 w-4" aria-hidden="true" />
                    )}
                    {item.id === 'ai_coach' && <Sparkles className="h-4 w-4" aria-hidden="true" />}
                    {item.id === 'articles' && (
                      <BookOpenText className="h-4 w-4" aria-hidden="true" />
                    )}
                    {item.id === 'grammar' && (
                      <GraduationCap className="h-4 w-4" aria-hidden="true" />
                    )}
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* Mobile Bottom Navigation Bar */}
      {!isInGame && screen !== 'game_setup' && (
        <nav
          aria-label={t.menuMain}
          className="fixed bottom-0 left-0 right-0 z-40 h-14 border-t border-slate-200 bg-white/95 backdrop-blur-md dark:border-slate-800 dark:bg-[#0f172a]/95 md:hidden"
        >
          <div className="mx-auto grid h-full max-w-xl grid-cols-7">
            {primaryNavItems.map((item) => {
              const active = navTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  data-testid={`mobile-nav-tab-${item.id}`}
                  onClick={() => onSelectTab(item.id)}
                  aria-current={active ? 'page' : undefined}
                  className={`relative flex min-h-[44px] min-w-0 flex-col items-center justify-center gap-0.5 px-0.5 text-[9.5px] font-bold transition-colors sm:text-[11px] ${
                    active
                      ? 'text-indigo-600 dark:text-indigo-400'
                      : 'text-slate-500 dark:text-slate-400'
                  }`}
                >
                  {active && (
                    <span className="absolute top-0 h-0.5 w-6 rounded-b bg-indigo-600 dark:bg-indigo-400" />
                  )}
                  {item.id === 'games' && <Gamepad2 className="h-4 w-4 shrink-0" aria-hidden="true" />}
                  {item.id === 'levels' && <Layers className="h-4 w-4 shrink-0" aria-hidden="true" />}
                  {item.id === 'sentences' && (
                    <MessageSquareText className="h-4 w-4 shrink-0" aria-hidden="true" />
                  )}
                  {item.id === 'listening' && (
                    <Headphones className="h-4 w-4 shrink-0" aria-hidden="true" />
                  )}
                  {item.id === 'ai_coach' && <Sparkles className="h-4 w-4 shrink-0" aria-hidden="true" />}
                  {item.id === 'articles' && (
                    <BookOpenText className="h-4 w-4 shrink-0" aria-hidden="true" />
                  )}
                  {item.id === 'grammar' && (
                    <GraduationCap className="h-4 w-4 shrink-0" aria-hidden="true" />
                  )}
                  <span className="max-w-full truncate whitespace-nowrap">{item.label}</span>
                </button>
              );
            })}
          </div>
        </nav>
      )}
    </>
  );
}

