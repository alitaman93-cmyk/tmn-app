import { ArrowUpLeft, Star, Volume2 } from 'lucide-react';
import { BAND_META } from '../data/constants';
import type { VocabEntry } from '../types';
import { prefetchWordVideoClips } from '../utils/prefetchEngine';
import { prefetchWordHub } from '../utils/wordHubApi';

interface WordRowProps {
  word: VocabEntry;
  isFavorite: boolean;
  isMistake: boolean;
  isMastered: boolean;
  onOpenDetail: (id: number) => void;
  onSpeak: (text: string) => void;
  onToggleFavorite: (id: number) => void;
}

export function WordRow({
  word,
  isFavorite,
  isMistake,
  isMastered,
  onOpenDetail,
  onSpeak,
  onToggleFavorite,
}: WordRowProps) {
  const meta = BAND_META[word.band];

  return (
    <div
      onMouseEnter={() => {
        prefetchWordHub(word.en, word.ar, word.band, 'ar');
        prefetchWordVideoClips(word.en, false);
      }}
      className="tmn-card-lift flex items-center justify-between gap-3 rounded-2xl border border-slate-200/80 bg-white px-4 py-3 hover:border-indigo-300/80 dark:border-slate-800/90 dark:bg-[#11192b] dark:hover:border-indigo-500/40"
    >
      <button
        type="button"
        onClick={() => onOpenDetail(word.id)}
        className="flex min-w-0 flex-1 items-center gap-3 text-right focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 rounded-lg"
      >
        <span
          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-xs font-bold text-white font-en ${meta.bgClass}`}
          aria-label={`المستوى ${word.band}`}
        >
          {word.band}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-2">
            <span className="font-en text-base font-bold text-slate-900 dark:text-slate-100" dir="ltr">
              {word.en}
            </span>
            <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">·</span>
            <span className="truncate text-sm font-medium text-slate-600 dark:text-slate-300">
              {word.ar}
            </span>
          </div>
          {(isMastered || isMistake) && (
            <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              {isMastered && <span className="text-emerald-600 dark:text-emerald-400 font-semibold">متقنة</span>}
              {isMastered && isMistake && <span aria-hidden="true">·</span>}
              {isMistake && <span className="text-amber-600 dark:text-amber-400 font-semibold">في بنك الأخطاء</span>}
            </div>
          )}
        </div>
      </button>

      <div className="flex shrink-0 items-center gap-1.5">
        <button
          type="button"
          onClick={() => onSpeak(word.en)}
          aria-label={`نطق كلمة ${word.en}`}
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-700 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200 dark:hover:bg-slate-800"
        >
          <Volume2 className="h-4 w-4" aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => onToggleFavorite(word.id)}
          aria-label={isFavorite ? `إزالة ${word.en} من المفضلة` : `إضافة ${word.en} إلى المفضلة`}
          className={`flex h-10 w-10 items-center justify-center rounded-lg border transition-colors ${
            isFavorite
              ? 'border-amber-300 bg-amber-50 text-amber-600 dark:border-amber-500/40 dark:bg-amber-500/15 dark:text-amber-400'
              : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-400 dark:hover:bg-slate-800'
          }`}
        >
          <Star className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} aria-hidden="true" />
        </button>
        <button
          type="button"
          onClick={() => onOpenDetail(word.id)}
          aria-label={`تفاصيل كلمة ${word.en}`}
          className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-600 transition-colors hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-300 dark:hover:bg-slate-800"
        >
          <ArrowUpLeft className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}
