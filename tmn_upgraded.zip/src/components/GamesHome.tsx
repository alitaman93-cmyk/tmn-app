import {
  AlertCircle,
  Award,
  Brain,
  Headphones,
  ListOrdered,
  LogIn,
  ShieldCheck,
  Trophy,
  UserPlus,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useI18n } from '../contexts/LanguageContext';
import { GAMES } from '../data/constants';
import type { GameModeId, PersistedSettings, SentenceGameModeId, VocabStore } from '../types';
import { getSrsStats } from '../utils/srsLogic';
import { GameIcon } from './GameIcon';

interface GamesHomeProps {
  store: VocabStore;
  settings: PersistedSettings;
  onSelectGame: (mode: GameModeId) => void;
  onStartSentenceGame: (mode: SentenceGameModeId) => void;
  onStartDueSrsReview: () => void;
  onOpenAuth: (mode: 'signup' | 'signin') => void;
  onOpenPlacement: () => void;
}

export function GamesHome({
  store,
  settings,
  onSelectGame,
  onStartSentenceGame,
  onStartDueSrsReview,
  onOpenAuth,
  onOpenPlacement,
}: GamesHomeProps) {
  const { user } = useAuth();
  const { t } = useI18n();

  const goalPct = Math.min(
    100,
    Math.round((settings.todayCount / Math.max(1, settings.dailyGoal)) * 100)
  );
  const srsStats = getSrsStats(settings.srsCards || {});
  const placement = settings.placementResult;

  return (
    <div className="space-y-8">
      {/* Top Hero Row: Daily Goal + Anki SRS / Personal Account & Placement Card */}
      <section className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        <div className="tmn-hero-surface flex flex-col justify-between rounded-2xl border border-slate-200/80 p-6 dark:border-slate-800/90 lg:col-span-7">
          <div>
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <h1 className="text-xl font-extrabold text-slate-900 dark:text-slate-100 sm:text-2xl">
                {t.dailyGoalTitle}:{' '}
                <span className="font-code tabular-nums">{settings.todayCount}</span> /{' '}
                <span className="font-code tabular-nums">{settings.dailyGoal}</span> {t.wordsLabel}
              </h1>
              <div className="flex items-center gap-3 text-sm font-semibold tabular-nums text-slate-600 dark:text-slate-300">
                <span className="text-amber-600 dark:text-amber-400">
                  {settings.xp.toLocaleString('en-US')} XP
                </span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-600 dark:text-emerald-400">
                  {settings.mastered.length} {t.masteredLabel}
                </span>
              </div>
            </div>
            <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400">
              <span className="font-code tabular-nums">
                {store.words.length.toLocaleString('en-US')}
              </span>{' '}
              CEFR (A0–C2) · {t.appTagline}
            </p>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
            {placement ? (
              <button
                type="button"
                data-testid="home-placement-badge"
                onClick={onOpenPlacement}
                className="inline-flex items-center gap-2 rounded-xl border border-emerald-500/35 bg-emerald-500/10 px-3 py-1.5 text-xs font-extrabold text-emerald-600 dark:text-emerald-300"
              >
                <Award className="h-4 w-4" aria-hidden="true" />
                <span>
                  CEFR {placement.cefrBand}
                  {placement.nextBand
                    ? ` · +${placement.pointsToNext}% → ${placement.nextBand}`
                    : ' (MAX)'}
                </span>
              </button>
            ) : (
              <button
                type="button"
                data-testid="home-placement-cta"
                onClick={onOpenPlacement}
                className="inline-flex items-center gap-1.5 rounded-xl border border-sky-500/35 bg-sky-500/10 px-3 py-1.5 text-xs font-extrabold text-sky-700 hover:bg-sky-500/20 dark:text-sky-300"
              >
                <Award className="h-4 w-4" aria-hidden="true" />
                <span>{t.takePlacementBtn}</span>
              </button>
            )}
          </div>

          <div className="mt-4">
            <div className="mb-1.5 flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
              <span>{t.dailyProgress}</span>
              <span className="font-code tabular-nums">{goalPct}%</span>
            </div>
            <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
              <div
                className="h-full rounded-full bg-gradient-to-r from-indigo-600 via-violet-500 to-sky-500 shadow-[0_0_12px_rgba(99,102,241,0.45)] transition-all duration-500"
                style={{ width: `${goalPct}%` }}
              />
            </div>
          </div>
        </div>

        <div className="tmn-hero-surface flex flex-col justify-between rounded-2xl border border-slate-200/80 p-6 dark:border-slate-800/90 lg:col-span-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-indigo-600 dark:text-indigo-400">
                <Brain className="h-4 w-4" aria-hidden="true" />
                <span>{t.ankiTitle}</span>
              </div>
              <h2 className="mt-1.5 text-base font-extrabold text-slate-900 dark:text-slate-100">
                {srsStats.dueNow > 0
                  ? `${srsStats.dueNow} — ${t.ankiDueTitle}`
                  : t.ankiStartTitle}
              </h2>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{t.ankiDesc}</p>
            </div>
            {settings.bestStreak > 0 && (
              <div className="flex shrink-0 items-center gap-1 rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-bold text-slate-700 dark:border-slate-700 dark:bg-slate-800/70 dark:text-slate-200">
                <Trophy className="h-3.5 w-3.5 text-amber-500" aria-hidden="true" />
                <span className="font-code tabular-nums">{settings.bestStreak}</span>
              </div>
            )}
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={srsStats.dueNow > 0 ? onStartDueSrsReview : () => onSelectGame('study')}
              className="tmn-btn-primary inline-flex h-10 flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-xl px-4 text-xs font-bold sm:text-sm"
            >
              <Brain className="h-4 w-4" aria-hidden="true" />
              <span>{srsStats.dueNow > 0 ? t.ankiReviewBtn : t.ankiOpenBtn}</span>
            </button>

            {user ? (
              <div className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-3 text-xs font-bold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
                <ShieldCheck className="h-4 w-4" aria-hidden="true" />
                <span className="max-w-[110px] truncate">{user.displayName || 'TMN'}</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  data-testid="home-signup-btn"
                  onClick={() => onOpenAuth('signup')}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-sky-500 px-3 text-xs font-extrabold text-slate-950 transition-colors hover:bg-sky-400"
                >
                  <UserPlus className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{t.signUp}</span>
                </button>
                <button
                  type="button"
                  data-testid="home-signin-btn"
                  onClick={() => onOpenAuth('signin')}
                  className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-800 transition-colors hover:border-indigo-400 hover:bg-indigo-50 hover:text-indigo-700 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
                >
                  <LogIn className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>{t.signIn}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Sentence Games Section (3 Interactive Games) */}
      <section>
        <div className="mb-4 flex items-baseline justify-between gap-4">
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">
            {t.sentenceGamesTitle}
          </h2>
          <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
            {t.sentenceGamesSub}
          </span>
        </div>

        <div className="grid grid-cols-1 gap-3.5 md:grid-cols-3">
          <button
            type="button"
            onClick={() => onStartSentenceGame('sentence_order')}
            className="tmn-card-lift group flex items-start gap-4 rounded-2xl border border-indigo-200/80 bg-gradient-to-br from-white to-indigo-50/50 p-5 text-start hover:border-indigo-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 dark:border-indigo-500/25 dark:from-[#131d33] dark:to-indigo-950/35 dark:hover:border-indigo-400/70"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-indigo-600 text-white">
              <ListOrdered className="h-6 w-6" aria-hidden="true" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                {t.sentOrderTitle}
              </h3>
              <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
                {t.sentOrderDesc}
              </p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onStartSentenceGame('sentence_error')}
            className="tmn-card-lift group flex items-start gap-4 rounded-2xl border border-amber-200/80 bg-gradient-to-br from-white to-amber-50/50 p-5 text-start hover:border-amber-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 dark:border-amber-500/25 dark:from-[#131d33] dark:to-amber-950/25 dark:hover:border-amber-400/70"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-amber-500 text-slate-950">
              <AlertCircle className="h-6 w-6" aria-hidden="true" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                {t.sentErrorTitle}
              </h3>
              <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
                {t.sentErrorDesc}
              </p>
            </div>
          </button>

          <button
            type="button"
            data-testid="launch-sentence-dictation"
            onClick={() => onStartSentenceGame('sentence_dictation')}
            className="tmn-card-lift group flex items-start gap-4 rounded-2xl border border-emerald-200/80 bg-gradient-to-br from-white to-emerald-50/50 p-5 text-start hover:border-emerald-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 dark:border-emerald-500/25 dark:from-[#131d33] dark:to-emerald-950/30 dark:hover:border-emerald-400/70"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-emerald-600 text-white">
              <Headphones className="h-6 w-6" aria-hidden="true" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                  {t.sentDictTitle}
                </h3>
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  · {t.badgeNew}
                </span>
              </div>
              <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{t.sentDictDesc}</p>
            </div>
          </button>
        </div>
      </section>

      {/* 10 Word Game Modes Grid */}
      <section>
        <div className="mb-4 flex items-baseline justify-between gap-4">
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-slate-100">
            {t.wordGamesTitle}
          </h2>
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
            {t.wordGamesModes}
          </span>
        </div>

        <div className="grid grid-cols-1 gap-3.5 sm:grid-cols-2 lg:grid-cols-3">
          {GAMES.map((game) => {
            const gLoc = t.games[game.id] || { name: game.name, desc: game.desc };
            return (
              <button
                key={game.id}
                type="button"
                onClick={() => onSelectGame(game.id)}
                className={`tmn-card-lift group flex flex-col items-start gap-3 rounded-2xl border p-5 text-start focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 ${
                  game.featured
                    ? 'border-indigo-300 bg-indigo-50/50 hover:border-indigo-400 dark:border-indigo-500/40 dark:bg-indigo-950/30 dark:hover:border-indigo-400'
                    : 'border-slate-200 bg-white hover:border-slate-300 dark:border-slate-800 dark:bg-[#131c2e] dark:hover:border-slate-700'
                }`}
              >
                <div
                  className={`flex h-11 w-11 items-center justify-center rounded-xl transition-colors ${
                    game.featured
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 text-slate-700 group-hover:bg-indigo-600 group-hover:text-white dark:bg-slate-800 dark:text-slate-200'
                  }`}
                >
                  <GameIcon mode={game.id} className="h-5 w-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                      {gLoc.name}
                    </h3>
                    {game.id === 'listen_type' && (
                      <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                        · {t.badgeNew}
                      </span>
                    )}
                    {game.id === 'mixed' && (
                      <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                        · {t.badgeAll}
                      </span>
                    )}
                  </div>
                  <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{gLoc.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
}

