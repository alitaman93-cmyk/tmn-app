import { WifiOff } from 'lucide-react';
import { useI18n } from '../contexts/LanguageContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export function OfflineIndicator() {
  const isOnline = useOnlineStatus();
  const { t } = useI18n();
  if (isOnline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-16 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 whitespace-nowrap rounded-full border border-amber-500/40 bg-amber-950/95 px-4 py-2 text-xs font-bold text-amber-200 shadow-lg backdrop-blur-sm md:bottom-4"
    >
      <WifiOff className="h-3.5 w-3.5 shrink-0 text-amber-400" aria-hidden="true" />
      <span>{t.offlineBanner}</span>
    </div>
  );
}

