import { Award, LogIn, Sparkles, UserPlus, X } from 'lucide-react';
import { useI18n } from '../contexts/LanguageContext';

interface GuestSavePromptModalProps {
  open: boolean;
  onClose: () => void;
  onOpenAuth: (mode: 'signup' | 'signin') => void;
  onOpenPlacement: () => void;
}

export function GuestSavePromptModal({
  open,
  onClose,
  onOpenAuth,
  onOpenPlacement,
}: GuestSavePromptModalProps) {
  const { t } = useI18n();
  if (!open) return null;

  return (
    <div
      data-testid="guest-save-prompt"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md rounded-3xl border border-sky-500/30 bg-[var(--card)] p-6 text-center shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label={t.close}
          className="absolute end-4 top-4 flex h-8 w-8 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--card2)] text-[var(--muted)] hover:text-[var(--ink)]"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-sky-500/15 text-sky-400">
          <Sparkles className="h-6 w-6" />
        </div>

        <h3 className="text-lg font-black text-[var(--ink)]">{t.guestSaveTitle}</h3>
        <p className="mt-2 text-xs leading-relaxed text-[var(--muted)]">{t.guestSaveDesc}</p>

        <div className="mt-5 flex flex-col gap-2.5">
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenAuth('signup');
            }}
            className="inline-flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-sky-500 to-indigo-600 px-4 py-3 text-xs font-black text-white shadow-md"
          >
            <UserPlus className="h-4 w-4" />
            <span>{t.createAccount}</span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenAuth('signin');
              }}
              className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-[var(--border)] bg-[var(--card2)] px-3 py-2.5 text-xs font-extrabold text-[var(--ink)]"
            >
              <LogIn className="h-3.5 w-3.5 text-sky-400" />
              <span>{t.signIn}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenPlacement();
              }}
              className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-2.5 text-xs font-extrabold text-emerald-300"
            >
              <Award className="h-3.5 w-3.5" />
              <span>{t.takePlacementBtn}</span>
            </button>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="mt-1 text-xs font-bold text-[var(--muted)] hover:text-[var(--ink)]"
          >
            {t.guestContinueBtn}
          </button>
        </div>
      </div>
    </div>
  );
}
